# Polyglot — Multi-Language Framework

**Polyglot framework** with shared memory IPC (Iceoryx2), ML, and AI code conversion. Includes trading, AI code rewrite studio, and more.

## Applications

- **polyglot-trader-t212** — Trading212 automated trading bot (ML signals, risk gates, live execution)
- **ai-code-rewrite-studio** — AI-powered code conversion between Rust, Go, and Python
- **core_rs** — Rust core library (ML model, signal generation, polyglot utilities)
- **iceoryx2bridge** — Iceoryx2 shared memory bridge for cross-language messaging

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Polyglot Workspace                   │
├─────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   Trading    │  │   AI Code    │  │   Core RS    │  │
│  │  (T212)      │  │  Rewrite     │  │              │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │
│         │                │                 │          │
│         ▼                ▼                 ▼          │
│  ┌──────────────────────────────────────────────────┐  │
│  │              Iceoryx2 Bridge                     │  │
│  │    (Go ↔ Rust ↔ Python shared memory IPC)        │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

## Dependencies

### System
- Go 1.24+
- Rust 1.70+ (for core_rs)
- Iceoryx2 v0.9.999 (built from source)
- clang/libclang (for cgo)

## Building

```bash
# Build trading bot
cd polyglot-trader-t212
go build -o polyglot-trader-t212

# Build with Iceoryx2 integration
go build -tags=real_iceoryx2 -o polyglot-trader-t212-real

# Build AI code rewrite studio
cd ai-code-rewrite-studio
go build -o ai-code-rewrite-studio

# Build core Rust library
cd core_rs
cargo build --release

# Run tests (trading)
cd polyglot-trader-t212
go test ./...
go test -tags=real_iceoryx2 ./iceoryx2/  # 80.3% coverage

# Run tests (AI rewrite)
cd ai-code-rewrite-studio
go test ./...
```

## Running

```bash
# Paper trading (backtesting)
cd polyglot-trader-t212
./polyglot-trader-t212 --mode=paper

# Live trading
cd polyglot-trader-t212
./polyglot-trader-t212 --mode=live --t212-read-key=$T212_READ_KEY

# With Iceoryx2 IPC
cd polyglot-trader-t212
LD_LIBRARY_PATH=/tmp/iceoryx2/target/release \
  ./polyglot-trader-t212-real --mode=paper

# AI code conversion
cd ai-code-rewrite-studio
./ai-code-rewrite-studio --input=./src --target=go
```

## Configuration

Environment variables:
- `T212_READ_KEY` — Trading212 API read key
- `T212_MODE` — `paper` or `live` (trading)
- `ICEORYX2_ROOT` — Iceoryx2 data directory (default: `/tmp/iceoryx2_data`)

## Project Structure

```
polyglot/
├── polyglot-trader-t212/     # Trading212 bot (Go + ML)
│   ├── core_rs/              # Rust ML core
│   ├── iceoryx2/             # Iceoryx2 C FFI integration
│   ├── ml/                   # ML utilities
│   ├── pkg/                  # Shared packages
│   ├── risk/                 # Risk management
│   ├── t212/                 # Trading212 API client
│   ├── rate_limiter/         # API rate limiting
│   ├── circuit_breaker.go
│   ├── killswitch.go
│   ├── config.go
│   ├── main.go
│   └── main_test.go
│
├── ai-code-rewrite-studio/   # AI code conversion (Rust↔Go↔Python)
│   ├── core_rs/
│   └── ...
│
├── core_rs/                  # Rust core library
│   ├── core_rs/
│   ├── deployment/
│   ├── docs/
│   ├── monitoring/
│   ├── schema/
│   ├── xtask/
│   └── ...
│
├── iceoryx2bridge/           # Iceoryx2 bridge (Go↔Rust)
│   ├── docs/
│   ├── internal/
│   ├── iox2/
│   ├── rust2go-shim/
│   └── scripts/
│
├── go/                       # Go components
│   ├── bench/
│   ├── engine/
│   ├── internal/
│   └── rust/
│
├── bindings/                 # Python/Go bindings
│   ├── python/
│   └── go/
│
├── benchmarks/
├── docker/
├── research/
├── schema/
├── security/
├── spikes/
│   ├── tier1-iceoryx2/
│   ├── tier2-extism/
│   ├── tier3-cgo-go/
│   └── tier3-pyo3-python/
└── tests/
    ├── bench/
    ├── chaos/
    ├── conformance/
    ├── fuzz/
    ├── integration/
    ├── sanitizers/
    └── soak/
```

## Iceoryx2 Integration

Real Iceoryx2 C FFI for zero-copy shared memory IPC:

```go
package iceoryx2

/*
#cgo CFLAGS: -I/tmp/iceoryx2/target/release/iceoryx2-ffi-c-cbindgen/include
#cgo LDFLAGS: -L/tmp/iceoryx2/target/release -liceoryx2_ffi_c -lm -lpthread
*/
import "C"
```

See `polyglot-trader-t212/iceoryx2/` for full C wrapper patterns and tested examples.

## Testing

```bash
# All trading tests
cd polyglot-trader-t212 && go test ./...

# All AI rewrite tests
cd ai-code-rewrite-studio && go test ./...

# Iceoryx2 coverage (80.3%)
go test -tags=real_iceoryx2 -cover ./polyglot-trader-t212/iceoryx2/

# Benchmark
go test -tags=real_iceoryx2 -bench=. ./polyglot-trader-t212/iceoryx2/
```

## License

Private — all rights reserved.

## Contact

PunitNaran — [GitHub](https://github.com/PunitNaran)
