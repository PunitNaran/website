package main

import (
	"context"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"sync/atomic"
	"syscall"
	"time"
)

var shutdownFlag int64

// IsShuttingDown returns whether the server has received a shutdown signal.
func IsShuttingDown() bool {
	return atomic.LoadInt64(&shutdownFlag) != 0
}

// ShutdownServer wires SIGINT/SIGTERM to srv.Shutdown with a 30s drain.
func ShutdownServer(srv *http.Server) {
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		sig := <-sigCh
		slog.Warn("shutdown signal received", "signal", sig)
		atomic.StoreInt64(&shutdownFlag, 1)
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		slog.Info("shutting down HTTP server")
		if err := srv.Shutdown(ctx); err != nil {
			slog.Error("server shutdown failed", "error", err)
		}
		slog.Info("server stopped cleanly")
	}()
}
