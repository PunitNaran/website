package main

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/brain"
	"github.com/punit/polyglot-trader-t212/data"
	"github.com/punit/polyglot-trader-t212/mlservice"
	"github.com/punit/polyglot-trader-t212/pkg/rate_limiter"
	"github.com/punit/polyglot-trader-t212/risk"
	"github.com/punit/polyglot-trader-t212/t212"
)

// --- handlePositions / handleOrders (cache hit + miss) ---

func TestHandlePositions_CacheHit(t *testing.T) {
	positionsCache.Set("positions", `{"cached":true}`)
	defer positionsCache.Set("positions", "expired") // clear
	req := httptest.NewRequest(http.MethodGet, "/api/positions", nil)
	w := httptest.NewRecorder()
	handlePositions(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
	if !bytes.Contains(w.Body.Bytes(), []byte(`{"cached":true}`)) {
		t.Errorf("body = %s, want cached response", w.Body.String())
	}
}

func TestHandleOrders(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`[]`))
	}))
	defer srv.Close()
	oldBaseURL := baseURL
	baseURL = srv.URL
	defer func() { baseURL = oldBaseURL }()

	req := httptest.NewRequest(http.MethodGet, "/api/orders", nil)
	w := httptest.NewRecorder()
	handleOrders(w, req)
	if w.Code != http.StatusOK {
		t.Errorf("got %d, want 200", w.Code)
	}
}

// --- handleJSON network error ---

func TestHandleJSON_NetworkError(t *testing.T) {
	oldBaseURL := baseURL
	baseURL = "http://127.0.0.1:1"
	defer func() { baseURL = oldBaseURL }()
	w := httptest.NewRecorder()
	handleJSON(w, "/api/v0/equity/positions")
	if w.Code != http.StatusInternalServerError {
		t.Errorf("got %d, want 500", w.Code)
	}
}

// --- handleMLPredict: batch mode + rate limit ---

func TestMLPredict_BatchMode(t *testing.T) {
	body := `{"tickers":["AAPL","MSFT"],"features":[0.1,0.2]}`
	req := httptest.NewRequest(http.MethodPost, "/api/ml/predict", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["predictions"] == nil {
		t.Error("expected predictions array")
	}
}

func TestMLPredict_BatchTooManyTickers(t *testing.T) {
	body := `{"tickers":["A1","A2","A3","A4","A5","A6","A7","A8","A9","A10","A11"],"features":[0.1]}`
	req := httptest.NewRequest(http.MethodPost, "/api/ml/predict", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("got %d, want 400", w.Code)
	}
}

func TestMLPredict_RateLimited(t *testing.T) {
	// Exhaust the MLPredict budget
	for i := 0; i < 40; i++ {
		rateLimiter.Allow(rate_limiter.MLPredict, 1)
	}
	body := `{"ticker":"AAPL","features":[0.1]}`
	req := httptest.NewRequest(http.MethodPost, "/api/ml/predict", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)
	if w.Code != http.StatusTooManyRequests {
		t.Errorf("got %d, want 429 (budget 30, used 40)", w.Code)
	}
}

func TestMLPredict_InvalidJSON(t *testing.T) {
	rateLimiter = rate_limiter.NewT212RateLimiter() // ponytail: fresh budget; RateLimited test exhausts the shared one
	req := httptest.NewRequest(http.MethodPost, "/api/ml/predict", bytes.NewBuffer([]byte("{invalid")))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("got %d, want 400", w.Code)
	}
}

// --- handleRiskGate / handleSignal edge cases ---

func TestRiskGate_InvalidTicker(t *testing.T) {
	body := `{"ticker":"!!!"}`
	req := httptest.NewRequest(http.MethodPost, "/api/risk/gate", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleRiskGate)(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("got %d, want 400", w.Code)
	}
}

func TestSignal_InvalidTicker(t *testing.T) {
	body := `{"ticker":""}`
	req := httptest.NewRequest(http.MethodPost, "/api/signal", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleSignal)(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("got %d, want 400", w.Code)
	}
}

// --- startMonitoringLoops (goroutines start and stop) ---

func TestStartMonitoringLoops(t *testing.T) {
	done := make(chan struct{})
	go func() {
		ctx := context.Background()
		startMonitoringLoops(ctx)
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("startMonitoringLoops did not return")
	}
}

// --- reconcilePositions with live server ---

func TestReconcilePositions_Success(t *testing.T) {
	isolateStateDir(t)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode([]map[string]interface{}{
			{"instrument": "AAPL"},
		})
	}))
	defer srv.Close()

	// Point the t212 client at the test server
	old := t212Client
	t212Client = t212.NewT212Client("k", "s", srv.URL)
	defer func() { t212Client = old }()

	// Paper has a matching position → no discrepancy, no panic
	paperTrader.portfolio = PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 1, EntryPrice: 10, CurrentPrice: 10},
	}}
	reconcilePositions(false)
}

// --- sota endpoints: active paths ---

func TestHandleSotaStatus_Active(t *testing.T) {
	isolateStateDir(t)
	oldFL, oldML, oldAE, oldStore := fastLoop, mlOrch, autoExec, store
	fastLoop = brain.NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, time.Minute)
	autoExec = brain.NewAutoExecutor(nil, fastLoop.GetLearning(), fastLoop.GetChampionChallenger())
	dir := t.TempDir()
	mlOrch = mlservice.NewOrchestrator(dir, dir, mlservice.DefaultConfig())
	defer func() { fastLoop, mlOrch, autoExec, store = oldFL, oldML, oldAE, oldStore }()

	req := httptest.NewRequest(http.MethodGet, "/api/sota/status", nil)
	w := httptest.NewRecorder()
	handleSotaStatus(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["status"] != "active" {
		t.Errorf("status = %v, want active", resp["status"])
	}
}

func TestHandleSotaDecisions_Active(t *testing.T) {
	oldFL := fastLoop
	fastLoop = brain.NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, time.Minute)
	defer func() { fastLoop = oldFL }()

	req := httptest.NewRequest(http.MethodGet, "/api/sota/decisions?limit=3", nil)
	w := httptest.NewRecorder()
	handleSotaDecisions(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
}

func TestHandleSotaCloseAll_Active(t *testing.T) {
	oldAE := autoExec
	autoExec = brain.NewAutoExecutor(nil, nil, nil)
	defer func() { autoExec = oldAE }()

	req := httptest.NewRequest(http.MethodPost, "/api/sota/close-all", nil)
	w := httptest.NewRecorder()
	handleSotaCloseAll(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
}

func TestHandleSotaTrain_Active(t *testing.T) {
	oldML, oldStore, oldFL := mlOrch, store, fastLoop
	dir := t.TempDir()
	mlOrch = mlservice.NewOrchestrator(dir, dir, mlservice.DefaultConfig())
	st, err := data.NewStore(dir)
	if err != nil {
		t.Fatalf("store: %v", err)
	}
	store = st
	fastLoop = brain.NewFastLoop(st, nil, nil, mlOrch, []string{"AAPL"}, time.Minute)
	defer func() { mlOrch, store, fastLoop = oldML, oldStore, oldFL }()

	req := httptest.NewRequest(http.MethodPost, "/api/sota/train", nil)
	w := httptest.NewRecorder()
	handleSotaTrain(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
}

// --- updateModelQualityGate with fastLoop set ---

func TestUpdateModelQualityGate_WithFastLoop(t *testing.T) {
	oldFL := fastLoop
	fastLoop = brain.NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, time.Minute)
	defer func() { fastLoop = oldFL }()

	updateModelQualityGate() // must not panic; mlOrch nil → gates allowed
}

// --- kellySizerAdapter with learning stats ---

func TestKellySizerAdapter_WithLearningStats(t *testing.T) {
	ll := brain.NewLearningLoop(1)
	// 6 winning trades → stats qualified (Trades>5, positive expectancy)
	for i := 0; i < 6; i++ {
		ll.RecordOutcome(brain.TradeOutcome{Model: "default", PnL: 10})
	}
	k := risk.NewQuarterKellySizer(10, 80, 5)
	adapter := &kellySizerAdapter{kelly: k, learning: ll}
	if n := adapter.Size(0.7, 1000); n <= 0 {
		t.Errorf("Size with stats = %v, want > 0", n)
	}
}

// --- handleSystemStatus edge: never traded ---

func TestHandleSystemStatus_NoTrades(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 100}
	req := httptest.NewRequest(http.MethodGet, "/api/system/status", nil)
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleSystemStatus)(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["stale"] != false {
		t.Errorf("stale = %v, want false (never traded)", resp["stale"])
	}
}

// --- RuntimeConfig.Apply with live components ---

func TestRuntimeConfig_Apply_WithComponents(t *testing.T) {
	oldAE, oldFL, oldKelly := autoExec, fastLoop, kellySizer
	autoExec = brain.NewAutoExecutor(nil, nil, nil)
	fastLoop = brain.NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, time.Minute)
	k := risk.NewQuarterKellySizer(10, 80, 5)
	kellySizer = k
	defer func() { autoExec, fastLoop, kellySizer = oldAE, oldFL, oldKelly }()

	runtimeCfg.DailyBudget = 20
	runtimeCfg.MaxOrderValue = 100
	runtimeCfg.MinTradeSize = 7
	runtimeCfg.Apply() // must push to all three live components

	if !runtimeCfg.AutoExecuteEnabled() {
		t.Error("expected auto execute enabled")
	}
}

// --- getContentType: all suffixes verified above; main() and ShutdownServer
// are entry points exercised via integration tests.

// --- handleMLPredict: batch validation of one bad ticker ---

func TestMLPredict_BatchInvalidTicker(t *testing.T) {
	body := `{"tickers":["AAPL","!!!"],"features":[0.1]}`
	req := httptest.NewRequest(http.MethodPost, "/api/ml/predict", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("got %d, want 400", w.Code)
	}
}

// --- handleJSON: response read failure path (short read) ---

func TestHandleJSON_ReadBodyFailure(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Write partial body then close early via hijack-free chunk trick
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()
	oldBaseURL := baseURL
	baseURL = srv.URL
	defer func() { baseURL = oldBaseURL }()
	w := httptest.NewRecorder()
	handleJSON(w, "/api/v0/equity/positions")
	if w.Code != http.StatusOK {
		t.Errorf("got %d, want 200", w.Code)
	}
}

// --- parseUniverse: empty string ---

func TestParseUniverse_Empty(t *testing.T) {
	os.Setenv("TRADING_UNIVERSE", "  ,  ")
	defer os.Unsetenv("TRADING_UNIVERSE")
	u := parseUniverse()
	if len(u) != 0 {
		t.Errorf("universe = %v, want empty", u)
	}
}
