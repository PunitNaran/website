package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/pkg/cache"
	"github.com/punit/polyglot-trader-t212/risk"
)

func TestMain(m *testing.M) {
	os.Setenv("T212_READ_KEY", "test-key")
	os.Setenv("T212_READ_SECRET", "test-secret")
	os.Setenv("T212_BASE_URL", "https://api.trading212.com")
	// Re-initialize globals after env change
	readKey = os.Getenv("T212_READ_KEY")
	readSecret = os.Getenv("T212_READ_SECRET")
	baseURL = os.Getenv("T212_BASE_URL")
	code := m.Run()
	os.Exit(code)
}

func TestHealthEndpoint(t *testing.T) {
	req := httptest.NewRequest("GET", "/health", nil)
	w := httptest.NewRecorder()
	handleHealth(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)

	if resp["status"] != "ok" {
		t.Errorf("expected status ok, got %v", resp["status"])
	}
}

func TestReadyEndpoint(t *testing.T) {
	req := httptest.NewRequest("GET", "/ready", nil)
	w := httptest.NewRecorder()
	handleReady(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)

	if resp["status"] != "ready" {
		t.Errorf("expected status ready, got %v", resp["status"])
	}
}

func TestMLPredictEndpoint(t *testing.T) {
	body := map[string]interface{}{
		"ticker":   "AAPL",
		"features": []float64{0.5, 0.6, 0.7},
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/ml/predict", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d: %s", w.Code, w.Body.String())
	}

	var resp predictResponse
	json.NewDecoder(w.Body).Decode(&resp)

	if resp.Prediction.Ticker != "AAPL" {
		t.Errorf("expected ticker AAPL, got %s", resp.Prediction.Ticker)
	}
	if resp.Prediction.Signal != "HOLD" {
		t.Errorf("expected signal HOLD, got %s", resp.Prediction.Signal)
	}
}

func TestMLPredictValidationEmptyTicker(t *testing.T) {
	body := map[string]interface{}{
		"ticker":   "",
		"features": []float64{0.5},
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/ml/predict", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", w.Code)
	}
}

func TestMLPredictValidationMissingFeatures(t *testing.T) {
	body := map[string]interface{}{
		"ticker":   "AAPL",
		"features": []float64{},
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/ml/predict", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", w.Code)
	}
}

func TestMLPredictValidationInvalidTicker(t *testing.T) {
	body := map[string]interface{}{
		"ticker":   "AAPL-INVALID!",
		"features": []float64{0.5},
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/ml/predict", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", w.Code)
	}
}

func TestRiskGateEndpoint(t *testing.T) {
	body := map[string]interface{}{
		"scheme":          "ISA",
		"ticker":          "AAPL",
		"side":            "BUY",
		"quantity":        10,
		"limit_price":     150.0,
		"market_price":    150.0,
		"position_value":  1500.0,
		"portfolio_value": 10000.0,
		"sector":          "TECH",
		"free_margin":     5000.0,
		"sector_exposure": 20.0,
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/risk/gate", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleRiskGate)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d: %s", w.Code, w.Body.String())
	}
}

func TestRiskGateEndpointBearRegimeBlocksBuy(t *testing.T) {
	// SPY below its EMA → MacroRegime gate must block a BUY. Before the
	// fix, SpyPrice/SpyEMA were both set to the ticker's market price,
	// so this gate could never fire on this endpoint.
	body := map[string]interface{}{
		"ticker":          "AAPL",
		"side":            "BUY",
		"market_price":    150.0,
		"spy_price":       480.0, // SPY
		"spy_ema":         500.0, // SPY below EMA → bear regime
		"position_value":  1500.0,
		"portfolio_value": 10000.0,
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/risk/gate", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleRiskGate)(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", w.Code, w.Body.String())
	}
	var resp risk.GateResultFull
	if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp.Passed {
		t.Errorf("expected bear-regime gate to block buy, got passed: %+v", resp.Gates)
	}
	if resp.FailedGate != "MacroRegime" {
		t.Errorf("expected failed gate MacroRegime, got %q", resp.FailedGate)
	}
}

// TestRiskGateEndpointNoSpyDataDoesNotLeakState guards against the old
// shared-riskGates bug: a request with no SPY data must evaluate the
// MacroRegime gate as "No SPY data available — allowing" (its own zero
// value), NOT inherit SPY price/EMA from a prior request.
func TestRiskGateEndpointNoSpyDataDoesNotLeakState(t *testing.T) {
	auth := basicAuth("test-key", "test-secret")
	// 1. Seed the (now per-request) gate state with a bear regime first.
	seed := map[string]interface{}{
		"ticker": "AAPL", "side": "BUY", "market_price": 150,
		"spy_price": 480, "spy_ema": 500,
		"position_value": 1500, "portfolio_value": 10000,
	}
	sb, _ := json.Marshal(seed)
	req := httptest.NewRequest("POST", "/api/risk/gate", bytes.NewBuffer(sb))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", auth)
	w := httptest.NewRecorder()
	authMiddleware(handleRiskGate)(w, req)
	var seedResp risk.GateResultFull
	json.NewDecoder(w.Body).Decode(&seedResp)
	if seedResp.Passed || seedResp.FailedGate != "MacroRegime" {
		t.Fatalf("setup: expected seed request blocked by MacroRegime, got passed=%v failed=%q", seedResp.Passed, seedResp.FailedGate)
	}
	// 2. A follow-up request with NO spy fields must NOT be blocked by
	// MacroRegime (it should report "No SPY data available — allowing").
	nospy := map[string]interface{}{
		"ticker": "AAPL", "side": "BUY", "market_price": 150,
		"position_value": 1500, "portfolio_value": 10000,
	}
	nb, _ := json.Marshal(nospy)
	req2 := httptest.NewRequest("POST", "/api/risk/gate", bytes.NewBuffer(nb))
	req2.Header.Set("Content-Type", "application/json")
	req2.Header.Set("Authorization", auth)
	w2 := httptest.NewRecorder()
	authMiddleware(handleRiskGate)(w2, req2)
	var resp2 risk.GateResultFull
	if err := json.NewDecoder(w2.Body).Decode(&resp2); err != nil {
		t.Fatalf("decode: %v", err)
	}
	var macro *risk.GateResult
	for i := range resp2.Gates {
		if resp2.Gates[i].Name == "MacroRegime" {
			macro = &resp2.Gates[i]
			break
		}
	}
	if macro == nil {
		t.Fatalf("MacroRegime gate missing from result")
	}
	if !macro.Passed {
		t.Errorf("no-SPY request should pass MacroRegime, got failed: %s", macro.Reason)
	}
	// The old shared-gates bug would have reported the seeded bear regime
	// here ("SPY $480 < EMA $500 — bear regime, buy blocked"). With a
	// per-request gate set the gate is simply unset and bypassed.
	if macro.Reason != "Gate not configured — bypassing" {
		t.Errorf("expected 'Gate not configured — bypassing', got %q (state leaked from prior request?)", macro.Reason)
	}
}

func TestRiskGateValidationEmptyTicker(t *testing.T) {
	body := map[string]interface{}{
		"scheme":       "ISA",
		"ticker":       "",
		"side":         "BUY",
		"quantity":     10,
		"limit_price":  150.0,
		"market_price": 150.0,
		"sector":       "TECH",
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/risk/gate", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleRiskGate)(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", w.Code)
	}
}

func TestSignalEndpoint(t *testing.T) {
	body := map[string]interface{}{
		"ticker":          "AAPL",
		"price":           150.0,
		"volume":          1000000.0,
		"features":        []float64{0.5, 0.6, 0.7},
		"spy_price":       450.0,
		"spy_ema":         448.0,
		"free_margin":     5000.0,
		"total_equity":    10000.0,
		"daily_pnl":       -100.0,
		"sector":          "TECH",
		"sector_exposure": 20.0,
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/signal", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleSignal)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d: %s", w.Code, w.Body.String())
	}

	var resp signalResponse
	json.NewDecoder(w.Body).Decode(&resp)

	if !resp.Accepted {
		t.Log("Signal not accepted (expected if risk gates block it)")
	}
}

func TestRateLimitStatusEndpoint(t *testing.T) {
	req := httptest.NewRequest("GET", "/api/ratelimit/status", nil)
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleRateLimitStatus)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d: %s", w.Code, w.Body.String())
	}
}

func TestAuthMiddlewareRejectUnauthorized(t *testing.T) {
	// Call a protected endpoint without auth
	req := httptest.NewRequest("GET", "/api/ml/predict", nil)
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", w.Code)
	}

	// Check WWW-Authenticate header
	if w.Header().Get("WWW-Authenticate") == "" {
		t.Error("expected WWW-Authenticate header")
	}
}

func TestAuthMiddlewareAcceptAuthorized(t *testing.T) {
	body := map[string]interface{}{
		"ticker":   "GOOG",
		"features": []float64{0.5, 0.6},
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/ml/predict", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}
}

func TestAuthMiddlewareRejectBadCredentials(t *testing.T) {
	body := map[string]interface{}{
		"ticker":   "AAPL",
		"features": []float64{0.5},
	}
	jsonBody, _ := json.Marshal(body)

	req := httptest.NewRequest("POST", "/api/ml/predict", bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", basicAuth("wrong", "wrong"))
	w := httptest.NewRecorder()
	authMiddleware(handleMLPredict)(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Errorf("expected 401, got %d", w.Code)
	}
}

func TestValidateTicker(t *testing.T) {
	tests := []struct {
		input string
		valid bool
	}{
		{"AAPL", true},
		{"tsla", true},
		{"GOOGL", true},
		{"", false},
		{"A", true},
		{"ABCDEFGHIJKLMNOPQRSTUVWXYZ", false}, // too long
		{"AAPL-!", false},
		{"12345", true},
	}

	for _, tc := range tests {
		t.Run(tc.input, func(t *testing.T) {
			if got := validateTicker(tc.input); got != tc.valid {
				t.Errorf("validateTicker(%q) = %v, want %v", tc.input, got, tc.valid)
			}
		})
	}
}

func TestMetricsEndpoint(t *testing.T) {
	// Record some requests first
	req := httptest.NewRequest("GET", "/health", nil)
	w := httptest.NewRecorder()
	metricsMiddleware(metricsCol, handleHealth)(w, req)

	req2 := httptest.NewRequest("GET", "/metrics", nil)
	w2 := httptest.NewRecorder()
	metricsCol.ServeHTTP(w2, req2)

	if w2.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w2.Code)
	}

	// Should now have metrics since we recorded requests
	if w2.Body.Len() == 0 {
		t.Error("expected non-empty metrics output after recording requests")
	}
}

func TestMetricsMiddleware(t *testing.T) {
	// Call an endpoint through the metrics middleware
	req := httptest.NewRequest("GET", "/health", nil)
	w := httptest.NewRecorder()
	metricsMiddleware(metricsCol, handleHealth)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}

	// Verify metrics were recorded
	req2 := httptest.NewRequest("GET", "/metrics", nil)
	w2 := httptest.NewRecorder()
	metricsCol.ServeHTTP(w2, req2)

	if w2.Body.Len() == 0 {
		t.Error("expected metrics to be recorded after request")
	}
}

func TestLoggingMiddleware(t *testing.T) {
	req := httptest.NewRequest("GET", "/health", nil)
	w := httptest.NewRecorder()
	loggingMiddleware(handleHealth)(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}
	// Logging just verifies it doesn't crash; actual log output is to stdout.
}

func TestCacheSetAndGet(t *testing.T) {
	c := cache.New(100 * time.Millisecond)
	c.Set("test-key", "test-value")

	val, ok := c.Get("test-key")
	if !ok {
		t.Fatal("expected cache hit")
	}
	if val.(string) != "test-value" {
		t.Errorf("expected test-value, got %v", val)
	}
}

func TestCacheExpiration(t *testing.T) {
	c := cache.New(50 * time.Millisecond)
	c.Set("expiring-key", "expiring-value")

	time.Sleep(100 * time.Millisecond)

	_, ok := c.Get("expiring-key")
	if ok {
		t.Error("expected cache miss after expiration")
	}
}

func TestCacheGetNonExistent(t *testing.T) {
	c := cache.New(1 * time.Minute)
	_, ok := c.Get("non-existent")
	if ok {
		t.Error("expected cache miss for non-existent key")
	}
}

// --- Helpers ---

func basicAuth(user, pass string) string {
	creds := user + ":" + pass
	return "Basic " + base64.StdEncoding.EncodeToString([]byte(creds))
}
