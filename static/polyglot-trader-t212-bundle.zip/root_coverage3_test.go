package main

import (
	"bytes"
	"encoding/json"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/brain"
	"github.com/punit/polyglot-trader-t212/t212"
)

func chdirTemp(t *testing.T) {
	t.Helper()
	old, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chdir(t.TempDir()); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { os.Chdir(old) })
}

func newTestT212Client(t *testing.T, quotes map[string]any) *t212.T212Client {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/v0/equity/quotes" {
			if quotes == nil {
				w.WriteHeader(http.StatusServiceUnavailable)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(quotes)
			return
		}
		w.WriteHeader(http.StatusNotFound)
	}))
	t.Cleanup(srv.Close)
	return t212.NewT212Client("k", "s", srv.URL)
}

// --- killswitch: already-halted + close-all with autoExec ---

func TestKillSwitch_AlreadyHalted(t *testing.T) {
	chdirTemp(t)
	killSwitch.Reset()
	oldAE := autoExec
	autoExec = nil
	defer func() {
		autoExec = oldAE
		killSwitch.Reset()
	}()
	killSwitch.Activate()
	req := httptest.NewRequest(http.MethodPost, "/api/kill-switch", nil)
	w := httptest.NewRecorder()
	handleKillSwitch(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
	if !strings.Contains(w.Body.String(), "already_halted") {
		t.Errorf("body = %s, want already_halted", w.Body.String())
	}
}

func TestKillSwitch_CloseAllWithAutoExec(t *testing.T) {
	chdirTemp(t)
	killSwitch.Reset()
	paperTrader.portfolio = PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 2, EntryPrice: 10, CurrentPrice: 10},
	}}
	oldAE := autoExec
	autoExec = brain.NewAutoExecutor(nil, nil, nil)
	defer func() {
		autoExec = oldAE
		killSwitch.Reset()
	}()
	req := httptest.NewRequest(http.MethodPost, "/api/kill-switch", nil)
	w := httptest.NewRecorder()
	handleKillSwitch(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d: %s", w.Code, w.Body.String())
	}
	if len(paperTrader.Portfolio().Positions) != 0 {
		t.Error("expected positions flattened")
	}
}

// --- paper_trading: SELL with no position ---

func TestPaperTrader_SellWithoutPosition(t *testing.T) {
	chdirTemp(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 100}}
	if err := pt.ExecuteTrade("AAPL", "SELL", 1, 10, "nope"); err == nil {
		t.Error("expected 'no position' error")
	}
}

// --- paper_trading: LoadState bad JSON ---

func TestPaperTrader_LoadStateBadJSON(t *testing.T) {
	chdirTemp(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 5}}
	os.WriteFile("paper_portfolio.json", []byte("{bad"), 0644)
	pt.LoadState()
	if pt.portfolio.Cash != 5 {
		t.Errorf("cash = %v, want 5 (defaults kept)", pt.portfolio.Cash)
	}
}

// --- paper_trading: writeTradesFile via a trade ---

func TestPaperTrader_WriteTradesFile(t *testing.T) {
	chdirTemp(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 100}}
	if err := pt.ExecuteTrade("AAPL", "BUY", 1, 10, "t"); err != nil {
		t.Fatalf("buy: %v", err)
	}
	raw, err := os.ReadFile("paper_trades.json")
	if err != nil {
		t.Fatalf("paper_trades.json missing: %v", err)
	}
	var log []map[string]any
	if err := json.Unmarshal(raw, &log); err != nil {
		t.Fatalf("trades file not a JSON array: %v", err)
	}
	if len(log) != 1 {
		t.Errorf("trades = %d, want 1", len(log))
	}
}

// --- paper_trading: handlePaperSignals with a fast loop ---

func TestHandlePaperSignals_WithFastLoop(t *testing.T) {
	chdirTemp(t)
	oldFL := fastLoop
	fastLoop = brain.NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, time.Minute)
	defer func() { fastLoop = oldFL }()
	req := httptest.NewRequest(http.MethodGet, "/api/paper/signals", nil)
	w := httptest.NewRecorder()
	handlePaperSignals(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d: %s", w.Code, w.Body.String())
	}
}

// --- paper_trading: handlePaperExecuteTrade price fallbacks ---

func TestPaperExecute_PriceFromT212LastField(t *testing.T) {
	chdirTemp(t)
	body := `{"ticker":"ZZZZQQQQ1","side":"BUY","quantity":1}`
	old := t212Client
	t212Client = newTestT212Client(t, map[string]any{
		"ZZZZQQQQ1": map[string]any{"last": 7.5}, // no "price" → "last" branch
	})
	defer func() { t212Client = old }()
	req := httptest.NewRequest(http.MethodPost, "/api/paper/execute", strings.NewReader(body))
	w := httptest.NewRecorder()
	handlePaperExecuteTrade(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d: %s", w.Code, w.Body.String())
	}
}

func TestPaperExecute_PriceFromT212PriceField(t *testing.T) {
	chdirTemp(t)
	body := `{"ticker":"ZZZZQQQQ1","side":"BUY","quantity":1}`
	old := t212Client
	t212Client = newTestT212Client(t, map[string]any{
		"ZZZZQQQQ1": map[string]any{"price": 9.5},
	})
	defer func() { t212Client = old }()
	req := httptest.NewRequest(http.MethodPost, "/api/paper/execute", strings.NewReader(body))
	w := httptest.NewRecorder()
	handlePaperExecuteTrade(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d: %s", w.Code, w.Body.String())
	}
}

func TestPaperExecute_PriceUnresolvable(t *testing.T) {
	chdirTemp(t)
	body := `{"ticker":"ZZZZQQQQ1","side":"BUY","quantity":1}`
	old := t212Client
	t212Client = newTestT212Client(t, nil)
	defer func() { t212Client = old }()
	req := httptest.NewRequest(http.MethodPost, "/api/paper/execute", strings.NewReader(body))
	w := httptest.NewRecorder()
	handlePaperExecuteTrade(w, req)
	if w.Code != http.StatusInternalServerError {
		t.Fatalf("got %d, want 500: %s", w.Code, w.Body.String())
	}
}

// --- paper_broker_adapter: no position ---

func TestPaperBrokerAdapter_GetPositionPrice_NoPosition(t *testing.T) {
	chdirTemp(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 10}
	a := &paperBrokerAdapter{}
	if p := a.GetPositionPrice("NOSUCHTICKER1"); p != 0 {
		t.Errorf("price = %v, want 0", p)
	}
}

// --- circuit_breaker: open, not yet recoverable ---

func TestCircuitBreaker_OpenNotRecoverable(t *testing.T) {
	cb := NewCircuitBreaker(1, -100, 30*time.Second)
	cb.RecordFailure(1, 0)
	if allowed, _ := cb.AllowRequest(); allowed {
		t.Error("expected request blocked while open")
	}
}

// --- config.go: Validate remaining branches ---

func TestConfig_ValidateBranches(t *testing.T) {
	cases := []struct {
		name string
		c    Config
	}{
		{"secret empty", Config{T212ReadKey: "k", CircuitMaxErrors: 1, CircuitRecoverSec: 1, RetryMaxRetries: 0, RetryMultiplier: 1}},
		{"maxErrors 0", Config{T212ReadKey: "k", T212ReadSecret: "s", CircuitMaxErrors: 0, CircuitRecoverSec: 1, RetryMaxRetries: 0, RetryMultiplier: 1}},
		{"recover 0", Config{T212ReadKey: "k", T212ReadSecret: "s", CircuitMaxErrors: 1, CircuitRecoverSec: 0, RetryMaxRetries: 0, RetryMultiplier: 1}},
		{"retries -1", Config{T212ReadKey: "k", T212ReadSecret: "s", CircuitMaxErrors: 1, CircuitRecoverSec: 1, RetryMaxRetries: -1, RetryMultiplier: 1}},
		{"multiplier <1", Config{T212ReadKey: "k", T212ReadSecret: "s", CircuitMaxErrors: 1, CircuitRecoverSec: 1, RetryMaxRetries: 0, RetryMultiplier: 0.5}},
	}
	for _, tc := range cases {
		if err := tc.c.Validate(); err == nil {
			t.Errorf("Validate(%s): expected error, got nil", tc.name)
		}
	}
}

func TestConfig_LoadEnvFile(t *testing.T) {
	chdirTemp(t)
	os.WriteFile(".env", []byte("# comment\n\nNEW_KEY_ONE=hello\nNEW_KEY_TWO='quoted'\n"), 0644)
	defer os.Unsetenv("NEW_KEY_ONE")
	defer os.Unsetenv("NEW_KEY_TWO")
	cfg := LoadConfig()
	// T212_BASE_URL is already set by TestMain; LoadConfig only fills
	// missing env vars, so it must survive (not be overridden by .env).
	if cfg.T212BaseURL != os.Getenv("T212_BASE_URL") {
		t.Errorf("base url = %q, want %q (env value preserved)", cfg.T212BaseURL, os.Getenv("T212_BASE_URL"))
	}
	if v := os.Getenv("NEW_KEY_ONE"); v != "hello" {
		t.Errorf("NEW_KEY_ONE = %q, want hello", v)
	}
	if v := os.Getenv("NEW_KEY_TWO"); v != "quoted" {
		t.Errorf("NEW_KEY_TWO = %q, want quoted (quotes stripped)", v)
	}
}

// --- runtime_config.go: LoadFile variants ---

func TestRuntimeConfig_LoadFileVariants(t *testing.T) {
	chdirTemp(t)
	rc := &RuntimeConfig{}
	rc.LoadFile()
	if rc.MinTradeSize != 0 {
		t.Errorf("min_trade_size = %v, want 0 (missing file)", rc.MinTradeSize)
	}
	os.WriteFile("runtime_config.json", []byte("{bad"), 0644)
	rc.LoadFile()
	if rc.MinTradeSize != 0 {
		t.Errorf("min_trade_size = %v, want 0 (bad json)", rc.MinTradeSize)
	}
	os.WriteFile("runtime_config.json", []byte(`{"min_trade_size":9,"stop_loss_pct":-3,"take_profit_pct":7,"auto_execute":false,"daily_budget":11,"max_order_value":55}`), 0644)
	rc.LoadFile()
	if rc.MinTradeSize != 9 || rc.StopLossPct != -3 || rc.TakeProfitPct != 7 || rc.AutoExecute || rc.DailyBudget != 11 || rc.MaxOrderValue != 55 {
		t.Errorf("loaded config = %+v", rc)
	}
}

// --- runtime_config.go: LoadEnv all-branch coverage ---

func TestRuntimeConfig_LoadEnvAllBranches(t *testing.T) {
	os.Setenv("TRADING_WEEKLY_BUDGET", "30")
	os.Setenv("MAX_DOLLARS_PER_ORDER", "500")
	os.Setenv("MIN_CONFIDENCE", "0.7")
	os.Setenv("TRADING_STOP_LOSS_PCT", "5")
	os.Setenv("TRADING_TAKE_PROFIT_PCT", "9")
	os.Setenv("SOTA_EXECUTE", "false")
	defer func() {
		for _, k := range []string{"TRADING_WEEKLY_BUDGET", "MAX_DOLLARS_PER_ORDER", "MIN_CONFIDENCE", "TRADING_STOP_LOSS_PCT", "TRADING_TAKE_PROFIT_PCT", "SOTA_EXECUTE"} {
			os.Unsetenv(k)
		}
	}()
	rc := &RuntimeConfig{}
	rc.LoadEnv()
	if rc.WeeklyBudget != 30 || rc.MaxOrderValue != 500 || rc.MinConfidence != 0.7 || rc.StopLossPct != -5 || rc.TakeProfitPct != 9 || rc.AutoExecute {
		t.Errorf("config = %+v", rc)
	}
}

// --- runtime_config.go: SaveFile in a temp dir ---

func TestRuntimeConfig_SaveFileInTempDir(t *testing.T) {
	chdirTemp(t)
	rc := &RuntimeConfig{MinTradeSize: 7}
	rc.SaveFile()
	raw, err := os.ReadFile("runtime_config.json")
	if err != nil {
		t.Fatalf("save: %v", err)
	}
	var back RuntimeConfig
	json.Unmarshal(raw, &back)
	if back.MinTradeSize != 7 {
		t.Errorf("persisted min_trade_size = %v, want 7", back.MinTradeSize)
	}
}

// --- runtime_config.go: handleConfig POST remaining fields ---

func TestHandleConfig_POSTRemainingFields(t *testing.T) {
	chdirTemp(t)
	body := `{"max_order_value":250,"min_confidence":0.8,"stop_loss_pct":-7,"take_profit_pct":12,"auto_execute":false,"reset_paper":true}`
	req := httptest.NewRequest(http.MethodPost, "/api/config", strings.NewReader(body))
	w := httptest.NewRecorder()
	handleConfig(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d: %s", w.Code, w.Body.String())
	}
	if runtimeCfg.MaxOrderValue != 250 || runtimeCfg.MinConfidence != 0.8 || runtimeCfg.StopLossPct != -7 || runtimeCfg.TakeProfitPct != 12 || runtimeCfg.AutoExecute {
		t.Errorf("config = %+v", runtimeCfg)
	}
	runtimeCfg.MaxOrderValue = 0
	runtimeCfg.MinConfidence = 0.55
	runtimeCfg.StopLossPct = -4
	runtimeCfg.TakeProfitPct = 8
	runtimeCfg.AutoExecute = true
}

// --- main(): full startup → health check → SIGTERM → clean exit ---
// main() ends in os.Exit(1) after a graceful shutdown (see main.go), so it
// must run in a child process; the parent just drives it.
func TestMain_FullStartupShutdown(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("signal test is unix-only")
	}

	// Child mode: run main() (it exits the process on SIGTERM).
	if os.Getenv("POLYGLOT_TEST_MAIN") == "1" {
		main()
		return
	}

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Skipf("no free port: %v", err)
	}
	freePort := ln.Addr().(*net.TCPAddr).Port
	ln.Close()

	d := t.TempDir()
	models := d + "/models"
	if err := os.MkdirAll(models, 0755); err != nil {
		t.Fatal(err)
	}
	os.WriteFile(models+"/model_info.json", []byte(`{"model_path":"m.txt","metrics":{"auc_val":0.7}}`), 0644)

	cmd := exec.Command(os.Args[0], "-test.run=TestMain_FullStartupShutdown")
	env := os.Environ()
	setEnv := func(k, v string) {
		for i, e := range env {
			if strings.HasPrefix(e, k+"=") {
				env[i] = k + "=" + v
				return
			}
		}
		env = append(env, k+"="+v)
	}
	unsetEnv := func(k string) {
		for i, e := range env {
			if strings.HasPrefix(e, k+"=") {
				env = append(env[:i], env[i+1:]...)
				return
			}
		}
	}
	unsetEnv("PORT")
	unsetEnv("DATA_DIR")
	unsetEnv("SOTA_EXECUTE")
	unsetEnv("MAX_DOLLARS_PER_ORDER")
	unsetEnv("TRADING_DAILY_BUDGET")
	unsetEnv("TRADING_MAX_HOLD_DAYS")
	unsetEnv("ML_SCRIPT_DIR")
	setEnv("POLYGLOT_TEST_MAIN", "1")
	setEnv("PORT", strconv.Itoa(freePort))
	setEnv("DATA_DIR", d)
	setEnv("SOTA_EXECUTE", "false")
	setEnv("MAX_DOLLARS_PER_ORDER", "500")
	setEnv("TRADING_DAILY_BUDGET", "10")
	setEnv("TRADING_MAX_HOLD_DAYS", "3")
	setEnv("ML_SCRIPT_DIR", "python/ml")
	cmd.Env = env
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Start(); err != nil {
		t.Fatalf("start: %v", err)
	}

	deadline := time.Now().Add(15 * time.Second)
	healthURL := "http://127.0.0.1:" + strconv.Itoa(freePort) + "/health"
	for {
		resp, err := http.Get(healthURL)
		if err == nil {
			resp.Body.Close()
			break
		}
		if time.Now().After(deadline) {
			cmd.Process.Kill()
			t.Fatalf("server never came up: %s", out.String())
		}
		time.Sleep(50 * time.Millisecond)
	}

	if err := cmd.Process.Signal(syscall.SIGTERM); err != nil {
		t.Fatalf("signal: %v", err)
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	select {
	case err := <-done:
		// main() os.Exit(1)s after a graceful shutdown — expected.
		if err == nil {
			t.Fatal("expected exit code 1 after graceful shutdown, got 0")
		}
	case <-time.After(35 * time.Second):
		cmd.Process.Kill()
		t.Fatalf("main() did not exit after SIGTERM: %s", out.String())
	}
}
