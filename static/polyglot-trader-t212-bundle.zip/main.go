package main

import (
	"context"
	"embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"math"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/punit/polyglot-trader-t212/brain"
	"github.com/punit/polyglot-trader-t212/data"
	"github.com/punit/polyglot-trader-t212/ml"
	"github.com/punit/polyglot-trader-t212/mlservice"
	"github.com/punit/polyglot-trader-t212/pkg/cache"
	"github.com/punit/polyglot-trader-t212/pkg/http_client"
	"github.com/punit/polyglot-trader-t212/pkg/metrics"
	"github.com/punit/polyglot-trader-t212/pkg/rate_limiter"
	"github.com/punit/polyglot-trader-t212/risk"
	"github.com/punit/polyglot-trader-t212/t212"
)

var port = normalizePort(envOr("PORT", ":8081"))

func envFloat(k string, def float64) float64 {
	if v := os.Getenv(k); v != "" {
		if f, err := strconv.ParseFloat(v, 64); err == nil {
			return f
		}
	}
	return def
}

// kellySizerAdapter adapts risk.QuarterKellySizer to brain.PositionSizer.
// Win/loss payoff ratio is estimated from realized trade outcomes when
// enough history exists, else defaults to 1.0 (symmetric daily horizon).
type kellySizerAdapter struct {
	kelly    *risk.QuarterKellySizer
	learning *brain.LearningLoop
}

func (k *kellySizerAdapter) Size(probability, equity float64) float64 {
	// Payoff ratio: prefer the realized avgWin/avgLoss from the learning
	// loop once we have trade history; fall back to the live stop-implied
	// ratio (e.g. −6%/+9% → W=1.5). The old W=1.0 default under-sized a
	// 1.5:1 payoff by ~3.6× at p=0.53.
	wlr := 1.0
	sl, tp := runtimeCfg.Snapshot().StopLossPct, runtimeCfg.Snapshot().TakeProfitPct
	if sl < 0 && tp > 0 {
		wlr = tp / math.Abs(sl)
	}
	if k.learning != nil {
		// ponytail: realized payoff from outcomes; W=1.0 when <5 trades
		if stats := k.learning.GetStats("default"); stats.Trades > 5 && stats.Expectancy > 0 {
			winRate := stats.WinRate
			if winRate > 0 && winRate < 1 {
				avgWin := stats.Expectancy / winRate
				avgLoss := stats.Expectancy / (1 - winRate)
				if avgWin > 0 && avgLoss > 0 {
					wlr = avgWin / avgLoss
				}
			}
		}
	}
	frac := k.kelly.Size("", probability, wlr, 0.0)
	notional := k.kelly.ComputeNotional(equity, frac)
	if notional <= 0 && frac > 0 {
		// No silent skips: log when Kelly wants a position but the
		// min_trade_size floor rejects it — the usual "why no trades?" cause.
		slog.Info("kelly skip: notional below min_trade_size",
			"notional", equity*frac, "min_trade_size", k.kelly.MinTradeSize(),
			"probability", probability, "frac", frac)
	}
	return notional
}

func envOr(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

// normalizePort ensures PORT has a leading colon for Go's net listener.
func normalizePort(p string) string {
	if p != "" && !strings.HasPrefix(p, ":") {
		return ":" + p
	}
	return p
}

//go:embed ui/*
var uiFS embed.FS

var (
	baseURL        string
	readKey        string
	readSecret     string
	rateLimiter    *rate_limiter.T212RateLimiter
	predictor      ml.Predictor
	metricsCol     *metrics.Collector
	positionsCache *cache.Cache
	httpClient     *http.Client
	cfg            Config
	circuitBreaker *CircuitBreaker
	t212Client     *t212.T212Client
	startTime      = time.Now()

	// SOTA intelligence stack
	store      *data.Store
	fetcher    *data.HistoryFetcher
	featureEng *data.FeatureEngine
	mlOrch     *mlservice.Orchestrator
	fastLoop   *brain.FastLoop
	autoExec   *brain.AutoExecutor
	universe   []string

	// modelQualityGate is shared read-only state updated by a background
	// retrain loop and read by request handlers + the auto-exec loop.
	// Guards: handlers build a fresh *RiskGates per request and attach the
	// current gate under this lock, so no gate state (e.g. SPY price/EMA)
	// can leak between concurrent requests.
	modelQualityMu sync.RWMutex
	modelQuality   *risk.ModelQualityGate
)

// currentModelQualityGate returns the latest AUC gate (nil when unknown),
// reading the shared state safely.
func currentModelQualityGate() *risk.ModelQualityGate {
	modelQualityMu.RLock()
	defer modelQualityMu.RUnlock()
	return modelQuality
}

func parseUniverse() []string {
	raw := envOr("TRADING_UNIVERSE", "AAPL,MSFT,GOOGL,AMZN,TSLA,NVDA,META,NFLX")
	return t212.NormalizeTickers(strings.Split(raw, ","))
}

func init() {
	cfg = LoadConfig()
	baseURL = cfg.T212BaseURL
	readKey = cfg.T212ReadKey
	readSecret = cfg.T212ReadSecret

	if readKey == "" || readSecret == "" {
		slog.Warn("T212_READ_KEY/T212_READ_SECRET not set — T212 API calls will fail")
	}

	rateLimiter = rate_limiter.NewT212RateLimiter()
	predictor = ml.NewStubPredictor()
	metricsCol = metrics.New()
	positionsCache = cache.New(time.Duration(cfg.CacheTTL) * time.Second)
	httpClient = http_client.NewPool(100, 10, 90*time.Second, 30*time.Second)
	circuitBreaker = NewCircuitBreaker(cfg.CircuitMaxErrors, cfg.CircuitDailyLoss, time.Duration(cfg.CircuitRecoverSec)*time.Second)

	t212Client = t212.NewT212Client(cfg.T212ReadKey, cfg.T212ReadSecret, cfg.T212BaseURL)
	slog.Info("initialized",
		"base_url", baseURL,
		"metrics_enabled", true,
		"cache_ttl_seconds", cfg.CacheTTL,
		"circuit_max_errors", cfg.CircuitMaxErrors,
		"paper_mode", cfg.PaperMode,
	)
}

// --- Middleware ---

func authMiddleware(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user, pass, ok := r.BasicAuth()
		if !ok || user != readKey || pass != readSecret {
			slog.Warn("unauthorized request", "remote", r.RemoteAddr, "path", r.URL.Path)
			w.Header().Set("WWW-Authenticate", `Basic realm="polyglot-trader"`)
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		h(w, r)
	}
}

func loggingMiddleware(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		h(w, r)
		slog.Info("request",
			"method", r.Method,
			"path", r.URL.Path,
			"duration_ms", time.Since(start).Milliseconds(),
			"remote", r.RemoteAddr,
		)
	}
}

func metricsMiddleware(c *metrics.Collector, h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		endpoint := metrics.SanitizeEndpoint(r.URL.Path)
		c.Inc(endpoint)
		start := time.Now()
		h(w, r)
		c.ObserveDuration(endpoint, time.Since(start))
	}
}

func validateTicker(t string) bool {
	if len(t) == 0 || len(t) > 10 {
		return false
	}
	for _, c := range t {
		if !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
			return false
		}
	}
	return true
}

// --- Request/Response types ---

type predictRequest struct {
	Ticker   string    `json:"ticker"`
	Features []float64 `json:"features"`
	Tickers  []string  `json:"tickers"` // optional: batch mode
}

type predictResponse struct {
	Prediction  ml.Prediction   `json:"prediction"`
	Predictions []ml.Prediction `json:"predictions,omitempty"`
}

type orderRequest struct {
	Scheme         string  `json:"scheme"`
	Ticker         string  `json:"ticker"`
	Side           string  `json:"side"`
	Quantity       float64 `json:"quantity"`
	LimitPrice     float64 `json:"limit_price"`
	MarketPrice    float64 `json:"market_price"`
	SpyPrice       float64 `json:"spy_price"`
	SpyEMA         float64 `json:"spy_ema"`
	PositionValue  float64 `json:"position_value"`
	PortfolioValue float64 `json:"portfolio_value"`
	Sector         string  `json:"sector"`
	LastTrade      string  `json:"last_trade"`
	FreeMargin     float64 `json:"free_margin"`
	DailyPnL       float64 `json:"daily_pnl"`
	SectorExposure float64 `json:"sector_exposure"`
	OpenPositions  int     `json:"open_positions"`
}

type tickRequest struct {
	Ticker         string    `json:"ticker"`
	Price          float64   `json:"price"`
	Volume         float64   `json:"volume"`
	Features       []float64 `json:"features"`
	SpyPrice       float64   `json:"spy_price"`
	SpyEMA         float64   `json:"spy_ema"`
	FreeMargin     float64   `json:"free_margin"`
	TotalEquity    float64   `json:"total_equity"`
	DailyPnL       float64   `json:"daily_pnl"`
	Sector         string    `json:"sector"`
	SectorExposure float64   `json:"sector_exposure"`
	OpenPositions  int       `json:"open_positions"`
}

type signalResponse struct {
	MLPrediction ml.Prediction       `json:"ml_prediction"`
	RiskResult   risk.GateResultFull `json:"risk_result"`
	Accepted     bool                `json:"accepted"`
}

type rateLimitResponse struct {
	Endpoint  string  `json:"endpoint"`
	Remaining float64 `json:"remaining"`
}

// --- Request/Response helpers ---

func authHeader() http.Header {
	credentials := readKey + ":" + readSecret
	encoded := base64.StdEncoding.EncodeToString([]byte(credentials))
	return http.Header{
		"Authorization": []string{"Basic " + encoded},
		"Accept":        []string{"application/json"},
	}
}

func handleJSON(w http.ResponseWriter, path string, params ...string) {
	url := baseURL + path
	if len(params) > 0 {
		url += "?" + strings.Join(params, "&")
	}

	req, _ := http.NewRequest("GET", url, nil)
	for k, v := range authHeader() {
		req.Header.Set(k, v[0])
	}

	resp, err := httpClient.Do(req)
	if err != nil {
		slog.Error("API call failed", "path", path, "error", err)
		http.Error(w, "API call failed", 500)
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		http.Error(w, "Failed to read response", 500)
		return
	}

	if resp.StatusCode != http.StatusOK {
		slog.Error("API returned error", "status", resp.StatusCode, "path", path, "body", string(body))
		http.Error(w, fmt.Sprintf("API returned %d", resp.StatusCode), resp.StatusCode)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(body)
}

// --- Endpoints ---

func handleHealth(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":      "ok",
		"component":   "polyglot-trader-t212",
		"base_url":    baseURL,
		"cb_state":    circuitBreaker.State(),
		"cb_stats":    circuitBreaker.Stats(),
		"shutdown":    IsShuttingDown(),
		"kill_active": killSwitch.IsActive(),
		"uptime_sec":  time.Since(startTime).Seconds(),
	})
}

func handleReady(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status": "ready",
		"checks": map[string]string{
			"rate_limiter":    "ok",
			"predictor":       "ok",
			"risk_gates":      "ok",
			"cache":           "ok",
			"circuit_breaker": "ok",
			"paper_trader":    "ok",
			"kill_switch":     "ok",
		},
	})
}

func handlePositions(w http.ResponseWriter, r *http.Request) {
	if cached, ok := positionsCache.Get("positions"); ok {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(cached.(string)))
		return
	}
	handleJSON(w, "/api/v0/equity/positions")
}

func handleOrders(w http.ResponseWriter, r *http.Request) {
	handleJSON(w, "/api/v0/equity/orders")
}

func handleQuotes(w http.ResponseWriter, r *http.Request) {
	http.Error(w, "quotes not implemented for read-only mode", 501)
}

func handleEquity(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(paperTrader.Portfolio())
}

// handleMLPredict handles single or batch ML predictions.
// Single: {"ticker": "AAPL", "features": [...]}
// Batch: {"tickers": ["AAPL", "TSLA"], "features": [...]}
func handleMLPredict(w http.ResponseWriter, r *http.Request) {
	if allowed, retryAfter := rateLimiter.Allow(rate_limiter.MLPredict, 1); !allowed {
		http.Error(w, fmt.Sprintf("rate limited — retry after %v", retryAfter), 429)
		return
	}

	var req predictRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", 400)
		return
	}

	w.Header().Set("Content-Type", "application/json")

	// Batch mode
	if len(req.Tickers) > 0 {
		if len(req.Tickers) > 10 {
			http.Error(w, "max 10 tickers per batch", 400)
			return
		}
		preds := make([]ml.Prediction, 0, len(req.Tickers))
		for _, ticker := range req.Tickers {
			if !validateTicker(ticker) {
				http.Error(w, fmt.Sprintf("ticker %q invalid", ticker), 400)
				return
			}
			fv := ml.FeatureVector{
				Ticker:    ticker,
				Features:  req.Features,
				Timestamp: time.Now(),
			}
			pred, err := predictor.Predict(fv)
			if err != nil {
				circuitBreaker.RecordFailure(cfg.CircuitMaxErrors, 0)
				slog.Error("ML prediction failed", "ticker", ticker, "error", err)
				http.Error(w, "prediction failed", 500)
				return
			}
			preds = append(preds, pred)
		}
		b, _ := json.Marshal(preds)
		w.Write([]byte(fmt.Sprintf(`{"predictions":%s}`, string(b))))
		return
	}

	// Single ticker mode
	if req.Ticker == "" || !validateTicker(req.Ticker) {
		http.Error(w, "ticker must be alphanumeric, 1-10 chars", 400)
		return
	}
	if len(req.Features) == 0 {
		http.Error(w, "features are required", 400)
		return
	}

	fv := ml.FeatureVector{
		Ticker:    req.Ticker,
		Features:  req.Features,
		Timestamp: time.Now(),
	}

	pred, err := predictor.Predict(fv)
	if err != nil {
		circuitBreaker.RecordFailure(cfg.CircuitMaxErrors, 0)
		slog.Error("ML prediction failed", "ticker", req.Ticker, "error", err)
		http.Error(w, "prediction failed", 500)
		return
	}
	circuitBreaker.RecordSuccess()

	b, _ := json.Marshal(pred)
	w.Write([]byte(fmt.Sprintf(`{"prediction":%s}`, string(b))))
}

func handleInstruments(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", 405)
		return
	}

	instruments := t212Client.GetInstruments()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(instruments)
}

func handleRiskGate(w http.ResponseWriter, r *http.Request) {
	if allowed, retryAfter := rateLimiter.Allow(rate_limiter.RiskGate, 1); !allowed {
		http.Error(w, fmt.Sprintf("rate limited — retry after %v", retryAfter), 429)
		return
	}

	var req orderRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", 400)
		return
	}

	if req.Ticker == "" || !validateTicker(req.Ticker) {
		http.Error(w, "ticker must be alphanumeric, 1-10 chars", 400)
		return
	}

	order := &risk.Order{
		Scheme:              req.Scheme,
		Ticker:              req.Ticker,
		Side:                risk.OrderSide(strings.ToUpper(req.Side)),
		Quantity:            req.Quantity,
		LimitPrice:          req.LimitPrice,
		MarketPrice:         req.MarketPrice,
		PositionValue:       req.PositionValue,
		TotalPortfolioValue: req.PortfolioValue,
		Sector:              req.Sector,
		DailyPnL:            req.DailyPnL,
		OpenPositions:       req.OpenPositions,
		SectorExposurePct:   req.SectorExposure,
	}

	if req.LastTrade != "" {
		if t, err := time.Parse(time.RFC3339, req.LastTrade); err == nil {
			order.LastTradeTime = &t
		}
	}

	// Build a fresh gate set per request so gate state (e.g. SPY price/EMA)
	// can't leak between concurrent requests. The AUC gate is the only shared
	// piece — read under lock via currentModelQualityGate().
	gates := risk.NewRiskGates()
	if mq := currentModelQualityGate(); mq != nil {
		gates.ModelQuality = mq
	}
	// Macro regime gate: use real SPY price/EMA when the caller supplies
	// them; otherwise leave the gate unset (auto-pass) rather than
	// comparing the ticker's own price against itself, which always
	// passed and silently disabled the bear-regime filter.
	if req.SpyPrice > 0 || req.SpyEMA > 0 {
		gates.MacroRegime = &risk.MacroRegimeGate{
			SpyPrice: req.SpyPrice,
			SpyEMA:   req.SpyEMA,
		}
	}
	if req.FreeMargin > 0 && req.PortfolioValue > 0 {
		gates.MarginFloor = &risk.MarginFloorGate{
			FreeMargin:  req.FreeMargin,
			TotalEquity: req.PortfolioValue,
			MinFloorPct: 0.15,
		}
	}
	if req.PortfolioValue > 0 {
		gates.MaxDrawdown = &risk.MaxDrawdownGate{
			DailyPnL:    req.DailyPnL,
			MaxLossPct:  0.05,
			TotalEquity: req.PortfolioValue,
		}
	}
	if req.Sector != "" {
		gates.AssetCorrelation = &risk.AssetCorrelationGate{
			SectorExposurePct: req.SectorExposure,
			MaxSectorPct:      40.0,
			Sector:            req.Sector,
		}
	}

	result := gates.Evaluate(order)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(result)
}

func handleSignal(w http.ResponseWriter, r *http.Request) {
	if allowed, retryAfter := rateLimiter.Allow(rate_limiter.Signal, 1); !allowed {
		http.Error(w, fmt.Sprintf("rate limited — retry after %v", retryAfter), 429)
		return
	}

	var req tickRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", 400)
		return
	}

	if req.Ticker == "" || !validateTicker(req.Ticker) {
		http.Error(w, "ticker must be alphanumeric, 1-10 chars", 400)
		return
	}

	fv := ml.FeatureVector{
		Ticker:    req.Ticker,
		Features:  req.Features,
		Timestamp: time.Now(),
	}
	pred, err := predictor.Predict(fv)
	if err != nil {
		circuitBreaker.RecordFailure(cfg.CircuitMaxErrors, req.DailyPnL)
		slog.Error("ML prediction failed", "ticker", req.Ticker, "error", err)
		http.Error(w, "prediction failed", 500)
		return
	}
	circuitBreaker.RecordSuccess()

	order := &risk.Order{
		Ticker:              req.Ticker,
		Side:                risk.OrderSide(pred.Signal),
		Quantity:            1,
		MarketPrice:         req.Price,
		PositionValue:       req.Price,
		TotalPortfolioValue: req.TotalEquity,
		Sector:              req.Sector,
		DailyPnL:            req.DailyPnL,
		OpenPositions:       req.OpenPositions,
		SectorExposurePct:   req.SectorExposure,
	}

	// Per-request gate set — see handleRiskGate. SPY fields 0 = no data,
	// which the MacroRegime gate treats as "allow".
	gates := risk.NewRiskGates()
	if mq := currentModelQualityGate(); mq != nil {
		gates.ModelQuality = mq
	}
	gates.MacroRegime = &risk.MacroRegimeGate{
		SpyPrice: req.SpyPrice,
		SpyEMA:   req.SpyEMA,
	}
	if req.FreeMargin > 0 && req.TotalEquity > 0 {
		gates.MarginFloor = &risk.MarginFloorGate{
			FreeMargin:  req.FreeMargin,
			TotalEquity: req.TotalEquity,
			MinFloorPct: 0.15,
		}
	}
	if req.TotalEquity > 0 {
		gates.MaxDrawdown = &risk.MaxDrawdownGate{
			DailyPnL:    req.DailyPnL,
			MaxLossPct:  0.05,
			TotalEquity: req.TotalEquity,
		}
	}
	if req.Sector != "" {
		gates.AssetCorrelation = &risk.AssetCorrelationGate{
			SectorExposurePct: req.SectorExposure,
			MaxSectorPct:      40.0,
			Sector:            req.Sector,
		}
	}

	riskResult := gates.Evaluate(order)

	resp := signalResponse{
		MLPrediction: pred,
		RiskResult:   riskResult,
		Accepted:     riskResult.Passed,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

// autoRiskGateCheck runs the 11-gate risk matrix on an auto BUY decision.
// Returns true if the order should proceed. Uses the fast loop's live SPY
// data for the macro regime gate, and the paper portfolio for portfolio data.
// SELLs bypass (always allow exits).
func autoRiskGateCheck(d brain.TradeDecision) bool {
	pf := paperTrader.Portfolio()
	// Estimate the max position notional (Kelly caps at 10%/position).
	// Conservative: ensures even at max sizing we stay under the static
	// MaxRiskPerOrder backstop (12%).
	posVal := pf.TotalValue * 0.10
	if v := getEnvF64("MAX_DOLLARS_PER_ORDER", 0); v > 0 && v < posVal {
		posVal = v
	}
	order := &risk.Order{
		Ticker:              d.Ticker,
		Side:                risk.Buy,
		MarketPrice:         d.Price,
		PositionValue:       posVal,
		TotalPortfolioValue: pf.TotalValue,
		DailyPnL:            pf.DailyPnL,
		OpenPositions:       len(pf.Positions),
	}

	// Per-request gate set — fresh each call so no state leaks into the
	// next decision or the HTTP handlers. Macro regime uses live SPY data.
	gates := risk.NewRiskGates()
	if mq := currentModelQualityGate(); mq != nil {
		gates.ModelQuality = mq
	}
	// Macro regime gate: use fastLoop's live SPY data (not a placeholder).
	var spyPrice, spyEMA float64
	if fastLoop != nil {
		spyPrice = fastLoop.GetSpyPrice()
		spyEMA = fastLoop.GetSpyEMA()
	}
	gates.MacroRegime = &risk.MacroRegimeGate{
		SpyPrice: spyPrice,
		SpyEMA:   spyEMA,
		// ponytail: the decision layer already applied the ±0.5% hysteresis
		// regime (spyBullish) — feeding the latched state here keeps the two
		// macro gates from diverging on a bps-of-noise flip.
		Bear: fastLoop != nil && fastLoop.GetSpyBelowSMA(),
	}

	// MaxDrawdown gate: today's P&L vs equity
	if pf.TotalValue > 0 {
		gates.MaxDrawdown = &risk.MaxDrawdownGate{
			DailyPnL:    pf.DailyPnL,
			MaxLossPct:  0.05,
			TotalEquity: pf.TotalValue,
		}
		// Margin floor: a long-only paper account's "free margin" is its cash.
		// Block a new BUY once the account is >85% deployed (cash below 15%
		// of equity) so the autonomous loop can't fully invest and lose the
		// ability to scale. The two HTTP risk-gate sites already enforce this;
		// the auto path (the only path that actually trades) was the one that
		// didn't — that's the gap this closes.
		gates.MarginFloor = &risk.MarginFloorGate{
			FreeMargin:  pf.Cash,
			TotalEquity: pf.TotalValue,
			MinFloorPct: 0.15,
		}
	}

	result := gates.Evaluate(order)
	if !result.Passed {
		slog.Info("auto risk gate blocked buy",
			"ticker", d.Ticker,
			"gate", result.FailedGate,
			"reason", result.FailReason,
		)
		return false
	}
	return true
}

// updateModelQualityGate refreshes the AUC gate from current model metrics
// and wires it into the fast loop so weak models can't open positions.
//
// ponytail: MIN_VALID_AUC env (default 0.53). The 200-tree/2y LightGBM
// model lands at AUC ~0.543 — slightly above random; the old 0.55 bar
// blocked every BUY forever (0 trades in 4 days), starving the outcome
// data that's supposed to improve it. 0.53 lets the paper loop trade while
// still gating truly dead models.
func updateModelQualityGate() {
	minAUC := minValidAUC
	if fastLoop != nil {
		fastLoop.SetModelQualityGate(func() bool {
			if mlOrch == nil {
				return true
			}
			m := mlOrch.GetMetrics()
			if m == nil {
				return true // no metrics yet — allow (model may still be training)
			}
			if auc, ok := m["auc_val"]; ok {
				// Static floor: don't trade a sub-floor model (0.53).
				if auc < minAUC {
					return false
				}
				// Dynamic tightening: once the model has a real trade
				// history (>=20), it must also be profitable (winrate>0.5 &&
				// rolling sharpe>0.5, already encoded in IsQualified).
				// Before 20 trades the loop keeps trading to accumulate
				// the outcome data that improves the model — the old
				// static 0.55 bar starved the loop of exactly that.
				if k := fastLoop.GetLearning(); k != nil {
					champ := fastLoop.GetChampionChallenger().GetChampion()
					if s := k.GetStats(champ); s.Trades >= 20 && !s.IsQualified {
						slog.Debug("model quality gate: not qualified on history",
							"model", champ, "trades", s.Trades,
							"winrate", s.WinRate, "sharpe", s.Sharpe)
						return false
					}
				}
				return true
			}
			return true
		})
		// Wire the AUC gate into champion promotion too.
		fastLoop.GetChampionChallenger().SetAUCGate(minAUC, func(string) float64 {
			if mlOrch == nil {
				return 0
			}
			m := mlOrch.GetMetrics()
			if m == nil {
				return 0
			}
			return m["auc_val"]
		})
	}
	if mlOrch == nil {
		return
	}
	metrics := mlOrch.GetMetrics()
	if metrics == nil {
		return
	}
	if auc, ok := metrics["auc_val"]; ok {
		// Write to the shared model-quality state under lock; each request
		// copies it into its own per-request gate set.
		modelQualityMu.Lock()
		modelQuality = &risk.ModelQualityGate{
			ModelAUC:    auc,
			MinValidAUC: minAUC,
			Source:      "validation",
		}
		modelQualityMu.Unlock()
		slog.Info("model quality gate updated", "auc_val", auc, "min", minAUC)
	}
}

// startMonitoringLoops launches background monitors:
// - position reconciliation (paper vs live) every 6h
// - dead-loop liveness check every 1h (keyed to last decision cycle)
func startMonitoringLoops(ctx context.Context) {
	// Position reconciliation: paper vs live T212 positions
	go func() {
		ticker := time.NewTicker(6 * time.Hour)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				reconcilePositions(cfg.PaperMode)
			}
		}
	}()

	// No-trade staleness: warn if no trades in > 24h (dead loop detection)
	go func() {
		ticker := time.NewTicker(1 * time.Hour)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				// Dead-loop liveness: the loop is dead when it stops producing decision
				// cycles, not when it stops filling. Key off lastLoopActivity() (last
				// decision cycle, falling back to last trade) so a live loop holding
				// already-open positions (no new fills) is not flagged dead after 24h.
				lastActive := lastLoopActivity()
				if !lastActive.IsZero() && time.Since(lastActive) > 24*time.Hour {
					slog.Warn("dead-loop alert: no decision cycles in > 24h", "last_active", lastActive.Format(time.RFC3339))
				}
			}
		}
	}()
}

// reconcilePositions compares paper positions with live T212 positions and logs discrepancies.
// In paper mode there is no live T212 account to reconcile against, so it skips the
// live-position fetch (which returns 401 on read-only creds and logged a spurious WARN).
func reconcilePositions(paperMode bool) {
	if paperMode {
		return
	}

	livePositions, err := t212Client.GetPositions()
	if err != nil {
		slog.Warn("reconciliation: failed to fetch live positions", "error", err)
		return
	}

	liveTickers := make(map[string]bool)
	for _, p := range livePositions {
		if inst, ok := p["instrument"].(string); ok {
			liveTickers[inst] = true
		}
	}

	paperPositions := paperTrader.Portfolio().Positions
	paperTickers := make(map[string]bool)
	for _, p := range paperPositions {
		paperTickers[p.Ticker] = true
	}

	// Check for positions in live but not in paper
	for inst := range liveTickers {
		if !paperTickers[inst] {
			slog.Warn("position discrepancy: live position not in paper", "instrument", inst)
		}
	}

	// Check for positions in paper but not in live
	for inst := range paperTickers {
		if !liveTickers[inst] {
			slog.Warn("position discrepancy: paper position not in live", "instrument", inst)
		}
	}

	slog.Info("position reconciliation complete", "live_count", len(livePositions), "paper_count", len(paperPositions))
}

// --- SOTA intelligence endpoints ---

func handleSotaStatus(w http.ResponseWriter, r *http.Request) {
	if fastLoop == nil {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"status":"disabled","reason":"sota stack not initialized"}`))
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":            "active",
		"universe":          universe,
		"model_loaded":      mlOrch.HasModel(),
		"model_metrics":     mlOrch.GetMetrics(),
		"champion":          fastLoop.GetChampionChallenger().GetChampion(),
		"challenger":        fastLoop.GetChampionChallenger().GetChallenger(),
		"model_performance": fastLoop.GetLearning().GetAllStats(),
		"risk":              fastLoop.GetRisk().GetCurrentRisk(),
		"last_cycle":        fastLoop.GetLastCycle(),
		"open_trades":       autoExec.GetOpenTrades(),
	})
}

func handleSotaDecisions(w http.ResponseWriter, r *http.Request) {
	if fastLoop == nil {
		http.Error(w, "sota stack not initialized", 503)
		return
	}
	limit := 20
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			limit = n
		}
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(fastLoop.GetDecisions(limit))
}

func handleSotaTrain(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	if mlOrch == nil || store == nil {
		http.Error(w, "sota stack not initialized", 503)
		return
	}

	orch := mlOrch
	go func() {
		if orch == nil {
			return
		}
		result, err := orch.TrainModel()
		if err != nil {
			slog.Error("model training failed", "error", err)
			return
		}
		slog.Info("model training complete",
			"train_accuracy", result.Metrics["train_accuracy"],
			"val_accuracy", result.Metrics["validation_accuracy"],
			"n_estimators", result.Metrics["n_estimators"],
		)
	}()

	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(`{"status":"training_started"}`))
}

func handleSotaCloseAll(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	if autoExec == nil {
		http.Error(w, "sota stack not initialized", 503)
		return
	}
	autoExec.CloseAll()
	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(`{"status":"all_auto_trades_closed"}`))
}

func handleRateLimitStatus(w http.ResponseWriter, r *http.Request) {
	endpoints := []rate_limiter.EndpointType{
		rate_limiter.Global,
		rate_limiter.Positions,
		rate_limiter.Orders,
		rate_limiter.MLPredict,
		rate_limiter.RiskGate,
		rate_limiter.Signal,
	}
	results := make([]rateLimitResponse, 0, len(endpoints))
	for _, ep := range endpoints {
		results = append(results, rateLimitResponse{
			Endpoint:  strconv.Itoa(int(ep)),
			Remaining: rateLimiter.Remaining(ep),
		})
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(results)
}

// --- Router ---

func getContentType(path string) string {
	switch {
	case strings.HasSuffix(path, ".html"):
		return "text/html; charset=utf-8"
	case strings.HasSuffix(path, ".css"):
		return "text/css"
	case strings.HasSuffix(path, ".js"):
		return "application/javascript"
	case strings.HasSuffix(path, ".png"):
		return "image/png"
	case strings.HasSuffix(path, ".jpg") || strings.HasSuffix(path, ".jpeg"):
		return "image/jpeg"
	case strings.HasSuffix(path, ".gif"):
		return "image/gif"
	case strings.HasSuffix(path, ".ico"):
		return "image/x-icon"
	default:
		return "application/octet-stream"
	}
}

func main() {
	slog.Info("starting polyglot-trader-t212", "port", port)

	// Seed runtime config from env, push to live components (nil-safe)
	runtimeCfg.LoadEnv()
	runtimeCfg.LoadFile() // saved UI/API edits override env (if present)
	runtimeCfg.Apply()

	// Initialize SOTA intelligence stack (non-fatal — degrades to proxy mode)
	universe = parseUniverse()
	t212Client.SetUniverse(universe)
	dataDir := envOr("DATA_DIR", "/app/data")
	if err := os.MkdirAll(dataDir, 0755); err != nil {
		slog.Warn("data dir not writable, falling back to /tmp", "error", err)
		dataDir = "/tmp/polyglot-data"
		os.MkdirAll(dataDir, 0755)
	}
	// Load the persisted paper portfolio BEFORE the sota stack inits so
	// SyncFromBroker below reads the real (durable) positions, not the
	// empty in-memory default. If this runs after SyncFromBroker, every
	// restart leaves openTrades empty and the next eligible BUY double-buys
	// a position the broker already holds (the NVDA 0.4211 = 0.2106×2 bug).
	SetPaperDir(dataDir)
	paperTrader.LoadState()
	paperTrader.LoadTrades() // durable trade log (source for realized-outcome replay)

	if st, err := data.NewStore(dataDir); err != nil {
		slog.Error("data store init failed — running in proxy-only mode", "error", err)
	} else {
		store = st
		fetcher = data.NewHistoryFetcher()
		featureEng = data.NewFeatureEngine()
		modelDir := dataDir + "/models"
		os.MkdirAll(modelDir, 0755)
		mlOrch = mlservice.NewOrchestrator(modelDir, dataDir, mlservice.DefaultConfig())
		if err := mlOrch.LoadModel(); err != nil {
			slog.Warn("model load failed (will train fresh)", "error", err)
		}
		fastLoop = brain.NewFastLoop(store, fetcher, featureEng, mlOrch, universe, 60*time.Second)
		autoExec = brain.NewAutoExecutor(&paperBrokerAdapter{}, fastLoop.GetLearning(), fastLoop.GetChampionChallenger())
		// Kelly sizing: probability-aware, quarter-Kelly safety margin,
		// capped at 10% per position, 80% total exposure, min notional live-editable
		kellySizer = risk.NewQuarterKellySizer(10, 80, runtimeCfg.Snapshot().MinTradeSize)
		autoExec.SetSizer(&kellySizerAdapter{
			kelly:    kellySizer,
			learning: fastLoop.GetLearning(),
		})
		if d := getEnvF64("TRADING_DAILY_BUDGET", 0); d > 0 || runtimeCfg.Snapshot().WeeklyBudget > 0 || runtimeCfg.Snapshot().MonthlyBudget > 0 {
			rc := runtimeCfg.Snapshot()
			autoExec.SetBudgets(rc.DailyBudget, rc.WeeklyBudget, rc.MonthlyBudget)
			slog.Info("trading budgets set", "daily", rc.DailyBudget, "weekly", rc.WeeklyBudget, "monthly", rc.MonthlyBudget)
		}
		if v := getEnvF64("MAX_DOLLARS_PER_ORDER", 0); v > 0 {
			autoExec.SetMaxOrderValue(v)
			slog.Info("max order value set", "amount", v)
		}
		autoExec.SetStopTakeLoss(-getEnvF64("TRADING_STOP_LOSS_PCT", 6), getEnvF64("TRADING_TAKE_PROFIT_PCT", 9))
		// Time stop: close zombie positions held longer than MAX_HOLD_DAYS.
		if days := int(getEnvF64("TRADING_MAX_HOLD_DAYS", 5)); days > 0 {
			autoExec.SetMaxHoldDays(days)
		}
		// Crash recovery: broker state is durable, openTrades map is not.
		// Rebuild so a restart never re-issues a duplicate BUY or leaves
		// a phantom entry for a position already flattened by a kill switch.
		autoExec.SyncFromBroker(&paperBrokerAdapter{})

		// The learning loop (promotion + drift stats) is in-memory and dies
		// with the process, but the durable paper_trades.json survives. Re-
		// feed its realized round-trips so a restart doesn't starve the
		// champion/challenger promotion gate back to 0 (it needs 20 closed
		// outcomes to fire; at ~1-2 trades/day that's weeks of progress that
		// a single deploy was previously wiping). Keyed on the current
		// champion, matching how the live recordOutcome path records it.
		if outcomes := paperTrader.RealizedOutcomes(); len(outcomes) > 0 {
			model := fastLoop.GetChampionChallenger().GetChampion()
			for _, o := range outcomes {
				fastLoop.GetLearning().RecordOutcome(brain.TradeOutcome{
					Ticker: o.Ticker,
					Side:   "BUY",
					Model:  model,
					PnL:    o.PnL,
				})
			}
			slog.Info("replayed realized outcomes into learning loop", "count", len(outcomes), "model", model)
		}
		slog.Info("sota stack initialized",
			"universe", universe,
			"model_loaded", mlOrch.HasModel(),
		)
	}

	// Fetch historical data + build training features in background
	if store != nil && fetcher != nil {
		go func() {
			time.Sleep(2 * time.Second)
			if err := fetcher.FetchUniverse(universe, "2y", store); err != nil {
				slog.Error("universe fetch failed", "error", err)
				return
			}
			slog.Info("universe data loaded")
			if err := store.BuildTrainingData(universe, featureEng); err != nil {
				slog.Error("training data build failed", "error", err)
				return
			}
			slog.Info("training data ready")

			// Refresh F1 gate after initial training
			if !mlOrch.HasModel() {
				slog.Info("no model present — running initial training")
				if res, err := mlOrch.TrainModel(); err != nil {
					slog.Error("initial training failed", "error", err)
				} else {
					slog.Info("initial training complete", "auc_val", res.Metrics["auc_val"], "n_train", res.Metrics["n_train"])
					updateModelQualityGate()
				}
			} else {
				updateModelQualityGate()
			}
		}()

		// Wire drift-triggered retrain (max once per 6h)
		fastLoop.SetRetrainCallback(func() {
			slog.Info("retrain triggered (drift)")
			if _, err := mlOrch.TrainModel(); err != nil {
				slog.Error("retrain failed", "error", err)
			} else {
				updateModelQualityGate()
			}
		})
		// Wire drift outcomes: every closed paper trade feeds the drift detector
		if fastLoop.GetLearning() != nil {
			fastLoop.GetLearning().SetDriftHook(func(model string, win bool) {
				fastLoop.GetDrift().RecordOutcome(model, win)
			})
		}
		// Wire the executor: decisions now actually trade (paper)
		if os.Getenv("SOTA_EXECUTE") != "false" {
			fastLoop.SetExecuteCallback(func(d brain.TradeDecision) {
				// Master switch: off = decisions logged but never traded
				if !runtimeCfg.AutoExecuteEnabled() {
					return
				}
				// Respect kill switch: never open NEW positions when halted
				if killSwitch.IsActive() && d.Action == "BUY" {
					slog.Warn("buy blocked: kill switch active", "ticker", d.Ticker)
					return
				}
				// Wire 11-gate risk matrix into the auto path (BUYs only).
				// SELLs bypass — we always want to be able to exit.
				if d.Action == "BUY" {
					if !autoRiskGateCheck(d) {
						return
					}
				}
				autoExec.ExecuteDecision(d)
			})
			slog.Info("sota auto-execution enabled")
		} else {
			slog.Info("sota auto-execution disabled via SOTA_EXECUTE=false")
		}
		// Model quality gate: block trades when validation F1 is below threshold
		updateModelQualityGate()
	}

	// Start background loops
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	if fastLoop != nil {
		go fastLoop.Run(ctx)
		go autoExec.Start(ctx, 30*time.Second)
	}

	// Monitoring loops: position reconciliation + no-trade staleness
	startMonitoringLoops(ctx)

	// SLOW LOOP: hourly retrain + data refresh (every 1 hour)
	if store != nil && mlOrch != nil {
		go func() {
			ticker := time.NewTicker(1 * time.Hour)
			defer ticker.Stop()
			for {
				select {
				case <-ctx.Done():
					return
				case <-ticker.C:
					slog.Info("slow loop: nightly refresh starting")
					if err := fetcher.FetchUniverse(universe, "2y", store); err != nil {
						slog.Error("slow loop: fetch failed", "error", err)
						continue
					}
					if err := store.BuildTrainingData(universe, featureEng); err != nil {
						slog.Error("slow loop: feature build failed", "error", err)
						continue
					}
					if res, err := mlOrch.TrainModel(); err != nil {
						slog.Error("slow loop: retrain failed", "error", err)
					} else {
						slog.Info("slow loop: retrain complete", "auc_val", res.Metrics["auc_val"])
					}
				}
			}
		}()
	}

	mux := http.NewServeMux()

	// Health and readiness (no auth required)
	mux.HandleFunc("/health", handleHealth)
	mux.HandleFunc("/ready", handleReady)

	// Kill switch (POST /api/kill-switch — no auth needed for safety)
	mux.HandleFunc("/api/kill-switch", loggingMiddleware(handleKillSwitch))

	// T212 instruments listing
	mux.HandleFunc("/api/instruments", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleInstruments))))

	// Paper trading
	mux.HandleFunc("/api/paper/portfolio", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handlePaperPortfolio))))
	mux.HandleFunc("/api/paper/execute", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handlePaperExecuteTrade))))
	mux.HandleFunc("/api/paper/signals", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handlePaperSignals))))
	mux.HandleFunc("/api/paper/positions", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handlePaperPositions))))
	mux.HandleFunc("/api/paper/trades", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handlePaperTrades))))
	mux.HandleFunc("/api/system/status", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleSystemStatus))))

	// Existing endpoints: logging -> metrics -> auth -> handler
	mux.HandleFunc("/api/positions", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handlePositions))))
	mux.HandleFunc("/api/orders", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleOrders))))
	mux.HandleFunc("/api/quotes", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleQuotes))))
	mux.HandleFunc("/api/equity", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleEquity))))

	mux.HandleFunc("/api/ml/predict", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleMLPredict))))
	mux.HandleFunc("/api/risk/gate", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleRiskGate))))
	mux.HandleFunc("/api/config", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleConfig))))
	mux.HandleFunc("/api/signal", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleSignal))))
	mux.HandleFunc("/api/ratelimit/status", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleRateLimitStatus))))
	mux.HandleFunc("/api/sota/status", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleSotaStatus))))
	mux.HandleFunc("/api/sota/decisions", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleSotaDecisions))))
	mux.HandleFunc("/api/sota/train", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleSotaTrain))))
	mux.HandleFunc("/api/sota/close-all", metricsMiddleware(metricsCol, loggingMiddleware(authMiddleware(handleSotaCloseAll))))

	// Metrics (no auth)
	mux.Handle("/metrics", metricsCol)

	// Serve embedded UI at root — explicitly handle root vs other paths
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// Root URL → serve index.html
		if r.URL.Path == "/" {
			w.Header().Set("Content-Type", "text/html")
			f, err := uiFS.Open("ui/index.html")
			if err != nil {
				http.Error(w, "UI not found", http.StatusNotFound)
				return
			}
			defer f.Close()
			io.Copy(w, f)
			return
		}

		// Static assets (CSS, JS, images) — strip / to access files from ui/
		http.StripPrefix("/", http.FileServer(http.FS(uiFS))).ServeHTTP(w, r)
	})

	slog.Info("routes configured", "metrics_path", "/metrics", "ready_path", "/ready")

	srv := &http.Server{
		Addr:         port,
		Handler:      mux,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	// Graceful shutdown on SIGINT/SIGTERM
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		sig := <-sigCh
		slog.Warn("shutdown signal received", "signal", sig)
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		if err := srv.Shutdown(ctx); err != nil {
			slog.Error("server shutdown failed", "error", err)
		}
		slog.Info("server stopped cleanly")
	}()

	if err := srv.ListenAndServe(); err != nil {
		slog.Error("server failed", "error", err)
		os.Exit(1)
	}
}
