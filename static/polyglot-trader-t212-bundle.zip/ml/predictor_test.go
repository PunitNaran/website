package ml

import (
	"testing"
	"time"
)

func TestStubPredictor_EmptyFeatures(t *testing.T) {
	p := NewStubPredictor()
	pred, err := p.Predict(FeatureVector{Ticker: "AAPL", Features: []float64{}, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if pred.Signal != "HOLD" {
		t.Errorf("expected HOLD for empty features, got %s", pred.Signal)
	}
	if pred.Score != 0.5 {
		t.Errorf("expected score 0.5, got %f", pred.Score)
	}
	if pred.Ticker != "AAPL" {
		t.Errorf("expected ticker AAPL, got %s", pred.Ticker)
	}
}

func TestStubPredictor_BuySignal(t *testing.T) {
	p := NewStubPredictor()
	pred, err := p.Predict(FeatureVector{Ticker: "GOOG", Features: []float64{0.8, 0.9, 0.7}, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if pred.Signal != "BUY" {
		t.Errorf("expected BUY for avg > 0.6, got %s", pred.Signal)
	}
	if pred.Ticker != "GOOG" {
		t.Errorf("expected ticker GOOG, got %s", pred.Ticker)
	}
}

func TestStubPredictor_SellSignal(t *testing.T) {
	p := NewStubPredictor()
	pred, err := p.Predict(FeatureVector{Ticker: "MSFT", Features: []float64{0.2, 0.1, 0.3}, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if pred.Signal != "SELL" {
		t.Errorf("expected SELL for avg < 0.4, got %s", pred.Signal)
	}
}

func TestStubPredictor_HoldNearNeutral(t *testing.T) {
	p := NewStubPredictor()
	pred, err := p.Predict(FeatureVector{Ticker: "TSLA", Features: []float64{0.5, 0.5, 0.5}, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if pred.Signal != "HOLD" {
		t.Errorf("expected HOLD for avg exactly 0.5, got %s", pred.Signal)
	}
}

func TestStubPredictor_NegativeFeatures(t *testing.T) {
	p := NewStubPredictor()
	pred, err := p.Predict(FeatureVector{Ticker: "NFLX", Features: []float64{-0.5, -0.3, -0.1}, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if pred.Ticker != "NFLX" {
		t.Errorf("expected ticker NFLX, got %s", pred.Ticker)
	}
}

func TestStubPredictor_PositiveFeatures(t *testing.T) {
	p := NewStubPredictor()
	pred, err := p.Predict(FeatureVector{Ticker: "AMZN", Features: []float64{1.0, 1.0, 1.0}, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if pred.Ticker != "AMZN" {
		t.Errorf("expected ticker AMZN, got %s", pred.Ticker)
	}
	if pred.Score > 1.0 {
		t.Errorf("score %f exceeded 1.0 clamp", pred.Score)
	}
}

func TestStubPredictor_FeaturesMatch(t *testing.T) {
	p := NewStubPredictor()
	features := []float64{0.3, 0.7, 0.2, 0.8}
	pred, err := p.Predict(FeatureVector{Ticker: "META", Features: features, Timestamp: time.Now()})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(pred.Features) != len(features) {
		t.Errorf("expected %d features, got %d", len(features), len(pred.Features))
	}
	for i, f := range features {
		if pred.Features[i] != f {
			t.Errorf("feature[%d]: expected %f, got %f", i, f, pred.Features[i])
		}
	}
}

func TestStubPredictor_PredictedAtIsSet(t *testing.T) {
	p := NewStubPredictor()
	before := time.Now()
	pred, _ := p.Predict(FeatureVector{Ticker: "NVDA", Features: []float64{0.5}, Timestamp: time.Now()})
	after := time.Now()
	if pred.PredictedAt.Before(before) || pred.PredictedAt.After(after) {
		t.Error("PredictedAt not within expected range")
	}
}

func TestStubPredictor_SingleFeature(t *testing.T) {
	p := NewStubPredictor()
	pred, _ := p.Predict(FeatureVector{Ticker: "BABA", Features: []float64{0.9}, Timestamp: time.Now()})
	if pred.Signal != "BUY" {
		t.Errorf("single high feature should give BUY, got %s", pred.Signal)
	}
}

func TestStubPredictor_SingleFeatureLow(t *testing.T) {
	p := NewStubPredictor()
	pred, _ := p.Predict(FeatureVector{Ticker: "INTC", Features: []float64{0.1}, Timestamp: time.Now()})
	if pred.Signal != "SELL" {
		t.Errorf("single low feature should give SELL, got %s", pred.Signal)
	}
}

func TestStubPredictor_JustAboveThreshold(t *testing.T) {
	p := NewStubPredictor()
	// avg = 0.55, |0.55-0.5| = 0.05 < 0.1 → HOLD
	pred, _ := p.Predict(FeatureVector{Ticker: "AMD", Features: []float64{0.55, 0.55}, Timestamp: time.Now()})
	if pred.Signal != "HOLD" {
		t.Errorf("expected HOLD for avg near 0.5, got %s", pred.Signal)
	}
}

func TestStubPredictor_JustBelowThreshold(t *testing.T) {
	p := NewStubPredictor()
	// avg = 0.44, |0.44-0.5| = 0.06 < 0.1 → HOLD
	pred, _ := p.Predict(FeatureVector{Ticker: "CRM", Features: []float64{0.44, 0.44}, Timestamp: time.Now()})
	if pred.Signal != "HOLD" {
		t.Errorf("expected HOLD for avg near 0.5, got %s", pred.Signal)
	}
}

func BenchmarkStubPredictor(b *testing.B) {
	p := NewStubPredictor()
	fv := FeatureVector{Ticker: "AAPL", Features: []float64{0.5, 0.6, 0.7, 0.8}, Timestamp: time.Now()}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		p.Predict(fv)
	}
}

func BenchmarkStubPredictor_EmptyFeatures(b *testing.B) {
	p := NewStubPredictor()
	fv := FeatureVector{Ticker: "AAPL", Features: []float64{}, Timestamp: time.Now()}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		p.Predict(fv)
	}
}
