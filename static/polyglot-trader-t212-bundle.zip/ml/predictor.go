// Package ml provides a predictor interface for ML-based signal generation.
// The current implementation is a stub — when the Rust ML core is linked
// (via cgo or external gRPC), replace Predict() with the real inference call.
package ml

import (
	"math"
	"time"
)

// FeatureVector is the input shape for ML predictions.
// Features are numeric indicators (e.g. RSI, MACD, volume, price change).
type FeatureVector struct {
	Ticker    string    `json:"ticker"`
	Features  []float64 `json:"features"`
	Timestamp time.Time `json:"timestamp"`
}

// Prediction is the ML model output.
type Prediction struct {
	Ticker      string    `json:"ticker"`
	Signal      string    `json:"signal"` // "BUY", "SELL", "HOLD"
	Score       float64   `json:"score"`  // confidence 0-1
	Features    []float64 `json:"features"`
	PredictedAt time.Time `json:"predicted_at"`
}

// Predictor is the interface the service calls. Implementations can be:
//   - a stub (current)
//   - a cgo bridge to the Rust ML core
//   - a gRPC client to an external inference service
type Predictor interface {
	Predict(fv FeatureVector) (Prediction, error)
}

// StubPredictor is the default predictor for development/testing.
// It returns a deterministic "HOLD" with score 0.5 based on feature average.
// Replace with the real ML core when available.
type StubPredictor struct{}

func NewStubPredictor() *StubPredictor { return &StubPredictor{} }

func (p *StubPredictor) Predict(fv FeatureVector) (Prediction, error) {
	if len(fv.Features) == 0 {
		return Prediction{Ticker: fv.Ticker, Signal: "HOLD", Score: 0.5, PredictedAt: time.Now()}, nil
	}
	sum := 0.0
	for _, f := range fv.Features {
		sum += f
	}
	avg := sum / float64(len(fv.Features))
	// Clamp to 0-1
	if avg < 0 {
		avg = 0
	}
	if avg > 1 {
		avg = 1
	}
	// Simple heuristic: avg > 0.5 → BUY, < 0.5 → SELL
	signal := "HOLD"
	if math.Abs(avg-0.5) > 0.1 {
		if avg > 0.5 {
			signal = "BUY"
		} else {
			signal = "SELL"
		}
	}
	return Prediction{
		Ticker:      fv.Ticker,
		Signal:      signal,
		Score:       math.Abs(avg - 0.5),
		Features:    fv.Features,
		PredictedAt: time.Now(),
	}, nil
}
