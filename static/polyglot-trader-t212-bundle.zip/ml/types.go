// Package ml provides shared data types for strategies and the fast loop.
// SignalType, Signal are new types not yet in predictor.go.
package ml

import "time"

// SignalType represents the direction of a trading signal.
type SignalType string

const (
	Long  SignalType = "LONG"
	Short SignalType = "SHORT"
)

// Signal is a trading signal from a strategy or ML model.
type Signal struct {
	Ticker      string                 `json:"ticker"`
	Signal      SignalType             `json:"signal"`
	Confidence  float64                `json:"confidence"`
	Strategy    string                 `json:"strategy_id"`
	Features    map[string]interface{} `json:"features,omitempty"`
	Probability float64                `json:"lightgbm_probability,omitempty"`
	CreatedAt   time.Time              `json:"created_at"`
}
