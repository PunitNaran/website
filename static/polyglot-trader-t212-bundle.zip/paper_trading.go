package main

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/punit/polyglot-trader-t212/t212"
)

// PaperPosition represents a simulated position.
type PaperPosition struct {
	Ticker       string    `json:"ticker"`
	Side         string    `json:"side"`
	Quantity     float64   `json:"quantity"`
	EntryPrice   float64   `json:"entry_price"`
	CurrentPrice float64   `json:"current_price"`
	PnL          float64   `json:"pnl"`
	Reason       string    `json:"reason,omitempty"`
	OpenedAt     time.Time `json:"opened_at"`
}

// PaperPortfolio is the simulated portfolio state.
type PaperPortfolio struct {
	Cash        float64         `json:"cash"`
	Positions   []PaperPosition `json:"positions"`
	TotalValue  float64         `json:"total_value"`
	DailyPnL    float64         `json:"daily_pnl"`
	PnLDayKey   string          `json:"pnl_day_key"` // calendar day the DailyPnL accumulates in (resets on rollover)
	TradesCount int             `json:"trades_count"`
	UpdatedAt   time.Time       `json:"updated_at"`
	LastTradeAt time.Time       `json:"last_trade_at"`
}

// PaperTrader manages simulated trading.
type PaperTrader struct {
	mu        sync.Mutex
	portfolio PaperPortfolio
	tradesLog []PaperTrade
	// quoteFn fetches live prices for mark-to-market in Portfolio().
	// Defaults to t212.GetQuoteYahoo; override in tests to stay offline.
	quoteFn func(ticker string) (float64, error)
}

// setQuoteFn sets the live-quote fetcher (nil → default Yahoo).
func (pt *PaperTrader) setQuoteFn(fn func(string) (float64, error)) {
	pt.quoteFn = fn
}

func (pt *PaperTrader) liveQuote(ticker string) (float64, error) {
	if pt.quoteFn != nil {
		return pt.quoteFn(ticker)
	}
	return t212.GetQuoteYahoo(ticker)
}

// PaperTrade is a record of a simulated trade.
type PaperTrade struct {
	Ticker      string    `json:"ticker"`
	Side        string    `json:"side"`
	Quantity    float64   `json:"quantity"`
	Price       float64   `json:"price"`
	Timestamp   time.Time `json:"timestamp"`
	Reason      string    `json:"reason"`
	FillDetails string    `json:"fill_details,omitempty"`
}

var (
	paperTrader = &PaperTrader{
		portfolio: PaperPortfolio{
			// init() runs after cfg = LoadConfig() in the same package
			Cash:        getEnvF64("PAPER_INITIAL_CASH", 1000),
			TradesCount: 0,
			UpdatedAt:   time.Now(),
		},
	}
)

// ResetPaper clears the account back to the configured initial cash and
// wipes open positions. The persisted state file is rewritten immediately.
func ResetPaper() {
	cash := getEnvF64("PAPER_INITIAL_CASH", 1000)
	paperTrader.mu.Lock()
	paperTrader.portfolio = PaperPortfolio{
		Cash:      cash,
		UpdatedAt: time.Now(),
	}
	paperTrader.tradesLog = nil
	paperTrader.saveStateLocked()
	paperTrader.mu.Unlock()
	slog.Info("paper portfolio reset", "cash", cash)
}

// rolloverDailyPnLLocked rolls the realized accumulator to the current
// calendar day IN PLACE. Must be called before folding new realized P&L:
// a stale PnLDayKey (e.g. process slept across midnight) would otherwise
// make a sale add to yesterday's total — which the next read then rolls
// away, silently discarding today's realized P&L.
func (pt *PaperTrader) rolloverDailyPnLLocked() {
	today := time.Now().Format("2006-01-02")
	if pt.portfolio.PnLDayKey != today {
		pt.portfolio.PnLDayKey = today
		pt.portfolio.DailyPnL = 0
	}
}

// ExecuteTrade simulates buying or selling a position.
func (pt *PaperTrader) ExecuteTrade(ticker string, side string, quantity float64, price float64, reason string) error {
	side = strings.ToUpper(side)
	pt.mu.Lock()
	defer pt.mu.Unlock()

	pt.rolloverDailyPnLLocked()
	switch side {
	case "BUY":
		cost := quantity * price
		if cost > pt.portfolio.Cash {
			return fmt.Errorf("insufficient cash: need $%.2f, have $%.2f", cost, pt.portfolio.Cash)
		}
		pt.portfolio.Cash -= cost

		found := false
		for i, p := range pt.portfolio.Positions {
			if p.Ticker == ticker {
				pt.portfolio.Positions[i].Quantity += quantity
				pt.portfolio.Positions[i].EntryPrice = (p.EntryPrice*p.Quantity + price*quantity) / (p.Quantity + quantity)
				pt.portfolio.Positions[i].CurrentPrice = price
				pt.portfolio.Positions[i].Reason = reason
				found = true
				break
			}
		}
		if !found {
			pt.portfolio.Positions = append(pt.portfolio.Positions, PaperPosition{
				Ticker:       ticker,
				Side:         "BUY",
				Quantity:     quantity,
				EntryPrice:   price,
				CurrentPrice: price,
				Reason:       reason,
				OpenedAt:     time.Now(),
			})
		}

	case "SELL":
		found := false
		for i, p := range pt.portfolio.Positions {
			if p.Ticker == ticker {
				if p.Quantity < quantity {
					return fmt.Errorf("insufficient position: have %.2f, want to sell %.2f", p.Quantity, quantity)
				}
				// Realized P&L of the closed portion folds into the daily
				// accumulator before the position shrinks/disappears.
				pt.portfolio.DailyPnL += (price - p.EntryPrice) * quantity
				p.Quantity -= quantity
				if p.Quantity == 0 {
					pt.portfolio.Positions = append(pt.portfolio.Positions[:i], pt.portfolio.Positions[i+1:]...)
				} else {
					// Mark remaining shares to the new price (fixes a
					// pre-existing bug: CurrentPrice was lost on partial sells).
					p.CurrentPrice = price
					pt.portfolio.Positions[i] = p
				}
				pt.portfolio.Cash += quantity * price
				found = true
				break
			}
		}
		if !found {
			return fmt.Errorf("no position for ticker %s", ticker)
		}
	}

	trade := PaperTrade{
		Ticker:      ticker,
		Side:        side,
		Quantity:    quantity,
		Price:       price,
		Timestamp:   time.Now(),
		Reason:      reason,
		FillDetails: fmt.Sprintf("intended_qty=%.4f,executed_qty=%.4f,intended_price=%.4f,executed_price=%.4f", quantity, quantity, price, price),
	}
	pt.tradesLog = append(pt.tradesLog, trade)
	pt.portfolio.TradesCount++
	pt.portfolio.UpdatedAt = time.Now()
	pt.portfolio.LastTradeAt = time.Now()

	totalValue := pt.portfolio.Cash
	for _, p := range pt.portfolio.Positions {
		totalValue += p.Quantity * p.CurrentPrice
	}
	pt.portfolio.TotalValue = totalValue

	// Persist realized-only: DailyPnL holds only closed-trade P&L here.
	// withDailyPnL (unrealized mark-to-market) is applied at read time only —
	// persisting it would double-count on the next sale's realized +=.
	pt.writeTradesFile()
	pt.saveStateLocked()

	slog.Info("paper_trade",
		"ticker", ticker,
		"side", side,
		"quantity", quantity,
		"price", price,
		"cash", pt.portfolio.Cash,
		"total_value", totalValue,
	)

	return nil
}

// Portfolio returns the current paper portfolio state with live prices.
func (pt *PaperTrader) Portfolio() PaperPortfolio {
	pt.mu.Lock()
	defer pt.mu.Unlock()
	pf := pt.portfolio
	// ponytail: refresh positions with live quotes so equity/PnL is real,
	// not frozen at entry. Falls back to stored price if Yahoo fails.
	for i, pos := range pf.Positions {
		live, err := pt.liveQuote(pos.Ticker)
		if err == nil && live > 0 {
			pf.Positions[i].CurrentPrice = live
			pf.Positions[i].PnL = (live - pos.EntryPrice) * pos.Quantity
		}
	}
	total := pf.Cash
	for _, pos := range pf.Positions {
		total += pos.Quantity * pos.CurrentPrice
	}
	pf.TotalValue = total
	return withDailyPnL(pf)
}

// withDailyPnL returns a copy of pf with DailyPnL presented as the current
// calendar day's total: realized (already in pf.DailyPnL, accumulated by
// ExecuteTrade/CloseAllPositions on each sale) + unrealized mark-to-market.
// Pure function — the caller's struct is not mutated, so the persisted
// accumulator stays realized-only (no double counting on later sales).
//
// Math: DailyPnL(day D) = Σ_closed (P_exit − P_entry)·q + Σ_open (P_now − P_entry)·q
// The realized accumulator rolls to zero when the calendar day changes.
func withDailyPnL(pf PaperPortfolio) PaperPortfolio {
	today := time.Now().Format("2006-01-02")
	if pf.PnLDayKey != today {
		pf.PnLDayKey = today
		pf.DailyPnL = 0 // new day: realized accumulator starts fresh
	}
	for _, p := range pf.Positions {
		pf.DailyPnL += (p.CurrentPrice - p.EntryPrice) * p.Quantity
	}
	return pf
}

// saveStateLocked persists the portfolio atomically. Callers hold pt.mu.
var (
	paperDir   = "."
	stateFile    = "paper_portfolio.json"
	tradesFile   = "paper_trades.json"
)

// SetPaperDir repoints the persistent paper-account files to dir.
// Must be called before LoadState in production. Tests rely on the default
// "." (CWD-relative) — isolateStateDir's chdir to a temp dir is enough.
func SetPaperDir(dir string) {
	paperDir = dir
	stateFile = filepath.Join(dir, "paper_portfolio.json")
	tradesFile = filepath.Join(dir, "paper_trades.json")
}

// atomicWrite writes data to path via tmp-file+fsync+rename so a crash or
// power cut mid-write never leaves a torn/corrupt state file. The fsync
// flushes the new data to stable storage BEFORE the rename makes it visible.
func atomicWrite(path string, data []byte, perm os.FileMode) error {
	tmp := path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, perm)
	if err != nil {
		return err
	}
	if _, err := f.Write(data); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}
	if err := f.Close(); err != nil {
		os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		os.Remove(tmp)
		return err
	}
	// Best-effort: flush the directory entry so the rename itself is durable.
	if d, err := os.Open(path); err == nil {
		d.Sync()
		d.Close()
	}
	return nil
}

// saveStateLocked persists the portfolio atomically. Callers hold pt.mu.
func (pt *PaperTrader) saveStateLocked() {
	data, err := json.MarshalIndent(pt.portfolio, "", "  ")
	if err != nil {
		slog.Warn("paper_trading: failed to marshal state", "error", err)
		return
	}
	if err := atomicWrite(stateFile, data, 0644); err != nil {
		slog.Warn("paper_trading: failed to save state", "error", err)
	}
}

// LoadState loads the portfolio from paper_portfolio.json if it exists.
func (pt *PaperTrader) LoadState() {
	pt.mu.Lock()
	defer pt.mu.Unlock()

	data, err := os.ReadFile(stateFile)
	if err != nil {
		return // no state file yet — use defaults
	}
	if err := json.Unmarshal(data, &pt.portfolio); err != nil {
		slog.Warn("paper_trading: failed to load state, using defaults", "error", err)
		return
	}
	slog.Info("paper_trading: state loaded", "cash", pt.portfolio.Cash, "positions", len(pt.portfolio.Positions), "last_trade", pt.portfolio.LastTradeAt.Format(time.RFC3339))
}

// RealizedOutcome is a closed auto round-trip (BUY→SELL) with its realized
// P&L. The durable trade log is the source; the in-memory learning loop is
// not, so this is how a restart re-feeds it (see RealizedOutcomes).
type RealizedOutcome struct {
	Ticker string
	PnL    float64
	Time   time.Time
}

// LoadTrades reads the durable paper_trades.json back into memory so the
// trade log (and /api/paper/trades) survives a pod restart. Call after
// SetPaperDir; before it, tradesFile points at the CWD-relative default.
func (pt *PaperTrader) LoadTrades() {
	pt.mu.Lock()
	defer pt.mu.Unlock()

	data, err := os.ReadFile(tradesFile)
	if err != nil {
		return // no trades file yet
	}
	if err := json.Unmarshal(data, &pt.tradesLog); err != nil {
		slog.Warn("paper_trading: failed to load trades, keeping in-memory log", "error", err)
		return
	}
}

// RealizedOutcomes pairs the auto-trade BUYs and SELLs in the durable log
// into closed round-trips and returns each one's realized P&L, in log
// order. Only "auto:" trades count — the learning loop only tracks those.
// The auto path holds at most one position per ticker at a time (it won't
// buy a ticker it already holds), so a per-ticker open-quantity match is
// exact: a SELL realizes (sellPrice - entryPrice) * matchedQty against the
// open buy, mirroring recordOutcome's own P&L math.
// ponytail: no open-cost tracking across partial sells is needed because
// the bot never pyramids a position; a partial sell keeps the original
// entry, so the match stays exact.
func (pt *PaperTrader) RealizedOutcomes() []RealizedOutcome {
	pt.mu.Lock()
	defer pt.mu.Unlock()

	open := map[string]float64{}  // ticker -> open auto-buy quantity
	entry := map[string]float64{} // ticker -> entry price of the open buy
	var out []RealizedOutcome
	for _, t := range pt.tradesLog {
		if !strings.HasPrefix(t.Reason, "auto:") {
			continue
		}
		switch t.Side {
		case "BUY":
			open[t.Ticker] += t.Quantity
			entry[t.Ticker] = t.Price
		case "SELL":
			q := t.Quantity
			if open[t.Ticker] > 0 {
				if q > open[t.Ticker] {
					q = open[t.Ticker]
				}
				out = append(out, RealizedOutcome{
					Ticker: t.Ticker,
					PnL:    (t.Price - entry[t.Ticker]) * q,
					Time:     t.Timestamp,
				})
				open[t.Ticker] -= q
			}
		}
	}
	return out
}

// LastTradeAt returns the time of the last executed trade.
func (pt *PaperTrader) LastTradeAt() time.Time {
	pt.mu.Lock()
	defer pt.mu.Unlock()
	return pt.portfolio.LastTradeAt
}

// CloseAllPositions sells all positions at current price (kill switch).
func (pt *PaperTrader) CloseAllPositions() {
	pt.mu.Lock()
	defer pt.mu.Unlock()
	pt.rolloverDailyPnLLocked()
	for _, p := range pt.portfolio.Positions {
		pt.portfolio.Cash += p.Quantity * p.CurrentPrice
		// Realized P&L of each closed position folds into the daily accumulator.
		pt.portfolio.DailyPnL += (p.CurrentPrice - p.EntryPrice) * p.Quantity
		trade := PaperTrade{
			Ticker:      p.Ticker,
			Side:        "SELL",
			Quantity:    p.Quantity,
			Price:       p.CurrentPrice,
			Timestamp:   time.Now(),
			Reason:      "kill_switch_close",
			FillDetails: fmt.Sprintf("intended_qty=%.4f,executed_qty=%.4f,intended_price=%.4f,executed_price=%.4f", p.Quantity, p.Quantity, p.CurrentPrice, p.CurrentPrice),
		}
		pt.tradesLog = append(pt.tradesLog, trade)
	}
	pt.portfolio.Positions = nil
	pt.portfolio.TradesCount++
	pt.portfolio.UpdatedAt = time.Now()
	pt.portfolio.LastTradeAt = time.Now()
	pt.writeTradesFile()
	pt.saveStateLocked()
	slog.Info("paper_trading: all positions closed via kill switch",
		"cash", pt.portfolio.Cash,
	)
}

// writeTradesFile persists the full trade log atomically (tmp+fsync+rename),
// so a crash mid-write never leaves a torn paper_trades.json.
func (pt *PaperTrader) writeTradesFile() {
	data, err := json.MarshalIndent(pt.tradesLog, "", "  ")
	if err != nil {
		slog.Error("paper_trading: failed to marshal trades", "error", err)
		return
	}
	data = append(data, '\n')
	if err := atomicWrite(tradesFile, data, 0644); err != nil {
		slog.Error("paper_trading: failed to write trades file", "path", tradesFile, "error", err)
	}
}

// handlePaperPortfolio is the HTTP handler for GET /api/paper/portfolio.
func handlePaperPortfolio(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(paperTrader.Portfolio())
}

// handlePaperExecuteTrade is the HTTP handler for POST /api/paper/execute.
func handlePaperExecuteTrade(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		Ticker   string  `json:"ticker"`
		Side     string  `json:"side"`
		Quantity float64 `json:"quantity"`
		Price    float64 `json:"price"`
		Reason   string  `json:"reason"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", 400)
		return
	}

	if req.Ticker == "" || req.Side == "" || req.Quantity <= 0 {
		http.Error(w, "ticker, side, and quantity are required", 400)
		return
	}

	// Fetch live price from T212 if not provided
	if req.Price == 0 {
		quotes, err := t212Client.GetQuotes([]string{req.Ticker})
		if err == nil {
			if quote, ok := quotes[req.Ticker]; ok {
				if priceMap, ok := quote.(map[string]interface{}); ok {
					if p, ok := priceMap["price"].(float64); ok {
						req.Price = p
					} else if p, ok := priceMap["last"].(float64); ok {
						req.Price = p
					}
				}
			}
		}
		// Fallback: Yahoo Finance (no auth)
		if req.Price == 0 {
			if p, yerr := t212.GetQuoteYahoo(req.Ticker); yerr == nil {
				req.Price = p
			}
		}
		if req.Price == 0 {
			http.Error(w, "price not available for ticker", 500)
			return
		}
	}

	err := paperTrader.ExecuteTrade(req.Ticker, req.Side, req.Quantity, req.Price, req.Reason)
	if err != nil {
		http.Error(w, err.Error(), 400)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "ok", "price": fmt.Sprintf("%.4f", req.Price)})
}

// handlePaperSignals returns the recent real ML/risk signals for paper trading.
func handlePaperSignals(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	if fastLoop == nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"signals": []interface{}{},
		})
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"signals": fastLoop.GetDecisions(10),
	})
}

// handlePaperPositions returns all open paper positions.
func handlePaperPositions(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(paperTrader.Portfolio().Positions)
}

// handlePaperTrades returns the full trade log.
func handlePaperTrades(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	paperTrader.mu.Lock()
	trades := paperTrader.tradesLog
	paperTrader.mu.Unlock()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(trades)
}

// lastLoopActivity returns the most recent time the trading loop did
// meaningful work: the last decision cycle when an auto loop is running, else
// the last executed trade (manual-only / loop disabled). This is the correct
// liveness signal for "is the loop alive": a live loop cycling every 60s but
// holding already-open positions (no new fills) is NOT a dead loop.
// ponytail: one shared liveness source for the status handler AND the monitor
// loop — previously both measured last-fill and a live loop got flagged dead
// after 24h of no new trades.
func lastLoopActivity() time.Time {
	if fastLoop != nil {
		if c := fastLoop.GetLastCycle(); !c.IsZero() {
			return c
		}
	}
	return paperTrader.LastTradeAt()
}

// handleSystemStatus returns the current system status. The "stale"/dead-loop
// flag is keyed to the last decision cycle (loop liveness), not the last fill —
// a live loop holding open positions (no new trades) must not read as dead.
func handleSystemStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	lastTrade := paperTrader.LastTradeAt()
	lastActive := lastLoopActivity()
	noCycleHours := 0.0
	stale := false
	if !lastActive.IsZero() {
		noCycleHours = time.Since(lastActive).Hours()
		stale = noCycleHours > 24
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":         "ok",
		"uptime_sec":     time.Since(startTime).Seconds(),
		"kill_switch":    killSwitch.IsActive(),
		"last_trade_at":  lastTrade.Format(time.RFC3339),
		"no_cycle_hours": noCycleHours,
		"stale":          stale,
		"paper_mode":     true,
		"positions_open": len(paperTrader.Portfolio().Positions),
	})
}
