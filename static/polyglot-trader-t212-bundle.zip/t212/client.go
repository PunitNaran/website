package t212

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"
)

// T212Client is the Go implementation of the Trading212 API client.
// All endpoints use the /equity/ prefix as required by the API.

type T212Client struct {
	baseURL    string
	apiKey     string
	apiSecret  string
	httpClient *http.Client
	authHeader string
	universe   []string
}

func NewT212Client(apiKey, apiSecret string, baseURL string) *T212Client {
	if baseURL == "" {
		baseURL = "https://api.trading212.com"
	}
	creds := base64.StdEncoding.EncodeToString([]byte(fmt.Sprintf("%s:%s", apiKey, apiSecret)))
	return &T212Client{
		baseURL:    baseURL,
		apiKey:     apiKey,
		apiSecret:  apiSecret,
		httpClient: &http.Client{Timeout: 10 * time.Second},
		authHeader: fmt.Sprintf("Basic %s", creds),
	}
}

// SetUniverse configures the tradable tickers used by GetInstruments.
func (c *T212Client) SetUniverse(tickers []string) {
	c.universe = NormalizeTickers(tickers)
}

func (c *T212Client) GetPositions() ([]map[string]interface{}, error) {
	url := fmt.Sprintf("%s/api/v0/equity/positions", c.baseURL)
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", c.authHeader)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("T212Client.GetPositions: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("T212Client.GetPositions: status %d", resp.StatusCode)
	}

	var data []map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, fmt.Errorf("T212Client.GetPositions: decode: %w", err)
	}
	return data, nil
}

func (c *T212Client) GetOrders(status string) ([]map[string]interface{}, error) {
	url := fmt.Sprintf("%s/api/v0/equity/orders", c.baseURL)
	if status != "" {
		url += "?status=" + status
	}
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", c.authHeader)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("T212Client.GetOrders: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("T212Client.GetOrders: status %d", resp.StatusCode)
	}

	var data []map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, fmt.Errorf("T212Client.GetOrders: decode: %w", err)
	}
	return data, nil
}

func (c *T212Client) SubmitOrder(scheme string, ticker string, side string, quantity float64, limitPrice float64) (map[string]interface{}, error) {
	url := fmt.Sprintf("%s/api/v0/equity/orders", c.baseURL)
	payload := map[string]interface{}{
		"accountScheme": scheme,
		"ticker":        ticker,
		"side":          side,
		"quantity":      quantity,
		"limitPrice":    limitPrice,
	}

	jsonPayload, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("T212Client.SubmitOrder: marshal: %w", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonPayload))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", c.authHeader)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("T212Client.SubmitOrder: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		return nil, fmt.Errorf("T212Client.SubmitOrder: status %d", resp.StatusCode)
	}

	var data map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, fmt.Errorf("T212Client.SubmitOrder: decode: %w", err)
	}
	return data, nil
}

func (c *T212Client) DeleteOrder(orderID string) error {
	url := fmt.Sprintf("%s/api/v0/equity/orders/%s", c.baseURL, orderID)
	req, err := http.NewRequest("DELETE", url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", c.authHeader)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("T212Client.DeleteOrder: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("T212Client.DeleteOrder: status %d", resp.StatusCode)
	}
	return nil
}

// GetQuoteYahoo fetches the current price for a single ticker via Yahoo Finance (no auth).
var yahooBaseURL = "https://query1.finance.yahoo.com" // ponytail: override in tests

// ponytail: shared client reuses TCP/TLS (per-call clients burned the 429
// budget). Single-flight dedupes concurrent reads of the same ticker on
// cache-TTL expiry, so a 10-name universe = 1 Yahoo call, not N.
var yahooHTTP = &http.Client{Timeout: 10 * time.Second}

var quoteCache = struct {
	mu       sync.Mutex
	prices   map[string]quoteEntry
	inflight map[string]chan struct{}
}{prices: map[string]quoteEntry{}, inflight: map[string]chan struct{}{}}

const quoteTTL = 30 * time.Second

type quoteEntry struct {
	price float64
	at    time.Time
}

func GetQuoteYahoo(ticker string) (float64, error) {
	quoteCache.mu.Lock()
	if e, ok := quoteCache.prices[ticker]; ok && time.Since(e.at) < quoteTTL {
		quoteCache.mu.Unlock()
		return e.price, nil
	}
	// A fetch for this ticker is already in flight — wait for it.
	if ch, ok := quoteCache.inflight[ticker]; ok {
		quoteCache.mu.Unlock()
		<-ch
		quoteCache.mu.Lock()
		if e, ok := quoteCache.prices[ticker]; ok {
			p := e.price
			quoteCache.mu.Unlock()
			return p, nil
		}
		quoteCache.mu.Unlock()
		return 0, fmt.Errorf("yahoo: %s in-flight, retry", ticker)
	}
	// We are the fetcher for this ticker.
	ch := make(chan struct{})
	quoteCache.inflight[ticker] = ch
	quoteCache.mu.Unlock()

	price, err := fetchYahooQuote(ticker)
	quoteCache.mu.Lock()
	delete(quoteCache.inflight, ticker)
	if err == nil {
		quoteCache.prices[ticker] = quoteEntry{price: price, at: time.Now()}
	}
	quoteCache.mu.Unlock()
	close(ch)
	return price, err
}

func fetchYahooQuote(ticker string) (float64, error) {
	url := yahooBaseURL + "/v8/finance/chart/" + ticker + "?interval=1d&range=1d"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return 0, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0")
	resp, err := yahooHTTP.Do(req)
	if err != nil {
		return 0, fmt.Errorf("yahoo fetch: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return 0, fmt.Errorf("yahoo status %d", resp.StatusCode)
	}

	var data map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return 0, fmt.Errorf("yahoo decode: %w", err)
	}
	result, ok := data["chart"].(map[string]interface{})["result"].([]interface{})
	if !ok || len(result) == 0 {
		return 0, fmt.Errorf("yahoo: no result for %s", ticker)
	}
	meta := result[0].(map[string]interface{})["meta"].(map[string]interface{})
	price, ok := meta["regularMarketPrice"].(float64)
	if !ok || price == 0 {
		return 0, fmt.Errorf("yahoo: no price for %s", ticker)
	}
	return price, nil
}

func (c *T212Client) GetQuotes(tickers []string) (map[string]interface{}, error) {
	url := fmt.Sprintf("%s/api/v0/equity/quotes", c.baseURL)
	symbols := strings.Join(tickers, ",")
	url += "?symbols=" + symbols

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", c.authHeader)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("T212Client.GetQuotes: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("T212Client.GetQuotes: status %d", resp.StatusCode)
	}

	var data map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, fmt.Errorf("T212Client.GetQuotes: decode: %w", err)
	}
	return data, nil
}

func (c *T212Client) Close() error {
	c.httpClient.CloseIdleConnections()
	return nil
}

// GetInstruments returns the tradable instruments — driven by the client's
// universe (TRADING_UNIVERSE) rather than a hardcoded list, so the UI picker
// offers exactly the tickers the bot trades. Falls back to a default set when
// no universe is configured.
func (c *T212Client) GetInstruments() []map[string]interface{} {
	universe := c.universe
	if len(universe) == 0 {
		universe = []string{"AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "NVDA", "META", "NFLX"}
	}
	out := make([]map[string]interface{}, 0, len(universe))
	for _, t := range universe {
		out = append(out, map[string]interface{}{"ticker": t, "name": t})
	}
	return out
}

// NormalizeTickers upper-cases, trims, dedupes, and drops empty tickers.
func NormalizeTickers(raw []string) []string {
	seen := map[string]bool{}
	out := make([]string, 0, len(raw))
	for _, p := range raw {
		t := strings.ToUpper(strings.TrimSpace(p))
		if t == "" || seen[t] {
			continue
		}
		seen[t] = true
		out = append(out, t)
	}
	return out
}
