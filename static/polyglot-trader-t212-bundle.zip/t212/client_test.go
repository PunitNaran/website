package t212

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestNewT212Client_DefaultBaseURL(t *testing.T) {
	c := NewT212Client("key", "secret", "")
	if c.baseURL != "https://api.trading212.com" {
		t.Errorf("expected default base URL, got %s", c.baseURL)
	}
}

func TestNewT212Client_CustomBaseURL(t *testing.T) {
	c := NewT212Client("key", "secret", "https://custom.api.com")
	if c.baseURL != "https://custom.api.com" {
		t.Errorf("expected custom URL, got %s", c.baseURL)
	}
}

func TestNewT212Client_AuthHeader(t *testing.T) {
	c := NewT212Client("mykey", "mysecret", "")
	if c.authHeader == "" {
		t.Error("expected non-empty auth header")
	}
	if len(c.authHeader) < 6 || c.authHeader[:6] != "Basic " {
		t.Errorf("expected Basic auth prefix, got %s", c.authHeader)
	}
}

func TestGetPositions_Success(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/v0/equity/positions" {
			t.Errorf("unexpected path: %s", r.URL.Path)
		}
		if r.Header.Get("Authorization") == "" {
			t.Error("expected auth header")
		}
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode([]map[string]interface{}{
			{"ticker": "AAPL", "quantity": 10},
		})
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	positions, err := c.GetPositions()
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(positions) != 1 {
		t.Errorf("expected 1 position, got %d", len(positions))
	}
}

func TestGetPositions_Error(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.GetPositions()
	if err == nil {
		t.Error("expected error for 500 status")
	}
}

func TestGetPositions_DecodeError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("not json"))
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.GetPositions()
	if err == nil {
		t.Error("expected decode error")
	}
}

func TestGetOrders_Success(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/v0/equity/orders" {
			t.Errorf("unexpected path: %s", r.URL.Path)
		}
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode([]map[string]interface{}{
			{"id": "123", "status": "FILLED"},
		})
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	orders, err := c.GetOrders("")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(orders) != 1 {
		t.Errorf("expected 1 order, got %d", len(orders))
	}
}

func TestGetOrders_WithStatus(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("status") != "PENDING" {
			t.Errorf("expected status=PENDING, got %s", r.URL.Query().Get("status"))
		}
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode([]map[string]interface{}{})
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.GetOrders("PENDING")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestGetOrders_Error(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusForbidden)
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.GetOrders("")
	if err == nil {
		t.Error("expected error for 403 status")
	}
}

func TestSubmitOrder_Success(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			t.Errorf("expected POST, got %s", r.Method)
		}
		if r.Header.Get("Content-Type") != "application/json" {
			t.Errorf("expected application/json, got %s", r.Header.Get("Content-Type"))
		}
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"id":     "order-123",
			"status": "PENDING",
		})
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	result, err := c.SubmitOrder("ISA", "AAPL", "BUY", 10, 150.0)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result["id"] != "order-123" {
		t.Errorf("expected id 'order-123', got %v", result["id"])
	}
}

func TestSubmitOrder_DecodeError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte("not json"))
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.SubmitOrder("ISA", "AAPL", "BUY", 10, 150.0)
	if err == nil {
		t.Error("expected decode error")
	}
}

func TestSubmitOrder_WrongStatus(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusBadRequest)
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.SubmitOrder("ISA", "AAPL", "BUY", 10, 150.0)
	if err == nil {
		t.Error("expected error for non-201 status")
	}
}

func TestDeleteOrder_Success(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "DELETE" {
			t.Errorf("expected DELETE, got %s", r.Method)
		}
		if r.URL.Path != "/api/v0/equity/orders/order-123" {
			t.Errorf("unexpected path: %s", r.URL.Path)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	err := c.DeleteOrder("order-123")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestDeleteOrder_Error(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	err := c.DeleteOrder("order-123")
	if err == nil {
		t.Error("expected error for 404")
	}
}

func TestGetQuotes_Success(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("symbols") != "AAPL,GOOG" {
			t.Errorf("expected symbols=AAPL,GOOG, got %s", r.URL.Query().Get("symbols"))
		}
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"AAPL": map[string]interface{}{"price": 150.0},
		})
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	quotes, err := c.GetQuotes([]string{"AAPL", "GOOG"})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if quotes["AAPL"] == nil {
		t.Error("expected AAPL in quotes")
	}
}

func TestGetQuotes_Error(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusServiceUnavailable)
	}))
	defer server.Close()

	c := NewT212Client("key", "secret", server.URL)
	_, err := c.GetQuotes([]string{"AAPL"})
	if err == nil {
		t.Error("expected error for 503")
	}
}

func TestGetQuoteYahoo_Success(t *testing.T) {
	orig := yahooBaseURL
	defer func() { yahooBaseURL = orig }()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("User-Agent") == "" {
			t.Error("expected User-Agent header")
		}
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"chart": map[string]interface{}{
				"result": []map[string]interface{}{
					{"meta": map[string]interface{}{"regularMarketPrice": 215.50}},
				},
			},
		})
	}))
	defer server.Close()
	quoteCache.mu.Lock()
	quoteCache.prices = map[string]quoteEntry{}
	quoteCache.mu.Unlock()
	yahooBaseURL = server.URL

	price, err := GetQuoteYahoo("AAPL")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if price != 215.50 {
		t.Errorf("expected 215.50, got %f", price)
	}
}

func TestGetQuoteYahoo_Error(t *testing.T) {
	orig := yahooBaseURL
	defer func() { yahooBaseURL = orig }()

	quoteCache.mu.Lock()
	quoteCache.prices = map[string]quoteEntry{}
	quoteCache.mu.Unlock()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer server.Close()
	yahooBaseURL = server.URL

	_, err := GetQuoteYahoo("AAPL")
	if err == nil {
		t.Error("expected error for 500")
	}
}

func TestClose(t *testing.T) {
	c := NewT212Client("key", "secret", "https://api.trading212.com")
	err := c.Close()
	if err != nil {
		t.Errorf("expected no error from Close(), got %v", err)
	}
}

// GetInstruments should reflect the live universe, not a stale hardcoded list.
func TestGetInstruments_UniverseDriven(t *testing.T) {
	c := NewT212Client("key", "secret", "https://api.trading212.com")
	c.SetUniverse([]string{"aapl", "msft ", "msft", ""})
	got := c.GetInstruments()
	if len(got) != 2 {
		t.Fatalf("expected 2 deduped instruments, got %d: %v", len(got), got)
	}
	if got[0]["ticker"] != "AAPL" || got[1]["ticker"] != "MSFT" {
		t.Errorf("instruments = %v", got)
	}
}

// GetInstruments with no universe falls back to the default set (non-empty).
func TestGetInstruments_Default(t *testing.T) {
	c := NewT212Client("key", "secret", "https://api.trading212.com")
	got := c.GetInstruments()
	if len(got) == 0 {
		t.Fatal("expected non-empty default instruments")
	}
}

// NormalizeTickers upper-cases, trims, dedupes, drops empties — in order.
func TestNormalizeTickers(t *testing.T) {
	got := NormalizeTickers([]string{"aapl", " AAPL ", "msft", "", "MSFT"})
	want := []string{"AAPL", "MSFT"}
	if len(got) != len(want) {
		t.Fatalf("got %v, want %v", got, want)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("got %v, want %v", got, want)
		}
	}
}

// Concurrency: N goroutines racing for the same expired ticker must collapse
// to a single Yahoo fetch (single-flight), not N fetches.
func TestGetQuoteYahoo_SingleFlight(t *testing.T) {
	quoteCache.mu.Lock()
	quoteCache.prices = map[string]quoteEntry{}
	quoteCache.inflight = map[string]chan struct{}{}
	quoteCache.mu.Unlock()

	var hits int64
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt64(&hits, 1)
		time.Sleep(50 * time.Millisecond) // force overlap of concurrent fetches
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"chart": map[string]interface{}{"result": []map[string]interface{}{{
				"meta": map[string]interface{}{"regularMarketPrice": 200.0, "currency": "USD"},
			}}},
		})
	}))
	defer srv.Close()
	orig := yahooBaseURL
	yahooBaseURL = srv.URL
	defer func() { yahooBaseURL = orig }()

	const n = 10
	var wg sync.WaitGroup
	errs := make([]error, n)
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			_, errs[i] = GetQuoteYahoo("TESTFLIGHT")
		}(i)
	}
	wg.Wait()
	for i, e := range errs {
		if e != nil {
			t.Fatalf("goroutine %d error: %v", i, e)
		}
	}
	if got := atomic.LoadInt64(&hits); got != 1 {
		t.Fatalf("expected exactly 1 yahoo fetch (single-flight), got %d", got)
	}
}

// After the first fetch the price is cached — a second call within the TTL
// must NOT hit Yahoo again.
func TestGetQuoteYahoo_CacheReused(t *testing.T) {
	quoteCache.mu.Lock()
	quoteCache.prices = map[string]quoteEntry{}
	quoteCache.inflight = map[string]chan struct{}{}
	quoteCache.mu.Unlock()

	var hits int64
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt64(&hits, 1)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"chart": map[string]interface{}{"result": []map[string]interface{}{{
				"meta": map[string]interface{}{"regularMarketPrice": 123.45, "currency": "USD"},
			}}},
		})
	}))
	defer srv.Close()
	orig := yahooBaseURL
	yahooBaseURL = srv.URL
	defer func() { yahooBaseURL = orig }()

	p1, err := GetQuoteYahoo("CACHED")
	if err != nil {
		t.Fatalf("first fetch: %v", err)
	}
	if _, err = GetQuoteYahoo("CACHED"); err != nil {
		t.Fatalf("second fetch: %v", err)
	}
	if p1 != 123.45 {
		t.Errorf("price = %v, want 123.45", p1)
	}
	if got := atomic.LoadInt64(&hits); got != 1 {
		t.Fatalf("expected 1 fetch (cached on 2nd), got %d", got)
	}
}

// A failed in-flight fetch must be retryable — not poisoned in the cache.
func TestGetQuoteYahoo_FailureRetryable(t *testing.T) {
	quoteCache.mu.Lock()
	quoteCache.prices = map[string]quoteEntry{}
	quoteCache.inflight = map[string]chan struct{}{}
	quoteCache.mu.Unlock()

	var hits int64
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if atomic.AddInt64(&hits, 1) == 1 {
			w.WriteHeader(http.StatusServiceUnavailable) // first call fails
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"chart": map[string]interface{}{"result": []map[string]interface{}{{
				"meta": map[string]interface{}{"regularMarketPrice": 55.0, "currency": "USD"},
			}}},
		})
	}))
	defer srv.Close()
	orig := yahooBaseURL
	yahooBaseURL = srv.URL
	defer func() { yahooBaseURL = orig }()

	if _, err := GetQuoteYahoo("RETRY"); err == nil {
		t.Fatal("expected error on first (503) call")
	}
	if p, err := GetQuoteYahoo("RETRY"); err != nil || p != 55.0 {
		t.Fatalf("retry should succeed: price=%v err=%v", p, err)
	}
}

// fetchYahooQuote must surface a non-200 status as an error (with the code).
func TestFetchYahooQuote_Non200(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(429)
	}))
	defer srv.Close()
	orig := yahooBaseURL
	yahooBaseURL = srv.URL
	defer func() { yahooBaseURL = orig }()

	_, err := fetchYahooQuote("RATELIMITED")
	if err == nil || !strings.Contains(err.Error(), "429") {
		t.Fatalf("expected 429 error, got %v", err)
	}
}

// fetchYahooQuote must reject a missing result array.
func TestFetchYahooQuote_NoResult(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{"chart": map[string]interface{}{"result": nil}})
	}))
	defer srv.Close()
	orig := yahooBaseURL
	yahooBaseURL = srv.URL
	defer func() { yahooBaseURL = orig }()

	if _, err := fetchYahooQuote("EMPTY"); err == nil {
		t.Fatal("expected error when result is empty")
	}
}

// fetchYahooQuote must reject a zero/missing regularMarketPrice.
func TestFetchYahooQuote_ZeroPrice(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"chart": map[string]interface{}{"result": []map[string]interface{}{{
				"meta": map[string]interface{}{"regularMarketPrice": 0, "currency": "USD"},
			}}},
		})
	}))
	defer srv.Close()
	orig := yahooBaseURL
	yahooBaseURL = srv.URL
	defer func() { yahooBaseURL = orig }()

	if _, err := fetchYahooQuote("ZERO"); err == nil {
		t.Fatal("expected error for zero price")
	}
}
