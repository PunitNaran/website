package main

import (
	"fmt"
	"log/slog"
	"sync"
	"sync/atomic"
	"time"
)

// Circuit states for the state machine.
const (
	CircuitClosed = iota
	CircuitOpen
	CircuitHalfOpen
)

// CircuitBreaker implements the circuit breaker state machine.
type CircuitBreaker struct {
	mu sync.Mutex

	state          int // CircuitClosed / Open / HalfOpen
	errCount       int
	dailyPnL       float64
	maxErrors      int
	dailyLossLimit float64
	opensAt        time.Time
	recoverTimeout time.Duration

	totalCalls   int64
	successCalls int64
	failureCalls int64
}

// NewCircuitBreaker creates a breaker with the given thresholds.
func NewCircuitBreaker(maxErrors int, dailyLossLimit float64, recoverTimeout time.Duration) *CircuitBreaker {
	return &CircuitBreaker{
		state:          CircuitClosed,
		maxErrors:      maxErrors,
		dailyLossLimit: dailyLossLimit,
		recoverTimeout: recoverTimeout,
		opensAt:        time.Now(),
	}
}

// AllowRequest returns (allowed, retryAfter).
func (cb *CircuitBreaker) AllowRequest() (bool, time.Duration) {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	switch cb.state {
	case CircuitClosed:
		return true, 0
	case CircuitHalfOpen:
		return true, 0
	case CircuitOpen:
		if time.Now().After(cb.opensAt) {
			cb.state = CircuitHalfOpen
			cb.errCount = 0
			slog.Info("circuit_breaker: transitioning to half-open")
			return true, 0
		}
		return false, time.Until(cb.opensAt)
	}
	return false, 0
}

// RecordSuccess auto-closes from half-open.
func (cb *CircuitBreaker) RecordSuccess() {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	atomic.AddInt64(&cb.successCalls, 1)
	atomic.AddInt64(&cb.totalCalls, 1)
	if cb.state == CircuitHalfOpen {
		cb.state = CircuitClosed
		cb.errCount = 0
		slog.Info("circuit_breaker: success in half-open, closing")
	}
}

// RecordFailure may open the circuit.
func (cb *CircuitBreaker) RecordFailure(maxErrors int, dailyPnL float64) {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	atomic.AddInt64(&cb.failureCalls, 1)
	atomic.AddInt64(&cb.totalCalls, 1)
	cb.errCount++
	cb.dailyPnL += dailyPnL

	if cb.state == CircuitHalfOpen {
		cb.state = CircuitOpen
		cb.opensAt = time.Now().Add(cb.recoverTimeout)
		slog.Warn("circuit_breaker: failure in half-open, re-opening")
		return
	}

	if cb.errCount >= maxErrors || (cb.dailyPnL <= cb.dailyLossLimit && cb.dailyPnL < 0) {
		cb.state = CircuitOpen
		cb.opensAt = time.Now().Add(cb.recoverTimeout)
		slog.Warn("circuit_breaker: opened",
			"err_count", cb.errCount,
			"daily_pnl", cb.dailyPnL,
			"recover_at", cb.opensAt,
		)
	}
}

// State returns the current circuit state for monitoring.
func (cb *CircuitBreaker) State() int {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	return cb.state
}

// Stats returns circuit breaker metrics.
func (cb *CircuitBreaker) Stats() map[string]interface{} {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	return map[string]interface{}{
		"state":       fmt.Sprintf("circuit_%d", cb.state),
		"err_count":   cb.errCount,
		"daily_pnl":   cb.dailyPnL,
		"opens_at":    cb.opensAt,
		"total_calls": atomic.LoadInt64(&cb.totalCalls),
		"success":     atomic.LoadInt64(&cb.successCalls),
		"failure":     atomic.LoadInt64(&cb.failureCalls),
	}
}

// Reset clears all state.
func (cb *CircuitBreaker) Reset() {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	cb.state = CircuitClosed
	cb.errCount = 0
	cb.dailyPnL = 0
	cb.opensAt = time.Now()
	atomic.StoreInt64(&cb.totalCalls, 0)
	atomic.StoreInt64(&cb.successCalls, 0)
	atomic.StoreInt64(&cb.failureCalls, 0)
	slog.Info("circuit_breaker: manual reset")
}
