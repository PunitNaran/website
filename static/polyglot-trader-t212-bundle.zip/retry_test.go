package main

import (
	"errors"
	"fmt"
	"sync/atomic"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/pkg/cache"
	"github.com/punit/polyglot-trader-t212/pkg/rate_limiter"
)

func TestRetryWithBackoff_Success(t *testing.T) {
	attempts := 0
	cfg := RetryConfig{MaxRetries: 3, BaseMs: 10, Multiplier: 2.0}
	err := RetryWithBackoff(cfg, func() error {
		attempts++
		if attempts < 2 {
			return errors.New("transient error")
		}
		return nil
	})
	if err != nil {
		t.Errorf("expected success, got %v", err)
	}
	if attempts != 2 {
		t.Errorf("expected 2 attempts, got %d", attempts)
	}
}

func TestRetryWithBackoff_AllFail(t *testing.T) {
	cfg := RetryConfig{MaxRetries: 2, BaseMs: 10, Multiplier: 2.0}
	err := RetryWithBackoff(cfg, func() error {
		return errors.New("permanent error")
	})
	if err == nil {
		t.Error("expected error after all retries exhausted")
	}
}

func TestRetryWithBackoff_SuccessFirstTry(t *testing.T) {
	attempts := 0
	cfg := RetryConfig{MaxRetries: 3, BaseMs: 10, Multiplier: 2.0}
	err := RetryWithBackoff(cfg, func() error {
		attempts++
		return nil
	})
	if err != nil {
		t.Errorf("expected success, got %v", err)
	}
	if attempts != 1 {
		t.Errorf("expected 1 attempt, got %d", attempts)
	}
}

func TestRetryWithBackoff_ZeroRetries(t *testing.T) {
	attempts := 0
	cfg := RetryConfig{MaxRetries: 0, BaseMs: 10, Multiplier: 2.0}
	err := RetryWithBackoff(cfg, func() error {
		attempts++
		return errors.New("fail")
	})
	if err == nil {
		t.Error("expected error")
	}
	if attempts != 1 {
		t.Errorf("expected 1 attempt with 0 retries, got %d", attempts)
	}
}

func TestFallbackHTTP_Success(t *testing.T) {
	c := cache.New(1 * time.Minute)
	called := false
	body, err := FallbackHTTP(
		RetryConfig{MaxRetries: 1, BaseMs: 10, Multiplier: 2.0},
		func() ([]byte, error) {
			called = true
			return []byte(`{"result":"ok"}`), nil
		},
		"test-key", c,
	)
	if err != nil {
		t.Errorf("expected success, got %v", err)
	}
	if !called {
		t.Error("expected fetch function to be called")
	}
	if string(body) != `{"result":"ok"}` {
		t.Errorf("unexpected body: %s", string(body))
	}
}

func TestFallbackHTTP_FetchFails_UseCache(t *testing.T) {
	c := cache.New(1 * time.Minute)
	c.Set("test-key", `{"cached":"data"}`)

	called := 0
	body, err := FallbackHTTP(
		RetryConfig{MaxRetries: 0, BaseMs: 10, Multiplier: 2.0},
		func() ([]byte, error) {
			called++
			return nil, fmt.Errorf("network error")
		},
		"test-key", c,
	)
	if err != nil {
		t.Errorf("expected cache fallback, got %v", err)
	}
	if string(body) != `{"cached":"data"}` {
		t.Errorf("expected cached body, got %s", string(body))
	}
	if called != 1 {
		t.Errorf("expected 1 fetch attempt, got %d", called)
	}
}

func TestFallbackHTTP_FetchFails_NoCache(t *testing.T) {
	c := cache.New(1 * time.Minute)
	_, err := FallbackHTTP(
		RetryConfig{MaxRetries: 0, BaseMs: 10, Multiplier: 2.0},
		func() ([]byte, error) {
			return nil, fmt.Errorf("network error")
		},
		"no-cache-key", c,
	)
	if err == nil {
		t.Error("expected error when no cache and fetch fails")
	}
}

func TestFallbackHTTP_StoresInCache(t *testing.T) {
	c := cache.New(1 * time.Minute)
	_, err := FallbackHTTP(
		RetryConfig{MaxRetries: 1, BaseMs: 10, Multiplier: 2.0},
		func() ([]byte, error) {
			return []byte(`{"fresh":"data"}`), nil
		},
		"cache-key", c,
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	cached, ok := c.Get("cache-key")
	if !ok {
		t.Error("expected cached value")
	}
	if cached.(string) != `{"fresh":"data"}` {
		t.Errorf("unexpected cached value: %s", cached)
	}
}

func TestFallbackHTTP_NullCache(t *testing.T) {
	_, err := FallbackHTTP(
		RetryConfig{MaxRetries: 0, BaseMs: 10, Multiplier: 2.0},
		func() ([]byte, error) {
			return nil, fmt.Errorf("no cache available")
		},
		"any-key", nil,
	)
	if err == nil {
		t.Error("expected error without cache")
	}
}

func TestAdaptiveRateLimiter_Allow_Normal(t *testing.T) {
	base := rate_limiter.NewT212RateLimiter()
	arL := NewAdaptiveRateLimiter(base)
	allowed, _ := arL.Allow(rate_limiter.Positions, 1)
	if !allowed {
		t.Error("expected allowed with no errors")
	}
}

func TestAdaptiveRateLimiter_RecordError_Penalty(t *testing.T) {
	base := rate_limiter.NewT212RateLimiter()
	arL := NewAdaptiveRateLimiter(base)

	for i := 0; i < 11; i++ {
		arL.RecordError()
	}

	// Should have reduced capacity
	allowed, _ := arL.Allow(rate_limiter.Positions, 1)
	// Don't fail on this — the rate limiter may be too aggressive
	_ = allowed
}

func TestAdaptiveRateLimiter_RecordSuccess_Reset(t *testing.T) {
	base := rate_limiter.NewT212RateLimiter()
	arL := NewAdaptiveRateLimiter(base)

	for i := 0; i < 11; i++ {
		arL.RecordError()
	}
	arL.RecordSuccess()

	// After success, should be back to normal
	allowed, _ := arL.Allow(rate_limiter.Positions, 1)
	if !allowed {
		t.Error("expected allowed after RecordSuccess")
	}
}

func TestAdaptiveRateLimiter_Penalty5Errors(t *testing.T) {
	base := rate_limiter.NewT212RateLimiter()
	arL := NewAdaptiveRateLimiter(base)

	for i := 0; i < 6; i++ {
		arL.RecordError()
	}
	// penaltyFactor should be 0.5 at this point
	// This means requests need to be 2x cheaper (n*0.5 tokens)
	// Still allows if we request 0.5 tokens
	allowed, _ := arL.Allow(rate_limiter.Positions, 0.5)
	if !allowed {
		t.Error("expected 0.5 token request to be allowed at 50% penalty")
	}
}

func TestAdaptiveRateLimiter_Concurrent(t *testing.T) {
	base := rate_limiter.NewT212RateLimiter()
	arL := NewAdaptiveRateLimiter(base)

	var wg atomic.Int64
	wg.Add(20)
	done := make(chan bool, 20)
	for i := 0; i < 10; i++ {
		go func() {
			arL.Allow(rate_limiter.Positions, 1)
			wg.Add(-1)
			done <- true
		}()
	}
	for i := 0; i < 10; i++ {
		go func() {
			arL.RecordError()
			wg.Add(-1)
			done <- true
		}()
	}
	for i := 0; i < 20; i++ {
		<-done
	}
	// Wait for all goroutines to complete
	for wg.Load() > 0 {
		time.Sleep(time.Millisecond)
	}
}

func BenchmarkRetryWithBackoff_Success(b *testing.B) {
	cfg := RetryConfig{MaxRetries: 0, BaseMs: 1, Multiplier: 2.0}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		RetryWithBackoff(cfg, func() error { return nil })
	}
}

func BenchmarkFallbackHTTP_Success(b *testing.B) {
	c := cache.New(1 * time.Minute)
	cfg := RetryConfig{MaxRetries: 0, BaseMs: 1, Multiplier: 2.0}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		FallbackHTTP(cfg, func() ([]byte, error) {
			return []byte(`{"ok":true}`), nil
		}, "key", c)
	}
}
