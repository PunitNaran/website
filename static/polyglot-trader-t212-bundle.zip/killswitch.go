package main

import (
	"encoding/json"
	"log/slog"
	"net/http"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// KillSwitch handles immediate halt requests via POST /api/kill-switch.
type KillSwitch struct {
	active      int32 // atomic bool
	activatedAt time.Time
	mu          sync.Mutex
}

var (
	killSwitch = &KillSwitch{}
)

// IsActive returns whether the kill switch is active.
func (ks *KillSwitch) IsActive() bool {
	return atomic.LoadInt32(&ks.active) == 1
}

// Activate flips the kill switch and logs the event.
func (ks *KillSwitch) Activate() {
	if !atomic.CompareAndSwapInt32(&ks.active, 0, 1) {
		slog.Warn("kill_switch: already active")
		return
	}
	ks.activatedAt = time.Now()
	ks.mu.Lock()
	defer ks.mu.Unlock()
	slog.Error("kill_switch ACTIVATED", "at", ks.activatedAt)
	ks.logKillEvent()
}

// Reset clears the kill switch state.
func (ks *KillSwitch) Reset() {
	atomic.StoreInt32(&ks.active, 0)
	slog.Info("kill_switch: reset")
}

// logKillEvent appends a kill event to kill_events.json as JSON Lines.
// Separate file from the paper trade log: kill events are an append-only
// audit trail (persisted across restarts, unlike the in-memory flag), while
// paper_trades.json is atomically overwritten as a single JSON array by
// writeTradesFile. Two writers on one file used to clobber each other —
// this split makes each file single-writer, single-format.
func (ks *KillSwitch) logKillEvent() {
	record := map[string]interface{}{
		"event":     "kill_switch",
		"timestamp": time.Now().UTC().Format(time.RFC3339),
		"positions": "returned_to_cash",
		"message":   "All positions closed, service halted",
	}
	data, _ := json.Marshal(record) // compact, one line per event
	path := "kill_events.json"
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		slog.Error("kill_switch: failed to open kill_events.json", "error", err)
		return
	}
	defer f.Close()
	f.Write(data)
	f.Write([]byte("\n"))
}

// handleKillSwitch is the HTTP handler for POST /api/kill-switch.
func handleKillSwitch(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if killSwitch.IsActive() {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"status":"already_halted"}`))
		return
	}

	killSwitch.Activate()
	if autoExec != nil {
		autoExec.CloseAll()
	}
	// Flatten ALL paper positions (including manual /api/paper/execute trades)
	paperTrader.CloseAllPositions()

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{
		"status":    "halted",
		"timestamp": killSwitch.activatedAt.Format(time.RFC3339),
		"message":   "All positions returned to cash, service halted",
	})
}
