package main

import (
	"fmt"
	"log/slog"
	"math"
	"math/rand"
	"sync"
	"time"

	"github.com/punit/polyglot-trader-t212/pkg/cache"
	"github.com/punit/polyglot-trader-t212/pkg/rate_limiter"
)

// RetryConfig holds retry/fallback parameters.
type RetryConfig struct {
	MaxRetries int
	BaseMs     int
	Multiplier float64
}

// RetryWithBackoff executes fn with exponential backoff and jitter.
func RetryWithBackoff(cfg RetryConfig, fn func() error) error {
	var lastErr error
	for attempt := 0; attempt <= cfg.MaxRetries; attempt++ {
		err := fn()
		if err == nil {
			return nil
		}
		lastErr = err
		if attempt < cfg.MaxRetries {
			backoff := float64(cfg.BaseMs) * math.Pow(cfg.Multiplier, float64(attempt))
			// Add jitter: ±25%
			jitter := backoff * 0.25 * rand.Float64()
			wait := time.Duration(backoff+jitter) * time.Millisecond
			slog.Warn("retry_attempt",
				"attempt", attempt+1,
				"max", cfg.MaxRetries,
				"wait_ms", int(wait.Milliseconds()),
				"error", err,
			)
			select {
			case <-time.After(wait):
			}
		}
	}
	return lastErr
}

// FallbackHTTP calls the T212 API with retry logic and falls back to cached data.
func FallbackHTTP(cfg RetryConfig, fetchFn func() ([]byte, error), cacheKey string, cache *cache.Cache) (body []byte, err error) {
	err = RetryWithBackoff(cfg, func() error {
		var fetchErr error
		body, fetchErr = fetchFn()
		if fetchErr != nil {
			return fetchErr
		}
		if cache != nil {
			cache.Set(cacheKey, string(body))
		}
		return nil
	})

	if err == nil {
		return body, nil
	}

	// Fallback: use cached data
	if cache != nil {
		if cached, ok := cache.Get(cacheKey); ok {
			slog.Warn("API failed, using cached data",
				"cache_key", cacheKey,
				"error", err,
			)
			return []byte(cached.(string)), nil
		}
	}

	return nil, fmt.Errorf("fetch failed after retries: %w", err)
}

// AdaptiveRateLimiter wraps rate_limiter.T212RateLimiter and reduces capacity on errors.
type AdaptiveRateLimiter struct {
	mu            sync.Mutex
	base          *rate_limiter.T212RateLimiter
	errorCount    int
	penaltyFactor float64 // 1.0 = normal, lower = more restrictive
	minCapacity   float64
}

// NewAdaptiveRateLimiter creates an adaptive rate limiter.
func NewAdaptiveRateLimiter(base *rate_limiter.T212RateLimiter) *AdaptiveRateLimiter {
	return &AdaptiveRateLimiter{
		base:          base,
		errorCount:    0,
		penaltyFactor: 1.0,
		minCapacity:   0.1,
	}
}

// Allow checks the rate limit, adapting based on error history.
func (a *AdaptiveRateLimiter) Allow(endpoint rate_limiter.EndpointType, n float64) (bool, time.Duration) {
	a.mu.Lock()
	defer a.mu.Unlock()

	if a.errorCount > 10 {
		a.penaltyFactor = a.minCapacity
	} else if a.errorCount > 5 {
		a.penaltyFactor = 0.5
	}

	allowed, retryAfter := a.base.Allow(endpoint, n*a.penaltyFactor)
	_ = retryAfter
	return allowed, time.Duration(float64(time.Second) * retryAfter)
}

// RecordError increments the error counter and reduces capacity.
func (a *AdaptiveRateLimiter) RecordError() {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.errorCount++
	slog.Warn("adaptive_rate_limiter: error recorded",
		"error_count", a.errorCount,
	)
}

// RecordSuccess resets error counter after a successful call.
func (a *AdaptiveRateLimiter) RecordSuccess() {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.errorCount = 0
	a.penaltyFactor = 1.0
}
