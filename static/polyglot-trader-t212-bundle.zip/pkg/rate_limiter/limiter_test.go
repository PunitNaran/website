package rate_limiter

import (
	"testing"
)

func TestNewT212RateLimiter(t *testing.T) {
	l := NewT212RateLimiter()
	if l == nil {
		t.Fatal("expected non-nil limiter")
	}
	// Check initial tokens for a few endpoints
	if l.tokens[Global] != 200 {
		t.Errorf("expected Global tokens=200, got %d", l.tokens[Global])
	}
	if l.tokens[Positions] != 50 {
		t.Errorf("expected Positions tokens=50, got %d", l.tokens[Positions])
	}
}

func TestAllowWithinLimit(t *testing.T) {
	l := NewT212RateLimiter()
	allowed, retry := l.Allow(Global, 1)
	if !allowed {
		t.Error("expected allow within limit")
	}
	if retry != 0 {
		t.Errorf("expected retry=0 when allowed, got %f", retry)
	}
}

func TestAllowExhaustedTokens(t *testing.T) {
	l := NewT212RateLimiter()
	// Exhaust all Global tokens (200)
	for i := 0; i < 200; i++ {
		l.Allow(Global, 1)
	}
	allowed, retry := l.Allow(Global, 1)
	if allowed {
		t.Error("expected block when tokens exhausted")
	}
	if retry <= 0 {
		t.Errorf("expected retry > 0 when blocked, got %f", retry)
	}
}

func TestRemaining(t *testing.T) {
	l := NewT212RateLimiter()
	l.Allow(Global, 10)
	remaining := l.Remaining(Global)
	if remaining != 190 {
		t.Errorf("expected 190 remaining, got %f", remaining)
	}
}

func TestAllowMultipleEndpoints(t *testing.T) {
	l := NewT212RateLimiter()
	// Allow on different endpoints
	l.Allow(Positions, 5)
	l.Allow(Orders, 3)
	l.Allow(Quotes, 10)

	if l.Remaining(Positions) != 45 {
		t.Errorf("expected Positions=45, got %f", l.Remaining(Positions))
	}
	if l.Remaining(Orders) != 47 {
		t.Errorf("expected Orders=47, got %f", l.Remaining(Orders))
	}
	if l.Remaining(Quotes) != 90 {
		t.Errorf("expected Quotes=90, got %f", l.Remaining(Quotes))
	}
}

func TestEndpointConstants(t *testing.T) {
	// Verify all endpoint types are distinct
	endpoints := []EndpointType{Global, Positions, Orders, Quotes, MLPredict, RiskGate, Signal}
	seen := make(map[EndpointType]bool)
	for _, e := range endpoints {
		if seen[e] {
			t.Errorf("duplicate endpoint type: %d", e)
		}
		seen[e] = true
	}
}
