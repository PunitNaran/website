// Package rate_limiter provides rate limiting for T212 API calls.
package rate_limiter

import "sync"

// EndpointType identifies a T212 API endpoint.
type EndpointType int

const (
	Global EndpointType = iota
	Positions
	Orders
	Quotes
	MLPredict
	RiskGate
	Signal
)

// Label is a string alias for endpoint labels.
type Label = string

// T212RateLimiter limits Trading212 API calls per endpoint.
type T212RateLimiter struct {
	mu     sync.Mutex
	tokens map[EndpointType]int
	cap    map[EndpointType]int
}

// NewT212RateLimiter creates a new T212RateLimiter.
func NewT212RateLimiter() *T212RateLimiter {
	return &T212RateLimiter{
		tokens: map[EndpointType]int{
			Global:    200,
			Positions: 50,
			Orders:    50,
			Quotes:    100,
			MLPredict: 30,
			RiskGate:  30,
			Signal:    30,
		},
		cap: map[EndpointType]int{
			Global:    200,
			Positions: 50,
			Orders:    50,
			Quotes:    100,
			MLPredict: 30,
			RiskGate:  30,
			Signal:    30,
		},
	}
}

// Allow checks if an endpoint has capacity and consumes a token.
// Returns (allowed, retryAfter) where retryAfter is seconds to wait.
func (r *T212RateLimiter) Allow(endpoint EndpointType, n float64) (bool, float64) {
	r.mu.Lock()
	defer r.mu.Unlock()

	cap := float64(r.cap[endpoint])
	if r.tokens[endpoint] < int(n) {
		needed := int(n) - r.tokens[endpoint]
		retry := float64(needed) / float64(cap) * 10 // rough estimate seconds
		return false, retry
	}
	r.tokens[endpoint] -= int(n)
	return true, 0
}

// Remaining returns tokens left for the endpoint.
func (r *T212RateLimiter) Remaining(endpoint EndpointType) float64 {
	r.mu.Lock()
	defer r.mu.Unlock()
	return float64(r.tokens[endpoint])
}
