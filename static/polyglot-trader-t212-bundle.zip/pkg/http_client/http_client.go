// Package http_client provides a pre-configured HTTP client with connection pooling.
// Uses stdlib only — no external dependency.
package http_client

import (
	"net/http"
	"time"
)

// NewPool returns an *http.Client with connection pooling configured for
// high-throughput external API calls (Trading212).
func NewPool(maxIdleConns, maxIdleConnsPerHost int, idleTimeout, respTimeout time.Duration) *http.Client {
	return &http.Client{
		Transport: &http.Transport{
			MaxIdleConns:          maxIdleConns,
			MaxIdleConnsPerHost:   maxIdleConnsPerHost,
			IdleConnTimeout:       idleTimeout,
			ResponseHeaderTimeout: respTimeout,
		},
		Timeout: 30 * time.Second,
	}
}
