package http_client

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestNewPool_DefaultConfig(t *testing.T) {
	client := NewPool(100, 100, 90*time.Second, 10*time.Second)
	if client == nil {
		t.Fatal("expected non-nil client")
	}
	if client.Timeout != 30*time.Second {
		t.Errorf("expected 30s timeout, got %v", client.Timeout)
	}
}

func TestNewPool_TransportConfig(t *testing.T) {
	client := NewPool(50, 25, 60*time.Second, 5*time.Second)
	transport, ok := client.Transport.(*http.Transport)
	if !ok {
		t.Fatal("expected *http.Transport")
	}
	if transport.MaxIdleConns != 50 {
		t.Errorf("expected MaxIdleConns=50, got %d", transport.MaxIdleConns)
	}
	if transport.MaxIdleConnsPerHost != 25 {
		t.Errorf("expected MaxIdleConnsPerHost=25, got %d", transport.MaxIdleConnsPerHost)
	}
	if transport.IdleConnTimeout != 60*time.Second {
		t.Errorf("expected IdleConnTimeout=60s, got %v", transport.IdleConnTimeout)
	}
}

func TestNewPool_ZeroConfig(t *testing.T) {
	client := NewPool(0, 0, 0, 0)
	if client == nil {
		t.Fatal("expected non-nil client even with zero config")
	}
	// Should still have default timeout
	if client.Timeout == 0 {
		t.Error("expected default 30s timeout")
	}
}

func TestNewPool_UsedSuccessfully(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"ok"}`))
	}))
	defer server.Close()

	client := NewPool(10, 10, 5*time.Second, 5*time.Second)
	resp, err := client.Get(server.URL)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected 200, got %d", resp.StatusCode)
	}
}

func TestNewPool_Timeout(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(5 * time.Second) // longer than timeout
	}))
	defer server.Close()

	client := NewPool(10, 10, 5*time.Second, 5*time.Second)
	_, err := client.Get(server.URL)
	if err == nil {
		t.Error("expected timeout error")
	}
}
