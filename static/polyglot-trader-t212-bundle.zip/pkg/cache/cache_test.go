package cache

import (
	"fmt"
	"sync"
	"testing"
	"time"
)

func TestCacheSetAndGet(t *testing.T) {
	c := New(1 * time.Minute)
	c.Set("key1", "value1")

	val, ok := c.Get("key1")
	if !ok {
		t.Fatal("expected cache hit")
	}
	if val.(string) != "value1" {
		t.Errorf("expected 'value1', got %v", val)
	}
}

func TestCacheGetNonExistent(t *testing.T) {
	c := New(1 * time.Minute)
	_, ok := c.Get("nonexistent")
	if ok {
		t.Error("expected miss for non-existent key")
	}
}

func TestCacheOverwrite(t *testing.T) {
	c := New(1 * time.Minute)
	c.Set("key1", "old")
	c.Set("key1", "new")

	val, ok := c.Get("key1")
	if !ok {
		t.Fatal("expected cache hit")
	}
	if val.(string) != "new" {
		t.Errorf("expected 'new', got %v", val)
	}
}

func TestCacheExpiration(t *testing.T) {
	c := New(50 * time.Millisecond)
	c.Set("expiring", "val")

	// Wait beyond TTL
	time.Sleep(100 * time.Millisecond)

	_, ok := c.Get("expiring")
	if ok {
		t.Error("expected miss after TTL expiry")
	}
}

func TestCacheMultipleKeys(t *testing.T) {
	c := New(1 * time.Minute)
	for i := 0; i < 100; i++ {
		c.Set(fmt.Sprintf("key-%d", i), fmt.Sprintf("val-%d", i))
	}

	for i := 0; i < 100; i++ {
		val, ok := c.Get(fmt.Sprintf("key-%d", i))
		if !ok {
			t.Errorf("expected hit for key-%d", i)
			continue
		}
		expected := fmt.Sprintf("val-%d", i)
		if val.(string) != expected {
			t.Errorf("key-%d: got %v, want %v", i, val, expected)
		}
	}
}

func TestCacheDifferentTypes(t *testing.T) {
	c := New(1 * time.Minute)

	c.Set("string", "hello")
	c.Set("int", 42)
	c.Set("float", 3.14)
	c.Set("bool", true)
	c.Set("slice", []int{1, 2, 3})

	if v, ok := c.Get("string"); !ok || v.(string) != "hello" {
		t.Error("string type failed")
	}
	if v, ok := c.Get("int"); !ok || v.(int) != 42 {
		t.Error("int type failed")
	}
	if v, ok := c.Get("float"); !ok || v.(float64) != 3.14 {
		t.Error("float type failed")
	}
	if v, ok := c.Get("bool"); !ok || v.(bool) != true {
		t.Error("bool type failed")
	}
	if v, ok := c.Get("slice"); ok {
		_ = v
	} else {
		t.Error("slice type failed")
	}
}

func TestCacheExpirationImmediate(t *testing.T) {
	c := New(1 * time.Millisecond)
	c.Set("fast", "value")
	time.Sleep(5 * time.Millisecond)
	_, ok := c.Get("fast")
	if ok {
		t.Error("expected miss after 1ms TTL")
	}
}

func TestCacheConcurrent(t *testing.T) {
	c := New(1 * time.Minute)
	var wg sync.WaitGroup
	wg.Add(10)
	for i := 0; i < 10; i++ {
		go func(n int) {
			defer wg.Done()
			c.Set(fmt.Sprintf("k%d", n), n)
			c.Get(fmt.Sprintf("k%d", n))
		}(i)
	}
	wg.Wait()
}

func BenchmarkCacheSet(b *testing.B) {
	c := New(1 * time.Minute)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Set("key", "value")
	}
}

func BenchmarkCacheGet(b *testing.B) {
	c := New(1 * time.Minute)
	c.Set("key", "value")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Get("key")
	}
}

func BenchmarkCacheGetMiss(b *testing.B) {
	c := New(1 * time.Minute)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Get("nonexistent")
	}
}
