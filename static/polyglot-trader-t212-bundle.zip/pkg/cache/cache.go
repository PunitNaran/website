// Package cache provides a simple TTL cache for positions and orders.
// Uses stdlib only — no external dependency.
package cache

import (
	"sync"
	"time"
)

// Entry is a cached value with an expiration timestamp.
type Entry struct {
	Value     interface{}
	ExpiresAt time.Time
}

// Cache is a simple TTL cache with periodic background cleanup.
// ponytail: uses a global RWMutex. Per-key locks or sharding needed
// if throughput exceeds a few thousand ops/sec.
type Cache struct {
	mu    sync.RWMutex
	items map[string]Entry
	ttl   time.Duration
}

// New creates a cache that expires entries after ttl.
func New(ttl time.Duration) *Cache {
	c := &Cache{
		items: make(map[string]Entry),
		ttl:   ttl,
	}
	go c.cleanup()
	return c
}

// Set stores a value under the given key with the cache's default TTL.
func (c *Cache) Set(key string, value interface{}) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.items[key] = Entry{
		Value:     value,
		ExpiresAt: time.Now().Add(c.ttl),
	}
}

// Get retrieves a value by key, returning nil and false if not found or expired.
func (c *Cache) Get(key string) (interface{}, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	entry, ok := c.items[key]
	if !ok || time.Now().After(entry.ExpiresAt) {
		return nil, false
	}
	return entry.Value, true
}

func maxDuration(a, b time.Duration) time.Duration {
	if a < b {
		return a
	}
	return b
}

// cleanup removes expired entries on a periodic ticker.
func (c *Cache) cleanup() {
	ticker := time.NewTicker(maxDuration(c.ttl/2, time.Millisecond))
	defer ticker.Stop()
	for range ticker.C {
		c.mu.Lock()
		now := time.Now()
		for k, v := range c.items {
			if now.After(v.ExpiresAt) {
				delete(c.items, k)
			}
		}
		c.mu.Unlock()
	}
}
