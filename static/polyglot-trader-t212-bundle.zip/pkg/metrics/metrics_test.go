package metrics

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestNew(t *testing.T) {
	c := New()
	if c == nil {
		t.Fatal("expected collector")
	}
}

func TestInc(t *testing.T) {
	c := New()
	c.Inc("positions")
	c.Inc("positions")
	c.Inc("orders")

	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()
	c.ServeHTTP(w, req)

	body := w.Body.String()
	if !strings.Contains(body, `endpoint="positions"`) {
		t.Errorf("expected 'positions' endpoint in metrics, got: %s", body)
	}
	if !strings.Contains(body, `endpoint="orders"`) {
		t.Errorf("expected 'orders' endpoint in metrics, got: %s", body)
	}
}

func TestObserveDuration(t *testing.T) {
	c := New()
	c.ObserveDuration("orders", 100*time.Millisecond)
	c.ObserveDuration("orders", 250*time.Millisecond)

	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()
	c.ServeHTTP(w, req)

	body := w.Body.String()
	if !strings.Contains(body, "orders") {
		t.Error("expected 'orders' in duration metrics")
	}
}

func TestServeHTTPContentType(t *testing.T) {
	c := New()
	c.Inc("/test")

	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()
	c.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}
	ct := w.Header().Get("Content-Type")
	if !strings.Contains(ct, "text/plain") {
		t.Errorf("expected text/plain content type, got %s", ct)
	}
}

func TestServeHTTPEmpty(t *testing.T) {
	c := New()
	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()
	c.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected 200, got %d", w.Code)
	}
}

func TestSanitizeEndpoint(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{"/api/ml/predict", "ml_predict"},
		{"/api/risk/gate", "risk_gate"},
		{"/health", "/health"},
		{"/", "/"},
		{"/api/v0/equity/positions", "v0_equity_positions"},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			got := SanitizeEndpoint(tt.input)
			if got != tt.want {
				t.Errorf("SanitizeEndpoint(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}

func TestMultipleEndpoints(t *testing.T) {
	c := New()
	c.Inc("/api/a")
	c.Inc("/api/b")
	c.Inc("/api/b")

	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()
	c.ServeHTTP(w, req)

	body := w.Body.String()
	if !strings.Contains(body, "/api/a") {
		t.Error("missing /api/a counter")
	}
	if !strings.Contains(body, "/api/b") {
		t.Error("missing /api/b counter")
	}
}

func TestCollector_ConcurrentAccess(t *testing.T) {
	c := New()
	var wg sync.WaitGroup
	wg.Add(20)
	for i := 0; i < 10; i++ {
		go func(n int) {
			defer wg.Done()
			c.Inc(fmt.Sprintf("ep-%d", n))
		}(i)
	}
	for i := 0; i < 10; i++ {
		go func(n int) {
			defer wg.Done()
			c.ObserveDuration(fmt.Sprintf("ep-%d", n), time.Duration(n)*time.Millisecond)
		}(i)
	}
	wg.Wait()
	// Should not panic
	req := httptest.NewRequest("GET", "/metrics", nil)
	w := httptest.NewRecorder()
	c.ServeHTTP(w, req)
	_, _ = w.Body.Read(make([]byte, 1000)) // drain body
}

func BenchmarkCollectorInc(b *testing.B) {
	c := New()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Inc("test")
	}
}

func BenchmarkCollectorObserveDuration(b *testing.B) {
	c := New()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.ObserveDuration("test", time.Duration(i)*time.Millisecond)
	}
}

func BenchmarkCollectorServeHTTP(b *testing.B) {
	c := New()
	c.Inc("test")
	c.ObserveDuration("test", 100*time.Millisecond)

	for i := 0; i < b.N; i++ {
		req := httptest.NewRequest("GET", "/metrics", nil)
		w := httptest.NewRecorder()
		c.ServeHTTP(w, req)
		_, _ = w.Body.ReadString(0) // drain body
	}
}
