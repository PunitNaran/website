// Package metrics provides Prometheus-format HTTP request metrics.
// Uses stdlib only — no external dependency.
package metrics

import (
	"fmt"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Collector tracks per-endpoint request counts and durations.
type Collector struct {
	mu        sync.RWMutex
	counters  map[string]*int64
	durations map[string][]float64
}

// New creates a new metrics collector.
func New() *Collector {
	return &Collector{
		counters:  make(map[string]*int64),
		durations: make(map[string][]float64),
	}
}

// Inc increments the request counter for the given endpoint.
func (c *Collector) Inc(endpoint string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, ok := c.counters[endpoint]; !ok {
		c.counters[endpoint] = new(int64)
	}
	atomic.AddInt64(c.counters[endpoint], 1)
}

// ObserveDuration records a request duration sample for the given endpoint.
func (c *Collector) ObserveDuration(endpoint string, d time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.durations[endpoint] = append(c.durations[endpoint], d.Seconds())
}

// ServeHTTP writes metrics in Prometheus exposition format.
func (c *Collector) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	var buf strings.Builder
	for ep, v := range c.counters {
		buf.WriteString(fmt.Sprintf("http_requests_total{endpoint=\"%s\"} %d\n", ep, atomic.LoadInt64(v)))
	}
	for ep, durs := range c.durations {
		for _, d := range durs {
			buf.WriteString(fmt.Sprintf("http_request_duration_seconds{endpoint=\"%s\"} %.6f\n", ep, d))
		}
	}
	w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
	w.Write([]byte(buf.String()))
}

// SanitizeEndpoint converts a URL path to a metric label key.
// e.g. /api/ml/predict -> ml_predict
func SanitizeEndpoint(path string) string {
	parts := strings.Split(path, "/")
	if len(parts) > 2 {
		return strings.Join(parts[2:], "_")
	}
	return path
}
