package main

import (
	"bufio"
	"fmt"
	"log/slog"
	"os"
	"strconv"
	"strings"
)

// Config holds all externally-configured values. Loaded from env vars first,
// then from a .env file (if present), with env vars winning.
type Config struct {
	T212BaseURL    string
	T212ReadKey    string
	T212ReadSecret string

	// Circuit breaker
	CircuitMaxErrors  int
	CircuitDailyLoss  float64
	CircuitRecoverSec int

	// Retry
	RetryMaxRetries int
	RetryBaseMs     int
	RetryMultiplier float64

	// Kill switch
	KillSwitchToken string

	// Paper trading
	PaperMode        bool
	PaperInitialCash float64

	// Cache
	CacheTTL int

	// ML config
	MLNEstimators  int
	MLLearningRate float64
	MLMaxDepth     int

	// Alerting (env-based security)
	TelegramBotToken string
	TelegramChatID   string

	// Metrics endpoint
	MetricsEndpoint string
}

// LoadConfig reads .env then env vars, env vars win.
func LoadConfig() Config {
	// Load .env file if present
	envFile := ".env"
	if f, err := os.Open(envFile); err == nil {
		defer f.Close()
		scanner := bufio.NewScanner(f)
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			parts := strings.SplitN(line, "=", 2)
			if len(parts) == 2 {
				k := strings.TrimSpace(parts[0])
				v := strings.TrimSpace(parts[1])
				v = strings.Trim(v, `'"'`)
				if _, exists := os.LookupEnv(k); !exists {
					os.Setenv(k, v)
				}
			}
		}
		slog.Info("config: loaded .env file", "path", envFile)
	}

	return Config{
		T212BaseURL:       getEnv("T212_BASE_URL", "https://live.trading212.com"),
		T212ReadKey:       getEnv("T212_READ_KEY", ""),
		T212ReadSecret:    getEnv("T212_READ_SECRET", ""),
		CircuitMaxErrors:  mustParseInt(os.Getenv("CB_MAX_ERRORS"), 5),
		CircuitDailyLoss:  getEnvF64("CB_DAILY_LOSS", -30),
		CircuitRecoverSec: mustParseInt(os.Getenv("CB_RECOVER_TIMEOUT"), 60),
		RetryMaxRetries:   mustParseInt(os.Getenv("RETRY_MAX"), 3),
		RetryBaseMs:       mustParseInt(os.Getenv("RETRY_BASE_MS"), 1000),
		RetryMultiplier:   getEnvF64("RETRY_MULTIPLIER", 2.0),
		KillSwitchToken:   getEnv("KILL_SWITCH_TOKEN", ""),
		PaperMode:         getEnv("PAPER_MODE", "false") == "true",
		PaperInitialCash:  getEnvF64("PAPER_INITIAL_CASH", 1000),
		CacheTTL:          mustParseInt(os.Getenv("CACHE_TTL_SEC"), 30),
		MLNEstimators:     mustParseInt(os.Getenv("ML_N_ESTIMATORS"), 100),
		MLLearningRate:    getEnvF64("ML_LEARNING_RATE", 0.1),
		MLMaxDepth:        mustParseInt(os.Getenv("ML_MAX_DEPTH"), 10),
		TelegramBotToken:  getEnv("TELEGRAM_BOT_TOKEN", ""),
		TelegramChatID:    getEnv("TELEGRAM_CHAT_ID", ""),
		MetricsEndpoint:   getEnv("METRICS_ENDPOINT", ""),
	}
}

// --- env helpers (single source of truth) ---

func getEnv(key, defaultVal string) string {
	if val, ok := os.LookupEnv(key); ok {
		return val
	}
	return defaultVal
}

func mustParseInt(s string, def int) int {
	v, err := strconv.Atoi(s)
	if err != nil {
		return def
	}
	return v
}

func mustParseFloat64(s string, def float64) float64 {
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return def
	}
	return v
}

func getEnvNum(key string, defaultVal float64) float64 {
	s := os.Getenv(key)
	if s == "" {
		return defaultVal
	}
	var v float64
	if _, err := fmt.Sscanf(s, "%f", &v); err != nil {
		return defaultVal
	}
	return v
}

func getEnvF64(key string, defaultVal float64) float64 {
	return getEnvNum(key, defaultVal)
}

// Validate checks all required configuration values.
func (c *Config) Validate() error {
	if c.T212ReadKey == "" {
		return fmt.Errorf("T212_READ_KEY is required")
	}
	if c.T212ReadSecret == "" {
		return fmt.Errorf("T212_READ_SECRET is required")
	}
	if c.CircuitMaxErrors < 1 {
		return fmt.Errorf("CB_MAX_ERRORS must be >= 1, got %d", c.CircuitMaxErrors)
	}
	if c.CircuitRecoverSec < 1 {
		return fmt.Errorf("CB_RECOVER_TIMEOUT must be >= 1, got %d", c.CircuitRecoverSec)
	}
	if c.RetryMaxRetries < 0 {
		return fmt.Errorf("RETRY_MAX must be >= 0, got %d", c.RetryMaxRetries)
	}
	if c.RetryMultiplier < 1.0 {
		return fmt.Errorf("RETRY_MULTIPLIER must be >= 1.0, got %f", c.RetryMultiplier)
	}
	return nil
}

// Reload re-reads .env and environment variables (for SIGHUP hot-reload).
func (c *Config) Reload() {
	// Re-load .env (only values not set in env)
	envFile := ".env"
	if f, err := os.Open(envFile); err == nil {
		defer f.Close()
		scanner := bufio.NewScanner(f)
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			parts := strings.SplitN(line, "=", 2)
			if len(parts) == 2 {
				k := strings.TrimSpace(parts[0])
				v := strings.TrimSpace(parts[1])
				v = strings.Trim(v, `'"'`)
				if _, exists := os.LookupEnv(k); !exists {
					os.Setenv(k, v)
				}
			}
		}
	}
	// Re-parse all env values
	*c = LoadConfig()
	slog.Info("config: hot-reloaded from .env and env vars")
}
