package main

import (
	"github.com/punit/polyglot-trader-t212/brain"
	"github.com/punit/polyglot-trader-t212/t212"
)

// paperBrokerAdapter implements brain.PaperBroker backed by the PaperTrader.
type paperBrokerAdapter struct{}

var _ brain.PaperBroker = (*paperBrokerAdapter)(nil)

func (a *paperBrokerAdapter) ExecuteTrade(ticker string, side string, quantity float64, price float64, reason string) error {
	return paperTrader.ExecuteTrade(ticker, side, quantity, price, reason)
}

func (a *paperBrokerAdapter) GetPositionPrice(ticker string) float64 {
	// Try live quote first; fall back to paper position's last known price
	if p, err := t212.GetQuoteYahoo(ticker); err == nil && p > 0 {
		return p
	}
	pf := paperTrader.Portfolio()
	for _, pos := range pf.Positions {
		if pos.Ticker == ticker {
			return pos.CurrentPrice
		}
	}
	return 0
}

func (a *paperBrokerAdapter) GetEquity() float64 {
	// Portfolio() refreshes live prices internally, so equity is real.
	pf := paperTrader.Portfolio()
	return pf.TotalValue
}

// Positions exposes the durable position book for crash-recovery sync.
func (a *paperBrokerAdapter) Positions() []brain.BrokerPosition {
	pf := paperTrader.Portfolio()
	out := make([]brain.BrokerPosition, 0, len(pf.Positions))
	for _, pos := range pf.Positions {
		out = append(out, brain.BrokerPosition{
			Ticker:     pos.Ticker,
			Quantity:   pos.Quantity,
			EntryPrice: pos.EntryPrice,
			Reason:     pos.Reason,
			OpenedAt:   pos.OpenedAt,
		})
	}
	return out
}
