package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/brain"
)

// isolateStateDir points the test at a temp dir so paper_portfolio.json
// and paper_trades.json writes don't touch the real files.
func isolateStateDir(t *testing.T) {
	t.Helper()
	dir := t.TempDir()
	old, _ := os.Getwd()
	if err := os.Chdir(dir); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { os.Chdir(old) })
}

// TestRealizedOutcomes_PairsAutoRoundTrips is the one check that fails if
// the realized-P&L pairing regresses. Only "auto:" round-trips count (the
// learning loop only tracks those); a SELL realizes (exit-entry)*qty against
// the open buy. Non-auto trades (manual/kill-switch) must be ignored.
func TestRealizedOutcomes_PairsAutoRoundTrips(t *testing.T) {
	pt := &PaperTrader{tradesLog: []PaperTrade{
		{Ticker: "AAPL", Side: "BUY", Quantity: 1, Price: 100, Reason: "auto:buy"},
		{Ticker: "MSFT", Side: "BUY", Quantity: 2, Price: 50, Reason: "auto:buy"},
		{Ticker: "AAPL", Side: "SELL", Quantity: 1, Price: 110, Reason: "auto:exit"}, // +10
		{Ticker: "MSFT", Side: "SELL", Quantity: 2, Price: 45, Reason: "auto:exit"},   // -10
		{Ticker: "TSLA", Side: "BUY", Quantity: 3, Price: 200, Reason: "manual:ui"},   // non-auto → ignored
	}}
	got := pt.RealizedOutcomes()
	if len(got) != 2 {
		t.Fatalf("got %d outcomes, want 2 (only the 2 auto round-trips)", len(got))
	}
	if got[0].Ticker != "AAPL" || got[0].PnL != 10 {
		t.Errorf("AAPL outcome = %v, want ticker AAPL pnl +10", got[0])
	}
	if got[1].Ticker != "MSFT" || got[1].PnL != -10 {
		t.Errorf("MSFT outcome = %v, want ticker MSFT pnl -10", got[1])
	}
}

// TestAutoRiskGate_MarginFloorBlocksWhenFullyInvested is the one check that
// fails if the autonomous BUY path stops enforcing the margin floor.
// autoRiskGateCheck is the only path that actually places trades, yet it is
// the one that historically omitted MarginFloor (only the two HTTP risk-gate
// sites had it). A long-only paper account's free margin is its cash, so a
// >85%-deployed book must block a new BUY.
func TestAutoRiskGate_MarginFloorBlocksWhenFullyInvested(t *testing.T) {
	// Save/restore the package globals the gate reads so this test can't
	// leak state into sibling tests (they rely on fresh paperTrader / fastLoop).
	oldPF := paperTrader.portfolio
	oldLoop := fastLoop
	t.Cleanup(func() {
		paperTrader.portfolio = oldPF
		fastLoop = oldLoop
	})

	// No live loop → MacroRegime sees zero SPY data (auto-pass), and no AUC
	// metric is loaded (modelQuality nil → gate unset, auto-pass). So the only
	// gate that can flip the outcome is MarginFloor.
	fastLoop = nil

	// 100% deployed: $100 cash of $1000 equity (10% < 15% floor) → block.
	paperTrader.portfolio = PaperPortfolio{
		Cash:       100,
		Positions:  []PaperPosition{{Ticker: "AAPL", Side: "BUY", Quantity: 9, EntryPrice: 100, CurrentPrice: 100}},
		TotalValue: 1000,
	}
	setStoredPriceQuotes(t, paperTrader)
	if autoRiskGateCheck(brain.TradeDecision{Ticker: "MSFT", Action: "BUY", Price: 100}) {
		t.Errorf("expected MarginFloor to block a BUY on a fully-invested book, got allowed")
	}

	// Control: 30%% deployed ($300 cash of $1000) clears the 15% floor → pass.
	paperTrader.portfolio = PaperPortfolio{
		Cash:       300,
		Positions:  []PaperPosition{{Ticker: "AAPL", Side: "BUY", Quantity: 7, EntryPrice: 100, CurrentPrice: 100}},
		TotalValue: 1000,
	}
	setStoredPriceQuotes(t, paperTrader)
	if !autoRiskGateCheck(brain.TradeDecision{Ticker: "MSFT", Action: "BUY", Price: 100}) {
		t.Errorf("expected the gate to pass at 30%% deployed (cash above 15%% floor), got blocked")
	}
}


func TestPaperTrader_BuySell(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)

	// Buy 4 shares at $10 → cost 40
	if err := pt.ExecuteTrade("AAPL", "buy", 4, 10.0, "test"); err != nil {
		t.Fatalf("buy failed: %v", err)
	}
	pf := pt.Portfolio()
	if pf.Cash != 960 {
		t.Errorf("cash = %v, want 960", pf.Cash)
	}
	if len(pf.Positions) != 1 || pf.Positions[0].Ticker != "AAPL" {
		t.Fatalf("positions wrong: %+v", pf.Positions)
	}

	// Sell 1 share → cash 972
	if err := pt.ExecuteTrade("AAPL", "SELL", 1, 12.0, "test"); err != nil {
		t.Fatalf("sell failed: %v", err)
	}
	if got := pt.Portfolio().Cash; got != 972 {
		t.Errorf("cash = %v, want 972", got)
	}

	// State file was persisted
	if _, err := os.Stat("paper_portfolio.json"); err != nil {
		t.Error("expected paper_portfolio.json to be written")
	}

	// LastTradeAt set
	if pt.LastTradeAt().IsZero() {
		t.Error("expected LastTradeAt to be set after trade")
	}
}

func TestPaperTrader_InsufficientCash(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 100}}
	if err := pt.ExecuteTrade("AAPL", "BUY", 20, 10.0, "test"); err == nil {
		t.Error("expected insufficient cash error")
	}
}

func TestPaperTrader_InsufficientPosition(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 2, EntryPrice: 10, CurrentPrice: 10},
	}}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("AAPL", "SELL", 5, 10.0, "test"); err == nil {
		t.Error("expected insufficient position error")
	}
}

func TestPaperTrader_LoadState(t *testing.T) {
	isolateStateDir(t)
	// Write a state file, then load it
	state := PaperPortfolio{Cash: 42.5, TradesCount: 3, LastTradeAt: time.Now()}
	data, _ := json.Marshal(state)
	os.WriteFile("paper_portfolio.json", data, 0644)

	pt := &PaperTrader{}
	pt.LoadState()
	if got := pt.Portfolio().Cash; got != 42.5 {
		t.Errorf("loaded cash = %v, want 42.5", got)
	}
	if got := pt.Portfolio().TradesCount; got != 3 {
		t.Errorf("loaded trades = %v, want 3", got)
	}
}

// TestSetPaperDir_RepointsState verifies the paper account persists to the
// durable dir (and the file lands there, not in CWD) — the 2026-10-07
// restart-lost-positions regression. Hermetic: chdir to a temp CWD, point
// the state file at a separate sub-dir, exercise a real trade, restore.
func TestSetPaperDir_RepointsState(t *testing.T) {
	isolateStateDir(t) // chdir to a temp CWD
	old := paperDir
	dir := t.TempDir()
	SetPaperDir(dir)
	defer func() { paperDir = old; stateFile, tradesFile = "paper_portfolio.json", "paper_trades.json" }()

	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 100}}
	if err := pt.ExecuteTrade("AAPL", "BUY", 1, 50, "test"); err != nil {
		t.Fatalf("execute: %v", err)
	}
	// The persisted state file must land in the durable dir, not CWD.
	if _, err := os.Stat(filepath.Join(dir, "paper_portfolio.json")); err != nil {
		t.Fatalf("expected state file in %s, err=%v", dir, err)
	}
	if _, err := os.Stat("paper_portfolio.json"); err == nil {
		t.Fatalf("state file unexpectedly in CWD (SetPaperDir not repointing)")
	}
}

func TestPaperTrader_CloseAllPositions(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 10, EntryPrice: 10, CurrentPrice: 11},
	}}}
	setStoredPriceQuotes(t, pt)
	pt.CloseAllPositions()
	pf := pt.Portfolio()
	if len(pf.Positions) != 0 {
		t.Errorf("positions not closed: %+v", pf.Positions)
	}
	if got := pf.Cash; got != 210 {
		t.Errorf("cash = %v, want 210", got)
	}
}

func TestPaperTrader_FillDetailsLogged(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("MSFT", "BUY", 2, 50.0, "test"); err != nil {
		t.Fatalf("buy failed: %v", err)
	}
	last := pt.tradesLog[len(pt.tradesLog)-1]
	if last.FillDetails == "" {
		t.Error("expected fill details on trade log")
	}
}

// setStoredPriceQuotes makes Portfolio() "fetch" each position's own stored
// CurrentPrice instead of hitting real Yahoo — tests stay hermetic while
// still exercising the mark-to-market refresh path.
func setStoredPriceQuotes(t *testing.T, pt *PaperTrader) {
	t.Helper()
	pt.setQuoteFn(func(ticker string) (float64, error) {
		for _, pos := range pt.portfolio.Positions {
			if pos.Ticker == ticker {
				return pos.CurrentPrice, nil
			}
		}
		return 0, fmt.Errorf("unknown ticker %s", ticker)
	})
}

// loadPersisted reads the on-disk state file and returns the raw (persisted)
// portfolio — what a restart would see. Used to assert the persistence
// invariant: DailyPnL on disk must be REALIZED-ONLY.
func loadPersisted(t *testing.T) PaperPortfolio {
	t.Helper()
	data, err := os.ReadFile("paper_portfolio.json")
	if err != nil {
		t.Fatalf("state file missing: %v", err)
	}
	var pf PaperPortfolio
	if err := json.Unmarshal(data, &pf); err != nil {
		t.Fatalf("unmarshal state: %v", err)
	}
	return pf
}

// Invariant: unrealized mark-to-market must NOT be persisted. Buy, let price
// move, sell — the realized P&L is (12−10)·10 = +20 and the persisted
// DailyPnL must be exactly 20, not 40 (the old double-count bug).
func TestDailyPnL_NoDoubleCount_RealizedOnly(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)

	if err := pt.ExecuteTrade("AAPL", "BUY", 10, 10.0, "test"); err != nil {
		t.Fatalf("buy: %v", err)
	}

	// Price drifts to 12 → +20 unrealized, shown at read time only.
	pt.portfolio.Positions[0].CurrentPrice = 12
	pf := pt.Portfolio()
	if got := pf.DailyPnL; got != 20 {
		t.Errorf("displayed DailyPnL with +20 unrealized = %v, want 20", got)
	}
	// Persistence invariant: disk holds realized-only (nothing sold yet).
	if got := loadPersisted(t).DailyPnL; got != 0 {
		t.Errorf("persisted DailyPnL = %v, want 0 (unrealized must not persist)", got)
	}

	// Sell everything @ 12 → realized +20.
	if err := pt.ExecuteTrade("AAPL", "SELL", 10, 12.0, "test"); err != nil {
		t.Fatalf("sell: %v", err)
	}
	pf = pt.Portfolio()
	if got := pf.DailyPnL; got != 20 {
		t.Errorf("DailyPnL after full sale = %v, want 20 (realized only, no double count)", got)
	}
	if got := loadPersisted(t).DailyPnL; got != 20 {
		t.Errorf("persisted DailyPnL after sale = %v, want 20", got)
	}
	if got := pf.Cash; got != 1020 {
		t.Errorf("cash = %v, want 1020", got)
	}
}

// Invariant: realized P&L accumulates across multiple same-day sales.
func TestDailyPnL_RealizedAccumulatesSameDay(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("AAPL", "BUY", 10, 10.0, "test"); err != nil {
		t.Fatalf("buy: %v", err)
	}
	if err := pt.ExecuteTrade("MSFT", "BUY", 10, 20.0, "test"); err != nil {
		t.Fatalf("buy: %v", err)
	}
	// AAPL +5 each, MSFT −2 each.
	if err := pt.ExecuteTrade("AAPL", "SELL", 10, 15.0, "test"); err != nil {
		t.Fatalf("sell: %v", err)
	}
	if err := pt.ExecuteTrade("MSFT", "SELL", 10, 18.0, "test"); err != nil {
		t.Fatalf("sell: %v", err)
	}
	if got := pt.Portfolio().DailyPnL; got != 30 {
		t.Errorf("DailyPnL = %v, want 30 (+50 −20)", got)
	}
	if got := loadPersisted(t).DailyPnL; got != 30 {
		t.Errorf("persisted DailyPnL = %v, want 30", got)
	}
}

// Invariant: on a new calendar day the realized accumulator reads zero
// (rollover) and today's sales accumulate fresh — yesterday's realized P&L
// must not leak into today's number.
func TestDailyPnL_DayRollover(t *testing.T) {
	isolateStateDir(t)
	yesterday := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
	pt := &PaperTrader{portfolio: PaperPortfolio{
		Cash:      1000,
		DailyPnL:  50, // realized yesterday
		PnLDayKey: yesterday,
		Positions: []PaperPosition{{Ticker: "AAPL", Quantity: 10, EntryPrice: 10, CurrentPrice: 11}},
	}}
	setStoredPriceQuotes(t, pt)
	// Read today: yesterday's 50 rolled away; only unrealized (+10) shows.
	if got := pt.Portfolio().DailyPnL; got != 10 {
		t.Errorf("post-rollover displayed DailyPnL = %v, want 10 (unrealized only)", got)
	}
	// Sell today @ 12: today's realized = +20, accumulated fresh (not 50+20).
	if err := pt.ExecuteTrade("AAPL", "SELL", 10, 12.0, "test"); err != nil {
		t.Fatalf("sell: %v", err)
	}
	if got := pt.Portfolio().DailyPnL; got != 20 {
		t.Errorf("today's DailyPnL after sale = %v, want 20 (yesterday's 50 must not leak)", got)
	}
	// In-place rollover: persisted day key is today and the accumulator is
	// the fresh 20 — a second sale later today adds to 20, not to the
	// rolled-away 50.
	persisted := loadPersisted(t)
	today := time.Now().Format("2006-01-02")
	if persisted.PnLDayKey != today {
		t.Errorf("persisted PnLDayKey = %q, want today %q (in-place rollover)", persisted.PnLDayKey, today)
	}
	if persisted.DailyPnL != 20 {
		t.Errorf("persisted DailyPnL = %v, want 20", persisted.DailyPnL)
	}
}

// Invariant: partial sells realize only the closed portion; the remainder
// keeps its (weighted) entry price and marks to the sale price.
func TestDailyPnL_PartialSell(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("AAPL", "BUY", 10, 10.0, "test"); err != nil {
		t.Fatalf("buy: %v", err)
	}
	// Sell 4 @ 12 → realized +8; 6 remain, entry 10, marked 12 → unrealized +12.
	if err := pt.ExecuteTrade("AAPL", "SELL", 4, 12.0, "test"); err != nil {
		t.Fatalf("partial sell: %v", err)
	}
	pf := pt.Portfolio()
	if got := pf.DailyPnL; got != 20 {
		t.Errorf("DailyPnL = %v, want 20 (realized 8 + unrealized 12)", got)
	}
	if got := loadPersisted(t).DailyPnL; got != 8 {
		t.Errorf("persisted DailyPnL = %v, want 8 (realized only)", got)
	}
	if len(pf.Positions) != 1 {
		t.Fatalf("expected 1 remaining position, got %d", len(pf.Positions))
	}
	p := pf.Positions[0]
	if p.Quantity != 6 || p.EntryPrice != 10 || p.CurrentPrice != 12 {
		t.Errorf("remaining position = %+v, want qty 6 entry 10 current 12", p)
	}
	if got := pf.Cash; got != 948 {
		t.Errorf("cash = %v, want 948 (1000 − 100 + 48)", got)
	}
}

// Invariant: kill switch realizes every position into the daily accumulator
// and cashes out at the mark price.
func TestDailyPnL_CloseAllFoldsRealized(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{
		Cash:      100,
		DailyPnL:  5, // realized earlier today
		PnLDayKey: time.Now().Format("2006-01-02"),
		Positions: []PaperPosition{
			{Ticker: "AAPL", Quantity: 10, EntryPrice: 10, CurrentPrice: 11}, // +10
			{Ticker: "MSFT", Quantity: 5, EntryPrice: 20, CurrentPrice: 18},  // −10
		},
	}}
	setStoredPriceQuotes(t, pt)
	pt.CloseAllPositions()
	pf := pt.Portfolio()
	if got := pf.Cash; got != 300 {
		t.Errorf("cash = %v, want 300 (100 + 110 + 90)", got)
	}
	if got := pf.DailyPnL; got != 5 {
		t.Errorf("DailyPnL = %v, want 5 (5 + 10 − 10)", got)
	}
	if got := loadPersisted(t).DailyPnL; got != 5 {
		t.Errorf("persisted DailyPnL = %v, want 5", got)
	}
	if len(pf.Positions) != 0 {
		t.Errorf("positions not flattened: %+v", pf.Positions)
	}
}

// Invariant: a BUY never moves the daily P&L (no realized P&L on entry) and
// the persisted accumulator stays untouched.
func TestDailyPnL_BuyDoesNotMovePnL(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{
		Cash:      1000,
		DailyPnL:  30,
		PnLDayKey: time.Now().Format("2006-01-02"),
	}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("NVDA", "BUY", 5, 80.0, "test"); err != nil {
		t.Fatalf("buy: %v", err)
	}
	if got := loadPersisted(t).DailyPnL; got != 30 {
		t.Errorf("persisted DailyPnL after buy = %v, want 30 (buys realize nothing)", got)
	}
}

// Invariant: avg-cost weighting on adding to an existing position.
// 10 @ 10, then 10 @ 14 → entry 12. Sell all @ 16 → realized +4·20 = +80.
func TestDailyPnL_AvgCostWeighting(t *testing.T) {
	isolateStateDir(t)
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 5000}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("AAPL", "BUY", 10, 10.0, "test"); err != nil {
		t.Fatalf("buy: %v", err)
	}
	if err := pt.ExecuteTrade("AAPL", "BUY", 10, 14.0, "test"); err != nil {
		t.Fatalf("buy add: %v", err)
	}
	if got := pt.Portfolio().Positions[0].EntryPrice; got != 12 {
		t.Errorf("weighted entry = %v, want 12", got)
	}
	if err := pt.ExecuteTrade("AAPL", "SELL", 20, 16.0, "test"); err != nil {
		t.Fatalf("sell: %v", err)
	}
	if got := pt.Portfolio().DailyPnL; got != 80 {
		t.Errorf("DailyPnL = %v, want 80", got)
	}
	if got := loadPersisted(t).DailyPnL; got != 80 {
		t.Errorf("persisted DailyPnL = %v, want 80", got)
	}
}

func TestHandleSystemStatus(t *testing.T) {
	isolateStateDir(t)
	// Pin a real loop so we can drive a known last-cycle; restore the global.
	oldFL := fastLoop
	fastLoop = brain.NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, time.Minute)
	defer func() { fastLoop = oldFL }()

	// 1) Loop alive (cycled 2h ago), trade 2h ago → not stale.
	fastLoop.SetLastCycle(time.Now().Add(-2 * time.Hour))
	*paperTrader = PaperTrader{portfolio: PaperPortfolio{Cash: 100, LastTradeAt: time.Now().Add(-2 * time.Hour)}}
	w := callSystemStatus(t)
	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["status"] != "ok" {
		t.Errorf("status = %v, want ok", resp["status"])
	}
	if resp["stale"] != false {
		t.Errorf("stale = %v, want false (loop cycled 2h ago)", resp["stale"])
	}

	// 2) Dead loop (last cycle 25h ago) → stale, even though a trade is recent.
	fastLoop.SetLastCycle(time.Now().Add(-25 * time.Hour))
	*paperTrader = PaperTrader{portfolio: PaperPortfolio{Cash: 100, LastTradeAt: time.Now().Add(-2 * time.Hour)}}
	w = callSystemStatus(t)
	var resp2 map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp2)
	if resp2["stale"] != true {
		t.Errorf("stale = %v, want true (loop last cycled 25h ago)", resp2["stale"])
	}

	// 3) Regression: the old code keyed "stale" to the last FILL. A live loop
	// holding already-open positions (no new trades in 30h) got flagged dead.
	// Now it must read not-stale because the loop is plainly alive.
	fastLoop.SetLastCycle(time.Now().Add(-1 * time.Hour))
	*paperTrader = PaperTrader{portfolio: PaperPortfolio{Cash: 100, LastTradeAt: time.Now().Add(-30 * time.Hour)}}
	w = callSystemStatus(t)
	var resp3 map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp3)
	if resp3["stale"] != false {
		t.Errorf("stale = %v, want false (loop cycled 1h ago; no-trade-for-30h must not read dead)", resp3["stale"])
	}
}

func callSystemStatus(t *testing.T) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest("GET", "/api/system/status", nil)
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleSystemStatus)(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", w.Code, w.Body.String())
	}
	return w
}

func TestUpdateModelQualityGate(t *testing.T) {
	// With mlOrch nil, must not panic
	updateModelQualityGate()
}

func TestReconcilePositions_NoDiscrepancy(t *testing.T) {
	// t212Client will error in tests (no network) → function must handle gracefully
	reconcilePositions(false)
}

// TestRestart_NoDuplicateBuy pins the money-path restart invariant behind
// main.go: the durable paper portfolio MUST be loaded (SetPaperDir +
// LoadState) before AutoExecutor.SyncFromBroker. If it isn't, openTrades is
// rebuilt from an empty in-memory book, and the next eligible BUY double-buys
// a position the broker already holds (the NVDA 0.4211 = 0.2106×2 incident).
//
// This is hermetic (own PaperTrader + temp dir, not the package-global
// paperTrader) and asserts the load-order contract directly: LoadState first
// → SyncFromBroker sees the position → a repeat BUY is suppressed (no double).
func TestRestart_NoDuplicateBuy(t *testing.T) {
	isolateStateDir(t)
	dir := t.TempDir()
	SetPaperDir(dir)
	defer func() {
		stateFile, tradesFile = "paper_portfolio.json", "paper_trades.json"
	}()

	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("NVDA", "BUY", 0.2, 240.0, "auto:open"); err != nil {
		t.Fatalf("initial buy: %v", err)
	}
	pt.saveStateLocked() // persist to dir, as main does before the loop starts

	// Restart: a fresh in-memory book, then the load-order under test.
	restarted := &PaperTrader{}
	restarted.LoadState() // main.go: LoadState BEFORE SyncFromBroker

	// paperBrokerAdapter is bound to the package-global paperTrader; point
	// it at the restarted book so the test stays self-contained.
	gOld := paperTrader
	paperTrader = restarted
	defer func() { paperTrader = gOld }()

	ae := brain.NewAutoExecutor(&paperBrokerAdapter{}, brain.NewLearningLoop(5), nil)
	ae.SyncFromBroker(&paperBrokerAdapter{})

	// The auto-traded NVDA position (reason "auto:…") must be restored into
	// openTrades, so a second identical BUY is a no-op, not a doubling.
	if got := ae.GetOpenTrades()["NVDA"]; got == nil {
		t.Fatalf("SyncFromBroker did not restore NVDA after restart — openTrades = %v", ae.GetOpenTrades())
	}
	cashBefore := pt.Portfolio().Cash
	ae.ExecuteDecision(brain.TradeDecision{Ticker: "NVDA", Action: "BUY", Confidence: 0.59, Price: 240.0, Model: "default", Reason: "open"})
	qty := 0.0
	for _, p := range pt.portfolio.Positions {
		if p.Ticker == "NVDA" {
			qty = p.Quantity
		}
	}
	if qty > 0.25 {
		t.Errorf("duplicate buy on restart: NVDA qty = %v, want 0.2 (one position)", qty)
	}
	if got, want := pt.Portfolio().Cash, cashBefore; got < want {
		t.Errorf("cash dropped on suppressed BUY: %v < %v", got, want)
	}
}
