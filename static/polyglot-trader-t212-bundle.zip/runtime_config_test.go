package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestConfigGet(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/config", nil)
	w := httptest.NewRecorder()
	handleConfig(w, req)
	if w.Code != 200 {
		t.Fatalf("GET /api/config: got %d, want 200", w.Code)
	}
	var resp map[string]interface{}
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatal("invalid JSON:", err)
	}
	if _, ok := resp["config"]; !ok {
		t.Fatal("missing 'config' key")
	}
}

func TestConfigPostAndApply(t *testing.T) {
	// Save originals
	orig := runtimeCfg.Snapshot()
	defer func() {
		runtimeMu.Lock()
		*runtimeCfg = orig
		runtimeMu.Unlock()
	}()

	body := bytes.NewBufferString(`{"max_order_value": 75, "stop_loss_pct": -5}`)
	req := httptest.NewRequest(http.MethodPost, "/api/config", body)
	w := httptest.NewRecorder()
	handleConfig(w, req)
	if w.Code != 200 {
		t.Fatalf("POST /api/config: got %d, want 200", w.Code)
	}
	got := runtimeCfg.Snapshot()
	if got.MaxOrderValue != 75 {
		t.Errorf("MaxOrderValue = %v, want 75", got.MaxOrderValue)
	}
	if got.StopLossPct != -5 {
		t.Errorf("StopLossPct = %v, want -5", got.StopLossPct)
	}
}

func TestConfigRejectsBadConfidence(t *testing.T) {
	orig := runtimeCfg.Snapshot()
	defer func() {
		runtimeMu.Lock()
		*runtimeCfg = orig
		runtimeMu.Unlock()
	}()

	body := bytes.NewBufferString(`{"min_confidence": 99}`)
	req := httptest.NewRequest(http.MethodPost, "/api/config", body)
	w := httptest.NewRecorder()
	handleConfig(w, req)
	if w.Code != 200 {
		t.Fatalf("POST /api/config: got %d, want 200", w.Code)
	}
	got := runtimeCfg.Snapshot()
	if got.MinConfidence > 1 || got.MinConfidence <= 0 {
		t.Errorf("MinConfidence = %v, should still be valid (0,1]", got.MinConfidence)
	}
}
