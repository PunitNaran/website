package brain

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/data"
	"github.com/punit/polyglot-trader-t212/mlservice"
)

// === test helpers ===

type mockBroker struct {
	equity    float64
	prices    map[string]float64
	trades    []string
	failNext  bool
	positions map[string]*BrokerPosition
}

func newMockBroker(equity float64) *mockBroker {
	return &mockBroker{equity: equity, prices: map[string]float64{}, positions: map[string]*BrokerPosition{}}
}

func (b *mockBroker) ExecuteTrade(ticker, side string, qty, price float64, reason string) error {
	if b.failNext {
		b.failNext = false
		return errors.New("boom")
	}
	b.trades = append(b.trades, ticker+":"+side)
	switch side {
	case "BUY":
		b.positions[ticker] = &BrokerPosition{
			Ticker:     ticker,
			Quantity:   qty,
			EntryPrice: price,
			Reason:     reason,
			OpenedAt:   time.Now(),
		}
	case "SELL":
		delete(b.positions, ticker)
	}
	return nil
}

func (b *mockBroker) GetPositionPrice(ticker string) float64 { return b.prices[ticker] }
func (b *mockBroker) GetEquity() float64                     { return b.equity }

func (b *mockBroker) Positions() []BrokerPosition {
	out := make([]BrokerPosition, 0, len(b.positions))
	for _, p := range b.positions {
		out = append(out, *p)
	}
	return out
}

// fakeMLDir creates a temp dir with a fake inference.py returning fixed probabilities.
func fakeMLDir(t *testing.T, label string, prob float64) *mlservice.Orchestrator {
	t.Helper()
	dir := t.TempDir()
	modelDir := filepath.Join(dir, "model")
	if err := os.MkdirAll(modelDir, 0755); err != nil {
		t.Fatal(err)
	}
	script := `import json, os, datetime
prob = float(os.environ.get('FAKE_PROB', 0.8))
label = os.environ.get('FAKE_LABEL', 'hold')
other = (1 - prob) / 2
probs = {"buy": other, "sell": other, "hold": other}
probs[label] = prob
print(json.dumps({"probabilities": probs, "predicted_at": datetime.datetime.utcnow().isoformat()+"Z"}))
`
	if err := os.WriteFile(filepath.Join(dir, "inference.py"), []byte(script), 0755); err != nil {
		t.Fatal(err)
	}
	// mustFindScript() requires train.py for the ML_SCRIPT_DIR override
	if err := os.WriteFile(filepath.Join(dir, "train.py"), []byte("print('ok')\n"), 0644); err != nil {
		t.Fatal(err)
	}
	info := map[string]interface{}{
		"model_path":    filepath.Join(modelDir, "model.txt"),
		"feature_names": []string{"f1"},
		"metrics":       map[string]float64{"auc_val": 0.8},
		"saved_at":      time.Now().Format(time.RFC3339),
	}
	b, _ := json.Marshal(info)
	if err := os.WriteFile(filepath.Join(modelDir, "model_info.json"), b, 0644); err != nil {
		t.Fatal(err)
	}
	t.Setenv("ML_SCRIPT_DIR", dir)
	t.Setenv("PYTHON_PATH", "python3")
	o := mlservice.NewOrchestrator(modelDir, t.TempDir(), mlservice.DefaultConfig())
	if err := o.LoadModel(); err != nil {
		t.Fatal(err)
	}
	return o
}

// fakeMLDirNoModel creates an orchestrator with no loaded model (Predict errors).
func fakeMLDirNoModel(t *testing.T) *mlservice.Orchestrator {
	t.Helper()
	dir := t.TempDir()
	script := "print('{}')"
	if err := os.WriteFile(filepath.Join(dir, "inference.py"), []byte(script), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "train.py"), []byte("print('ok')\n"), 0644); err != nil {
		t.Fatal(err)
	}
	t.Setenv("ML_SCRIPT_DIR", dir)
	t.Setenv("PYTHON_PATH", "python3")
	return mlservice.NewOrchestrator(filepath.Join(dir, "model"), t.TempDir(), mlservice.DefaultConfig())
}

// fakeYahooServer returns an httptest server serving one valid ticker.
func fakeYahooServer(t *testing.T) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.Contains(r.URL.Path, "/AAPL") {
			w.WriteHeader(404)
			return
		}
		n := 150 // FeatureEngine requires lookback(120) + 1 bars
		quote := make([]float64, n)
		ts := make([]int64, n)
		now := time.Now().Unix()
		for i := 0; i < n; i++ {
			quote[i] = 100.0 + float64(i)*0.1
			ts[i] = now - int64(n-i)*86400
		}
		resp := map[string]interface{}{
			"chart": map[string]interface{}{
				"result": []map[string]interface{}{
					{
						"meta":      map[string]string{"range": "1y"},
						"timestamp": ts,
						"indicators": map[string]interface{}{
							"quote": []map[string]interface{}{
								{
									"open":   quote,
									"high":   quote,
									"low":    quote,
									"close":  quote,
									"volume": quote,
								},
							},
						},
					},
				},
			},
		}
		json.NewEncoder(w).Encode(resp)
	}))
}

func fetcherFromServer(s *httptest.Server) *data.HistoryFetcher {
	f := data.NewHistoryFetcher()
	f.SetBaseURL(s.URL)
	return f
}

// newFastLoopWithDeps builds a FastLoop with a working store, fetcher, and ML.
func newFastLoopWithDeps(t *testing.T, tickers []string, interval time.Duration) (*FastLoop, *mlservice.Orchestrator) {
	t.Helper()
	store, err := data.NewStore(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	srv := fakeYahooServer(t)
	t.Cleanup(srv.Close)
	fl := NewFastLoop(store, fetcherFromServer(srv), data.NewFeatureEngine(), nil, tickers, interval)
	o := fakeMLDir(t, "hold", 0.8)
	fl.ml = o
	return fl, o
}

// setFakePrediction sets env for the fake inference.py.
func setFakePrediction(t *testing.T, label string, prob float64) {
	t.Helper()
	t.Setenv("FAKE_LABEL", label)
	t.Setenv("FAKE_PROB", fmt.Sprintf("%f", prob))
}

// === DriftDetector ===

func TestDriftDetector_LastCheck(t *testing.T) {
	d := NewDriftDetector(10)
	before := time.Now()
	got := d.LastCheck()
	if got.Before(before) {
		t.Errorf("LastCheck returned time in the past")
	}
}

// === AutoExecutor ===

func TestAutoExecutor_ExecuteDecision_Buy(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	if len(b.trades) != 1 || b.trades[0] != "AAPL:BUY" {
		t.Fatalf("expected AAPL:BUY trade, got %v", b.trades)
	}
	if ot := ae.GetOpenTrades()["AAPL"]; ot == nil || ot.Quantity <= 0 {
		t.Error("expected open trade with positive quantity")
	}
}

func TestAutoExecutor_DailyBudget(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	// Budget £50; equity 1000, 10% sizer → posValue 100 > 50, clamps to 50
	ae.SetBudgets(50, 0, 0)
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	if ae.spent["daily"] < 49 || ae.spent["daily"] > 51 {
		t.Fatalf("expected daily spent ~50, got %v", ae.spent["daily"])
	}
	// Second buy: budget exhausted → no trade
	ae.ExecuteDecision(TradeDecision{Ticker: "MSFT", Action: "BUY", Price: 100})
	if len(b.trades) != 1 {
		t.Fatalf("expected budget block, got trades %v", b.trades)
	}
	// New day → budget resets, trade allowed
	ae.spentKey["daily"] = "2000-01-01"
	ae.ExecuteDecision(TradeDecision{Ticker: "MSFT", Action: "BUY", Price: 100})
	if len(b.trades) != 2 {
		t.Fatalf("expected reset trade, got trades %v", b.trades)
	}
}

func TestAutoExecutor_BudgetState_ExpiredKeyReset(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.SetBudgets(50, 0, 0)
	ae.spent["daily"] = 30
	ae.spentKey["daily"] = "2000-01-01" // stale period
	bs := ae.GetBudgetState()
	if bs.Spent["daily"] != 0 {
		t.Fatalf("expected spent reset to 0 on expired key, got %v", bs.Spent["daily"])
	}
	if bs.DateKey["daily"] != time.Now().Format("2006-01-02") {
		t.Fatalf("expected fresh daily key, got %v", bs.DateKey["daily"])
	}
}

func TestFastLoop_SyncRingVolFactors(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, []string{"T"}, time.Second)
	fl.decisions = []TradeDecision{{Ticker: "T", Action: "BUY"}}
	fl.syncRingVolFactorsLocked([]*TradeDecision{{Ticker: "T", VolFactor: 1.5}})
	if fl.decisions[0].VolFactor != 1.5 {
		t.Fatalf("expected ring VolFactor 1.5, got %v", fl.decisions[0].VolFactor)
	}
}

func TestAutoExecutor_ExecuteDecision_AlreadyLong(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	if len(b.trades) != 1 {
		t.Errorf("expected 1 trade (dedup), got %d", len(b.trades))
	}
}

func TestAutoExecutor_ExecuteDecision_InvalidPrice(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: -1})
	if len(b.trades) != 0 {
		t.Errorf("expected no trades for invalid price, got %v", b.trades)
	}
}

func TestAutoExecutor_ExecuteDecision_ZeroEquity(t *testing.T) {
	b := newMockBroker(0)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	if len(b.trades) != 0 {
		t.Errorf("expected no trades with zero equity, got %v", b.trades)
	}
}

func TestAutoExecutor_ExecuteDecision_BuyError(t *testing.T) {
	b := newMockBroker(1000)
	b.failNext = true
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	if len(ae.GetOpenTrades()) != 0 {
		t.Error("expected no open trades after buy failure")
	}
}

func TestAutoExecutor_ExecuteDecision_Sell(t *testing.T) {
	b := newMockBroker(1000)
	ll := NewLearningLoop(20)
	ae := NewAutoExecutor(b, ll, NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100, Model: "default"})
	b.prices["AAPL"] = 110
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "SELL"})
	if ot := ae.GetOpenTrades()["AAPL"]; ot != nil {
		t.Error("expected open trade closed")
	}
	stats := ll.GetStats("default")
	if stats.Trades != 1 || stats.Expectancy < 0 {
		t.Errorf("expected positive PnL recorded, trades=%d expectancy=%f", stats.Trades, stats.Expectancy)
	}
}

func TestAutoExecutor_ExecuteDecision_SellNoPosition(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "SELL"})
	if len(b.trades) != 0 {
		t.Errorf("expected no trades selling without position, got %v", b.trades)
	}
}

func TestAutoExecutor_ExecuteDecision_SellError(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	b.prices["AAPL"] = 110
	b.failNext = true
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "SELL"})
	if ot := ae.GetOpenTrades()["AAPL"]; ot == nil {
		t.Error("expected trade to remain open after sell failure")
	}
}

func TestAutoExecutor_MonitorOpenTrades_StopLoss(t *testing.T) {
	b := newMockBroker(1000)
	ll := NewLearningLoop(20)
	ae := NewAutoExecutor(b, ll, NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100, Model: "default"})
	b.prices["AAPL"] = 95 // -5% → stop loss
	ae.MonitorOpenTrades()
	if ot := ae.GetOpenTrades()["AAPL"]; ot != nil {
		t.Error("expected stop-loss exit")
	}
	if ll.GetStats("default").Trades != 1 {
		t.Error("expected outcome recorded for stop-loss")
	}
}

func TestAutoExecutor_MonitorOpenTrades_TakeProfit(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	b.prices["AAPL"] = 110 // +10% → take profit
	ae.MonitorOpenTrades()
	if ot := ae.GetOpenTrades()["AAPL"]; ot != nil {
		t.Error("expected take-profit exit")
	}
}

func TestAutoExecutor_MonitorOpenTrades_FlatAndNoPrice(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	ae.ExecuteDecision(TradeDecision{Ticker: "MSFT", Action: "BUY", Price: 50})
	b.prices["AAPL"] = 101 // +1%, no action
	// MSFT price stays 0 → skip
	ae.MonitorOpenTrades()
	if len(ae.GetOpenTrades()) != 2 {
		t.Errorf("expected trades to stay open, got %d", len(ae.GetOpenTrades()))
	}
}

func TestAutoExecutor_MonitorOpenTrades_SellError(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	b.prices["AAPL"] = 95 // triggers stop loss
	b.failNext = true
	ae.MonitorOpenTrades()
	if ot := ae.GetOpenTrades()["AAPL"]; ot == nil {
		t.Error("expected trade to remain open after monitor sell failure")
	}
}

func TestAutoExecutor_GetOpenTrades_Snapshot(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	snap := ae.GetOpenTrades()
	delete(snap, "AAPL") // mutate snapshot
	if ot := ae.GetOpenTrades()["AAPL"]; ot == nil {
		t.Error("expected original map unaffected by snapshot mutation")
	}
}

func TestAutoExecutor_CloseAll(t *testing.T) {
	b := newMockBroker(1000)
	ll := NewLearningLoop(20)
	ae := NewAutoExecutor(b, ll, NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	ae.ExecuteDecision(TradeDecision{Ticker: "MSFT", Action: "BUY", Price: 50})
	b.prices["MSFT"] = 0 // exercise entry-price fallback
	ae.CloseAll()
	if len(ae.GetOpenTrades()) != 0 {
		t.Errorf("expected no open trades after CloseAll, got %d", len(ae.GetOpenTrades()))
	}
	sells := 0
	for _, tr := range b.trades {
		if strings.HasSuffix(tr, ":SELL") {
			sells++
		}
	}
	if sells != 2 {
		t.Errorf("expected 2 SELL trades, got %d", sells)
	}
}

func TestAutoExecutor_CloseAll_SellError(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	b.failNext = true
	ae.CloseAll()
	if ot := ae.GetOpenTrades()["AAPL"]; ot == nil {
		t.Error("expected trade to remain open after close-all failure")
	}
}

func TestAutoExecutor_Start_MonitorLoop(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100})
	b.prices["AAPL"] = 95 // stop loss fires on first tick
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		ae.Start(ctx, 20*time.Millisecond)
		close(done)
	}()
	time.Sleep(80 * time.Millisecond)
	cancel()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("Start did not stop after cancel")
	}
	if ot := ae.GetOpenTrades()["AAPL"]; ot != nil {
		t.Error("expected monitor loop to close stop-loss trade")
	}
}

// === SyncFromBroker (crash recovery) ===

func TestAutoExecutor_SyncFromBroker_RestoresAutoTrades(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	// Simulate a durable broker state: one auto trade + one manual position.
	b.positions["AAPL"] = &BrokerPosition{
		Ticker: "AAPL", Quantity: 10, EntryPrice: 100,
		Reason: "auto:gbr", OpenedAt: time.Now().Add(-time.Hour),
	}
	b.positions["MSFT"] = &BrokerPosition{
		Ticker: "MSFT", Quantity: 2, EntryPrice: 50,
		Reason: "manual_api", OpenedAt: time.Now().Add(-time.Hour),
	}
	ae.SyncFromBroker(b)
	ot := ae.GetOpenTrades()
	if len(ot) != 1 {
		t.Fatalf("expected 1 restored auto trade (manual excluded), got %d: %v", len(ot), ot)
	}
	if t2 := ot["AAPL"]; t2 == nil || t2.Model != "default" || t2.EntryPrice != 100 {
		t.Errorf("restored trade wrong: %+v (model should be champion 'default', not the reason string)", t2)
	}
}

func TestAutoExecutor_SyncFromBroker_DropsStale(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	// Stale in-memory entry: position no longer open at broker (flattened by kill switch).
	ae.openTrades["AAPL"] = &openTrade{Ticker: "AAPL", Quantity: 1, EntryPrice: 100, Model: "gbr", EntryTime: time.Now()}
	ae.SyncFromBroker(b)
	if len(ae.GetOpenTrades()) != 0 {
		t.Fatalf("expected stale entry dropped, got %v", ae.GetOpenTrades())
	}
}

func TestAutoExecutor_SyncFromBroker_Idempotent(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))
	ae.ExecuteDecision(TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 100, Reason: "gbr"})
	if len(ae.GetOpenTrades()) != 1 {
		t.Fatal("expected 1 open trade after buy")
	}
	ae.SyncFromBroker(b)
	ae.SyncFromBroker(b)
	if len(ae.GetOpenTrades()) != 1 {
		t.Fatalf("expected sync to be idempotent, got %v", ae.GetOpenTrades())
	}
}

// === FastLoop: evaluateTicker / runCycle / getters ===

func TestFastLoop_EvaluateTicker_FetchError(t *testing.T) {
	store, err := data.NewStore(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	f := data.NewHistoryFetcher()
	f.SetBaseURL("http://127.0.0.1:1") // unreachable → fetch error
	fl := NewFastLoop(store, f, data.NewFeatureEngine(), nil, nil, time.Second)
	if d := fl.evaluateTicker("AAPL"); d != nil {
		t.Error("expected nil decision on fetch error")
	}
}

func TestFastLoop_EvaluateTicker_InsufficientBars(t *testing.T) {
	store, err := data.NewStore(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// return only 5 bars (< 30)
		ts := []int64{1, 2, 3, 4, 5}
		q := []float64{1, 2, 3, 4, 5}
		resp := map[string]interface{}{
			"chart": map[string]interface{}{
				"result": []map[string]interface{}{
					{"meta": map[string]string{"range": "1y"},
						"timestamp": ts,
						"indicators": map[string]interface{}{
							"quote": []map[string]interface{}{
								{"open": q, "high": q, "low": q, "close": q, "volume": q},
							},
						}},
				},
			},
		}
		json.NewEncoder(w).Encode(resp)
	}))
	defer srv.Close()
	f := data.NewHistoryFetcher()
	f.SetBaseURL(srv.URL)
	fl := NewFastLoop(store, f, data.NewFeatureEngine(), nil, nil, time.Second)
	if d := fl.evaluateTicker("AAPL"); d != nil {
		t.Error("expected nil decision for insufficient bars")
	}
}

func TestFastLoop_EvaluateTicker_BuySellHold(t *testing.T) {
	fl, _ := newFastLoopWithDeps(t, []string{"AAPL"}, time.Second)

	// BUY
	setFakePrediction(t, "buy", 0.9)
	d := fl.evaluateTicker("AAPL")
	if d == nil || d.Action != "BUY" {
		t.Errorf("expected BUY decision, got %+v", d)
	}

	// SELL
	setFakePrediction(t, "sell", 0.9)
	d2 := fl.evaluateTicker("AAPL")
	if d2 == nil || d2.Action != "SELL" {
		t.Errorf("expected SELL decision, got %+v", d2)
	}

	// HOLD: p_up in the hysteresis deadband (0.45 < p < 0.55)
	setFakePrediction(t, "buy", 0.50)
	d3 := fl.evaluateTicker("AAPL")
	if d3 == nil || d3.Action != "HOLD" {
		t.Errorf("expected HOLD decision, got %+v", d3)
	}

	// HOLD: drawdown breach blocks buy
	fl.risk.UpdateEquity(1000)
	fl.risk.UpdateEquity(900)
	setFakePrediction(t, "buy", 0.9)
	d4 := fl.evaluateTicker("AAPL")
	if d4 == nil || d4.Action != "HOLD" {
		t.Errorf("expected HOLD on drawdown breach, got %+v", d4)
	}
}

func TestFastLoop_Run_FullCycle(t *testing.T) {
	fl, _ := newFastLoopWithDeps(t, []string{"AAPL"}, 20*time.Millisecond)
	setFakePrediction(t, "buy", 0.9)

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		fl.Run(ctx)
		close(done)
	}()
	time.Sleep(80 * time.Millisecond)
	cancel()
	<-done

	if fl.GetLastCycle().IsZero() {
		t.Error("expected lastCycle set after run")
	}
	if len(fl.GetDecisions(10)) < 1 {
		t.Errorf("expected at least 1 decision, got %d", len(fl.GetDecisions(10)))
	}
	if fl.GetLearning() == nil || fl.GetRisk() == nil || fl.GetChampionChallenger() == nil {
		t.Error("expected non-nil component getters")
	}
}

func TestFastLoop_Run_MLFailureStopsCycle(t *testing.T) {
	store, err := data.NewStore(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	srv := fakeYahooServer(t)
	t.Cleanup(srv.Close)
	f := data.NewHistoryFetcher()
	f.SetBaseURL(srv.URL)
	fl := NewFastLoop(store, f, data.NewFeatureEngine(), nil, []string{"AAPL"}, 10*time.Millisecond)
	fl.ml = fakeMLDirNoModel(t) // no model_info.json → Predict errors
	fl.runCycle()
	if fl.GetLastCycle().IsZero() {
		t.Error("expected lastCycle set even when prediction fails")
	}
	if len(fl.GetDecisions(10)) != 0 {
		t.Errorf("expected no decisions on ML failure, got %d", len(fl.GetDecisions(10)))
	}
}

// SPY regime hysteresis: entry at -0.5%, exit only at +0.5% band.
func TestSpyRegime_Hysteresis(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	sma := 100.0

	set := func(price float64) {
		fl.mu.Lock()
		fl.spyPrice = price
		fl.spyEMA = sma
		switch {
		case !fl.spyBelowSMA && price < sma*spyBearEnter:
			fl.spyBelowSMA = true
		case fl.spyBelowSMA && price > sma*spyBearExit:
			fl.spyBelowSMA = false
		}
		fl.mu.Unlock()
	}

	set(100) // at the SMA: bull
	fl.mu.RLock()
	if fl.spyBelowSMA {
		t.Fatal("expected bull at SMA level")
	}
	fl.mu.RUnlock()

	set(99.9) // 0.1% below: inside band, must stay bull (no flip)
	fl.mu.RLock()
	if fl.spyBelowSMA {
		t.Fatal("band wobble must not enter bear regime")
	}
	fl.mu.RUnlock()

	set(99.4) // 0.6% below: crosses entry threshold
	fl.mu.RLock()
	if !fl.spyBelowSMA {
		t.Fatal("expected bear regime entry at -0.5%")
	}
	fl.mu.RUnlock()

	set(100.1) // back above SMA but inside band: must stay bear (no exit)
	fl.mu.RLock()
	if !fl.spyBelowSMA {
		t.Fatal("must stay in bear regime until +0.5% exit band")
	}
	fl.mu.RUnlock()

	set(100.6) // 0.6% above: crosses exit threshold
	fl.mu.RLock()
	if fl.spyBelowSMA {
		t.Fatal("expected bull regime exit at +0.5%")
	}
	fl.mu.RUnlock()
}
