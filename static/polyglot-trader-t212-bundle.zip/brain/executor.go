package brain

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"time"
)

// PaperBroker is the interface for executing paper trades.
// Implemented by the main package's PaperTrader to avoid import cycles.
type PaperBroker interface {
	ExecuteTrade(ticker string, side string, quantity float64, price float64, reason string) error
	GetPositionPrice(ticker string) float64
	GetEquity() float64
	// Positions is the durable source of truth for open positions.
	Positions() []BrokerPosition
}

// BrokerPosition is the broker-side view of an open position, used for
// crash recovery (see AutoExecutor.SyncFromBroker).
type BrokerPosition struct {
	Ticker     string
	Quantity   float64
	EntryPrice float64
	Reason     string
	OpenedAt   time.Time
}

// PositionSizer sizes a position as a fraction of equity. Structural
// interface so brain can use risk.QuarterKellySizer / FixedFractionSizer
// without an import cycle.
type PositionSizer interface {
	Size(probability float64, equity float64) float64
}

// AutoExecutor converts ML decisions into paper trades with outcome tracking.
type AutoExecutor struct {
	broker   PaperBroker
	learning *LearningLoop
	champion *ChampionChallenger
	sizer    PositionSizer

	mu         sync.Mutex
	openTrades map[string]*openTrade
	equityPeak float64
	lastEquity float64

	// Risk limits (all 0/negative = use default or unlimited)
	maxOrder float64            // max notional per order (0 = unlimited)
	stopPct  float64            // stop loss %, negative (e.g. -4)
	takePct  float64            // take profit %, positive (e.g. 8)
	budgets  map[string]float64 // daily / weekly / monthly caps (0 = unlimited)
	spent    map[string]float64 // spent per period
	spentKey map[string]string  // period key when spent was last reset

	maxHoldDays int // time stop: close positions older than this (0 = disabled)
}

// BudgetState is the live budget usage snapshot for API/UI.
type BudgetState struct {
	Daily    float64            `json:"daily"`
	Weekly   float64            `json:"weekly"`
	Monthly  float64            `json:"monthly"`
	MaxOrder float64            `json:"max_order"`
	StopPct  float64            `json:"stop_pct"`
	TakePct  float64            `json:"take_pct"`
	Spent    map[string]float64 `json:"spent"`
	DateKey  map[string]string  `json:"date_key"`
}

type openTrade struct {
	Ticker     string
	Quantity   float64
	EntryPrice float64
	Model      string
	EntryTime  time.Time
}

// championModel returns the champion model name, or "default" when the
// champion manager is nil (hermetic tests construct AutoExecutor without one).
func (ae *AutoExecutor) championModel() string {
	if ae.champion == nil {
		return "default"
	}
	return ae.champion.GetChampion()
}

// SyncFromBroker rebuilds ae.openTrades from the broker's durable position
// book after a restart. The broker's persisted state is the source of truth;
// this in-memory map is not. Without this, a crash between a broker fill and
// the openTrades bookkeeping below would re-issue a duplicate BUY on restart,
// and a kill-switch flatten would leave phantom entries.
func (ae *AutoExecutor) SyncFromBroker(b PaperBroker) {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	restored := 0
	open := map[string]BrokerPosition{}
	for _, p := range b.Positions() {
		open[p.Ticker] = p
	}
	// Drop in-memory entries no longer open at the broker (stale after restart).
	for ticker := range ae.openTrades {
		if _, stillOpen := open[ticker]; !stillOpen {
			delete(ae.openTrades, ticker)
		}
	}
	// Restore broker-side auto positions missing from memory.
	for _, p := range open {
		if _, exists := ae.openTrades[p.Ticker]; exists {
			continue
		}
		if p.Reason == "" || !strings.HasPrefix(p.Reason, "auto:") {
			continue // manual/kill-switch position — not an auto trade
		}
		ae.openTrades[p.Ticker] = &openTrade{
			Ticker:     p.Ticker,
			Quantity:   p.Quantity,
			EntryPrice: p.EntryPrice,
			// ponytail: restore the model the FRESH path records (champion),
			// not the per-trade reason string. The reason string is
			// unique per trade (confidence/momentum), so keying learning
			// stats on it fragmented every outcome into its own 1-trade
			// "model" and starved the promotion gate.
			Model:      ae.championModel(),
			EntryTime:  p.OpenedAt,
		}
		restored++
	}
	if restored > 0 {
		slog.Info("auto executor: restored open trades from broker", "restored", restored, "total", len(ae.openTrades))
	}
}

// fixedFractionSizer allocates a constant fraction of equity per position.
type fixedFractionSizer struct{ fraction float64 }

func (f fixedFractionSizer) Size(_, equity float64) float64 {
	return equity * f.fraction
}

// NewAutoExecutor creates a paper trade executor with learning feedback.
func NewAutoExecutor(broker PaperBroker, learning *LearningLoop, champion *ChampionChallenger) *AutoExecutor {
	return &AutoExecutor{
		broker:     broker,
		learning:   learning,
		champion:   champion,
		sizer:      fixedFractionSizer{fraction: 0.10},
		openTrades: make(map[string]*openTrade),
		budgets:    map[string]float64{},
		spent:      map[string]float64{},
		spentKey:   map[string]string{},
		stopPct:    -4,
		takePct:    8,
	}
}

// SetSizer configures the position-sizing strategy (e.g. a Kelly sizer).
func (ae *AutoExecutor) SetSizer(s PositionSizer) {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	ae.sizer = s
}

// SetBudgets sets daily/weekly/monthly notional caps. 0 = unlimited.
func (ae *AutoExecutor) SetBudgets(daily, weekly, monthly float64) {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	ae.budgets["daily"] = daily
	ae.budgets["weekly"] = weekly
	ae.budgets["monthly"] = monthly
}

// SetMaxOrderValue caps the notional per order. 0 = unlimited.
func (ae *AutoExecutor) SetMaxOrderValue(v float64) {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	ae.maxOrder = v
}

// SetStopTakeLoss configures the monitor exit levels (%).
func (ae *AutoExecutor) SetStopTakeLoss(stop, take float64) {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	if stop < 0 {
		ae.stopPct = stop
	}
	if take > 0 {
		ae.takePct = take
	}
}

// SetMaxHoldDays sets the time stop: positions held longer than this
// (in days) are closed at the next monitor tick. 0 disables it.
func (ae *AutoExecutor) SetMaxHoldDays(days int) {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	ae.maxHoldDays = days
}

// periodKey returns the period identifier for a period type.
func periodKey(period string, now time.Time) string {
	switch period {
	case "daily":
		return now.Format("2006-01-02")
	case "weekly":
		y, w := now.ISOWeek()
		return fmt.Sprintf("%d-W%02d", y, w)
	case "monthly":
		return now.Format("2006-01")
	}
	return ""
}

// checkBudget clamps posValue to the remaining budget across all caps.
// Returns (ok, allowedValue).
func (ae *AutoExecutor) checkBudget(posValue float64, now time.Time) (bool, float64) {
	for period, capVal := range ae.budgets {
		if capVal <= 0 {
			continue
		}
		key := periodKey(period, now)
		if ae.spentKey[period] != key {
			ae.spent[period] = 0
			ae.spentKey[period] = key
		}
		remaining := capVal - ae.spent[period]
		if remaining < posValue {
			posValue = remaining
		}
	}
	return posValue > 0, posValue
}

// GetBudgetState returns the live budget caps and usage.
func (ae *AutoExecutor) GetBudgetState() BudgetState {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	// ponytail: reset expired periods on read so the API never reports a
	// stale date_key (the reset used to happen only on the next order).
	now := time.Now()
	for p := range ae.budgets {
		key := periodKey(p, now)
		if ae.spentKey[p] != "" && ae.spentKey[p] != key {
			ae.spent[p] = 0
			ae.spentKey[p] = key
		}
	}
	bs := BudgetState{
		MaxOrder: ae.maxOrder,
		StopPct:  ae.stopPct,
		TakePct:  ae.takePct,
		Spent:    map[string]float64{},
		DateKey:  map[string]string{},
	}
	for p, capVal := range ae.budgets {
		if p == "daily" {
			bs.Daily = capVal
		} else if p == "weekly" {
			bs.Weekly = capVal
		} else if p == "monthly" {
			bs.Monthly = capVal
		}
		bs.Spent[p] = ae.spent[p]
		bs.DateKey[p] = ae.spentKey[p]
	}
	return bs
}

// ExecuteDecision acts on a trade decision via paper trading.
func (ae *AutoExecutor) ExecuteDecision(d TradeDecision) {
	ae.mu.Lock()
	defer ae.mu.Unlock()

	switch d.Action {
	case "BUY":
		if _, exists := ae.openTrades[d.Ticker]; exists {
			return // already long
		}
		equity := ae.broker.GetEquity()
		if equity <= 0 || d.Price <= 0 {
			return
		}
		posValue := ae.sizer.Size(d.Confidence, equity)

		// Vol-scaled sizing: high-vol names get smaller positions,
		// low-vol names get larger. VolFactor is clamped [0.5, 2.0].
		if d.VolFactor > 0 {
			posValue *= d.VolFactor
		}

		// Max order value cap
		if ae.maxOrder > 0 && posValue > ae.maxOrder {
			posValue = ae.maxOrder
		}

		// Budget guards: clamp to remaining across daily/weekly/monthly caps
		now := time.Now()
		ok, v := ae.checkBudget(posValue, now)
		if !ok {
			return
		}
		posValue = v

		qty := posValue / d.Price
		if qty <= 0 {
			return
		}
		if err := ae.broker.ExecuteTrade(d.Ticker, "BUY", qty, d.Price, "auto:"+d.Reason); err != nil {
			slog.Error("auto buy failed", "ticker", d.Ticker, "error", err)
			return
		}
		// Record spend in each period (only on successful fill)
		for period := range ae.budgets {
			if ae.budgets[period] > 0 {
				key := periodKey(period, now)
				if ae.spentKey[period] != key {
					ae.spent[period] = 0
					ae.spentKey[period] = key
				}
				ae.spent[period] += posValue
			}
		}

		ae.openTrades[d.Ticker] = &openTrade{
			Ticker:     d.Ticker,
			Quantity:   qty,
			EntryPrice: d.Price,
			Model:      d.Model,
			EntryTime:  now,
		}
		slog.Info("AUTO BUY executed", "ticker", d.Ticker, "qty", qty, "price", d.Price, "model", d.Model, "value", posValue)

	case "SELL":
		trade, exists := ae.openTrades[d.Ticker]
		if !exists {
			return
		}
		exitPrice := ae.broker.GetPositionPrice(d.Ticker)
		if exitPrice <= 0 {
			exitPrice = d.Price
		}
		if err := ae.broker.ExecuteTrade(d.Ticker, "SELL", trade.Quantity, exitPrice, "auto:exit"); err != nil {
			slog.Error("auto sell failed", "ticker", d.Ticker, "error", err)
			return
		}
		ae.recordOutcome(trade, exitPrice)
		delete(ae.openTrades, d.Ticker)
		slog.Info("AUTO SELL executed", "ticker", d.Ticker, "qty", trade.Quantity, "exit", exitPrice)
	}

	ae.lastEquity = ae.broker.GetEquity()
	if ae.lastEquity > ae.equityPeak {
		ae.equityPeak = ae.lastEquity
	}
}

// recordOutcome computes PnL and feeds back to the learning loop.
func (ae *AutoExecutor) recordOutcome(trade *openTrade, exitPrice float64) {
	pnl := (exitPrice - trade.EntryPrice) * trade.Quantity
	ae.learning.RecordOutcome(TradeOutcome{
		Ticker:     trade.Ticker,
		Side:       "BUY",
		Model:      trade.Model,
		PnL:        pnl,
		HoldingSec: time.Since(trade.EntryTime).Seconds(),
	})
	slog.Info("trade outcome recorded",
		"ticker", trade.Ticker,
		"model", trade.Model,
		"pnl", pnl,
		"holding_sec", time.Since(trade.EntryTime).Seconds(),
	)
}

// MonitorOpenTrades checks open trades for stop-loss/take-profit.
func (ae *AutoExecutor) MonitorOpenTrades() {
	ae.mu.Lock()
	defer ae.mu.Unlock()

	for ticker, trade := range ae.openTrades {
		current := ae.broker.GetPositionPrice(ticker)
		if current <= 0 {
			continue
		}
		pnlPct := (current - trade.EntryPrice) / trade.EntryPrice * 100

		// Stop loss / take profit / time stop at configured levels
		age := time.Since(trade.EntryTime).Hours() / 24
		timeStop := ae.maxHoldDays > 0 && age >= float64(ae.maxHoldDays)
		if pnlPct <= ae.stopPct || pnlPct >= ae.takePct || timeStop {
			if err := ae.broker.ExecuteTrade(ticker, "SELL", trade.Quantity, current, "auto:exit"); err != nil {
				slog.Error("monitor sell failed", "ticker", ticker, "error", err)
				continue
			}
			ae.recordOutcome(trade, current)
			delete(ae.openTrades, ticker)
			slog.Info("MONITOR exit", "ticker", ticker, "pnl_pct", pnlPct,
				"stop", ae.stopPct, "take", ae.takePct, "age_days", age, "time_stop", timeStop)
		}
	}
}

// GetOpenTrades returns a snapshot of open auto-trades.
func (ae *AutoExecutor) GetOpenTrades() map[string]*openTrade {
	ae.mu.Lock()
	defer ae.mu.Unlock()
	out := make(map[string]*openTrade, len(ae.openTrades))
	for k, v := range ae.openTrades {
		out[k] = v
	}
	return out
}

// CloseAll closes all open auto-trades (e.g. on kill switch).
func (ae *AutoExecutor) CloseAll() {
	ae.mu.Lock()
	defer ae.mu.Unlock()

	for ticker, trade := range ae.openTrades {
		price := ae.broker.GetPositionPrice(ticker)
		if price <= 0 {
			price = trade.EntryPrice
		}
		if err := ae.broker.ExecuteTrade(ticker, "SELL", trade.Quantity, price, "auto:flatten"); err != nil {
			slog.Error("close-all sell failed", "ticker", ticker, "error", err)
			continue
		}
		ae.recordOutcome(trade, price)
		delete(ae.openTrades, ticker)
	}
	slog.Info("all auto-trades flattened")
}

// Start launches background monitoring of open trades.
func (ae *AutoExecutor) Start(ctx context.Context, interval time.Duration) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			ae.MonitorOpenTrades()
		}
	}
}
