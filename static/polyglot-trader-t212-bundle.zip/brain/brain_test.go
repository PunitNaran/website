package brain

import (
	"context"
	"sync"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/mlservice"
)

// === predictionLabel tests ===

func TestPredictionLabel_BuyDominant(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{
			"buy":  0.6,
			"sell": 0.1,
			"hold": 0.3,
		},
	}
	if got := predictionLabel(pred); got != "buy" {
		t.Errorf("expected buy, got %s", got)
	}
}

func TestPredictionLabel_SellDominant(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{
			"buy":  0.2,
			"sell": 0.7,
			"hold": 0.1,
		},
	}
	if got := predictionLabel(pred); got != "sell" {
		t.Errorf("expected sell, got %s", got)
	}
}

func TestPredictionLabel_HoldDominant(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{
			"buy":  0.15,
			"sell": 0.1,
			"hold": 0.75,
		},
	}
	if got := predictionLabel(pred); got != "hold" {
		t.Errorf("expected hold, got %s", got)
	}
}

func TestPredictionLabel_AllEqual_DefaultsToHold(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{
			"buy":  0.33,
			"sell": 0.33,
			"hold": 0.34,
		},
	}
	if got := predictionLabel(pred); got != "hold" {
		t.Errorf("expected hold on tie, got %s", got)
	}
}

func TestPredictionLabel_EmptyMap(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{},
	}
	if got := predictionLabel(pred); got != "hold" {
		t.Errorf("expected hold on empty, got %s", got)
	}
}

func TestPredictionLabel_NilMap(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: nil,
	}
	if got := predictionLabel(pred); got != "hold" {
		t.Errorf("expected hold on nil, got %s", got)
	}
}

func TestPredictionLabel_SingleEntry(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{
			"sell": 1.0,
		},
	}
	if got := predictionLabel(pred); got != "sell" {
		t.Errorf("expected sell, got %s", got)
	}
}

func TestPredictionLabel_ZeroProbabilities(t *testing.T) {
	pred := &mlservice.InferenceResult{
		Probabilities: map[string]float64{
			"buy":  0,
			"sell": 0,
			"hold": 0,
		},
	}
	// All zero: first found wins in iteration (nondeterministic), but bestProb starts at 0
	// so it returns "hold" (initial value) since no prob > 0
	if got := predictionLabel(pred); got != "hold" {
		t.Errorf("expected hold on all zeros, got %s", got)
	}
}

// === DriftDetector tests ===

func TestDriftDetector_New_DefaultWindowSize(t *testing.T) {
	d := NewDriftDetector(0)
	if d.windowSize != 50 {
		t.Errorf("expected default window size 50, got %d", d.windowSize)
	}
}

func TestDriftDetector_New_CustomWindowSize(t *testing.T) {
	d := NewDriftDetector(100)
	if d.windowSize != 100 {
		t.Errorf("expected window size 100, got %d", d.windowSize)
	}
}

func TestDriftDetector_RecordPrediction_WindowTruncation(t *testing.T) {
	d := NewDriftDetector(5)
	for i := 0; i < 10; i++ {
		d.RecordPrediction("model1", 0.8)
	}
	d.mu.RLock()
	w := d.performances["model1"]
	d.mu.RUnlock()
	if len(w.Predictions) != 5 {
		t.Errorf("expected 5 predictions (window size), got %d", len(w.Predictions))
	}
	// Should keep the last 5
	for _, v := range w.Predictions {
		if v != 0.8 {
			t.Errorf("expected 0.8, got %f", v)
		}
	}
}

func TestDriftDetector_RecordOutcome_WindowTruncation(t *testing.T) {
	d := NewDriftDetector(5)
	for i := 0; i < 10; i++ {
		d.RecordOutcome("model1", true)
	}
	d.mu.RLock()
	w := d.performances["model1"]
	d.mu.RUnlock()
	if len(w.Outcomes) != 5 {
		t.Errorf("expected 5 outcomes (window size), got %d", len(w.Outcomes))
	}
}

func TestDriftDetector_CheckDrift_InsufficientData(t *testing.T) {
	d := NewDriftDetector(50)
	// Record fewer than 20 outcomes
	for i := 0; i < 15; i++ {
		d.RecordOutcome("model1", true)
	}
	drifted, reason := d.CheckDrift("model1")
	if drifted {
		t.Errorf("expected no drift with insufficient data")
	}
	if reason != "insufficient data" {
		t.Errorf("expected 'insufficient data', got %q", reason)
	}
}

func TestDriftDetector_CheckDrift_UnknownModel(t *testing.T) {
	d := NewDriftDetector(50)
	drifted, reason := d.CheckDrift("unknown")
	if drifted {
		t.Errorf("expected no drift for unknown model")
	}
	if reason != "insufficient data" {
		t.Errorf("expected 'insufficient data', got %q", reason)
	}
}

func TestDriftDetector_CheckDrift_NoDrift(t *testing.T) {
	d := NewDriftDetector(50)
	// Record consistent performance: 50% win rate throughout
	for i := 0; i < 30; i++ {
		if i%2 == 0 {
			d.RecordOutcome("model1", true) // win
		} else {
			d.RecordOutcome("model1", false) // loss
		}
	}
	drifted, reason := d.CheckDrift("model1")
	if drifted {
		t.Errorf("expected no drift, got drift reason: %s", reason)
	}
}

func TestDriftDetector_CheckDrift_DegradationDetected(t *testing.T) {
	d := NewDriftDetector(50)
	// Early: 80% win rate (16 wins, 4 losses out of 20)
	for i := 0; i < 20; i++ {
		if i < 16 {
			d.RecordOutcome("model1", true)
		} else {
			d.RecordOutcome("model1", false)
		}
	}
	// Recent: 30% win rate (6 wins, 14 losses out of 20)
	for i := 0; i < 20; i++ {
		if i < 6 {
			d.RecordOutcome("model1", true)
		} else {
			d.RecordOutcome("model1", false)
		}
	}
	drifted, reason := d.CheckDrift("model1")
	if !drifted {
		t.Errorf("expected drift to be detected")
	}
	if reason != "performance degradation" {
		t.Errorf("expected 'performance degradation', got %q", reason)
	}
}

func TestDriftDetector_CheckDrift_ImprovementNotDrift(t *testing.T) {
	d := NewDriftDetector(50)
	// Early: 30% win rate
	for i := 0; i < 20; i++ {
		if i < 6 {
			d.RecordOutcome("model1", true)
		} else {
			d.RecordOutcome("model1", false)
		}
	}
	// Recent: 80% win rate (improvement)
	for i := 0; i < 20; i++ {
		if i < 16 {
			d.RecordOutcome("model1", true)
		} else {
			d.RecordOutcome("model1", false)
		}
	}
	drifted, _ := d.CheckDrift("model1")
	if drifted {
		t.Errorf("expected no drift for improvement")
	}
}

func TestDriftDetector_CheckDrift_EarlyRateTooLow(t *testing.T) {
	d := NewDriftDetector(50)
	// Early: 20% win rate (below 0.4 threshold)
	for i := 0; i < 20; i++ {
		if i < 4 {
			d.RecordOutcome("model1", true)
		} else {
			d.RecordOutcome("model1", false)
		}
	}
	// Recent: 0% win rate
	for i := 0; i < 20; i++ {
		d.RecordOutcome("model1", false)
	}
	drifted, _ := d.CheckDrift("model1")
	if drifted {
		t.Errorf("expected no drift when early rate is below threshold")
	}
}

func TestDriftDetector_GetConfidenceStats_UnknownModel(t *testing.T) {
	d := NewDriftDetector(50)
	meanConf, recentMeanConf := d.GetConfidenceStats("unknown")
	if meanConf != 0 || recentMeanConf != 0 {
		t.Errorf("expected zeros for unknown model, got (%f, %f)", meanConf, recentMeanConf)
	}
}

func TestDriftDetector_GetConfidenceStats_EmptyPredictions(t *testing.T) {
	d := NewDriftDetector(50)
	// Only outcomes, no predictions
	d.RecordOutcome("model1", true)
	meanConf, recentMeanConf := d.GetConfidenceStats("model1")
	if meanConf != 0 || recentMeanConf != 0 {
		t.Errorf("expected zeros when no predictions, got (%f, %f)", meanConf, recentMeanConf)
	}
}

func TestDriftDetector_GetConfidenceStats_WithPredictions(t *testing.T) {
	d := NewDriftDetector(50)
	d.RecordPrediction("model1", 0.6)
	d.RecordPrediction("model1", 0.8)
	meanConf, _ := d.GetConfidenceStats("model1")
	expected := (0.6 + 0.8) / 2
	if meanConf < expected-0.001 || meanConf > expected+0.001 {
		t.Errorf("expected mean confidence ~%f, got %f", expected, meanConf)
	}
}

func TestDriftDetector_GetConfidenceStats_RecentWindow(t *testing.T) {
	d := NewDriftDetector(100)
	// Record 30 predictions with varying values
	for i := 0; i < 30; i++ {
		d.RecordPrediction("model1", 0.5)
	}
	// Add 20 higher confidence predictions at the end
	for i := 0; i < 20; i++ {
		d.RecordPrediction("model1", 1.0)
	}
	_, recentMeanConf := d.GetConfidenceStats("model1")
	// Recent 20 should all be 1.0
	if recentMeanConf < 1.0-0.001 {
		t.Errorf("expected recent mean ~1.0, got %f", recentMeanConf)
	}
}

func TestMean_Empty(t *testing.T) {
	if mean([]float64{}) != 0 {
		t.Errorf("expected 0 for empty slice")
	}
}

func TestMean_SingleValue(t *testing.T) {
	if got := mean([]float64{5.5}); got != 5.5 {
		t.Errorf("expected 5.5, got %f", got)
	}
}

func TestMean_MultipleValues(t *testing.T) {
	if got := mean([]float64{1, 2, 3, 4, 5}); got != 3.0 {
		t.Errorf("expected 3.0, got %f", got)
	}
}

// === LearningLoop tests ===

func TestLearningLoop_New_DefaultMinTrades(t *testing.T) {
	ll := NewLearningLoop(0)
	if ll.minTrades != 20 {
		t.Errorf("expected default min trades 20, got %d", ll.minTrades)
	}
}

func TestLearningLoop_New_CustomMinTrades(t *testing.T) {
	ll := NewLearningLoop(50)
	if ll.minTrades != 50 {
		t.Errorf("expected min trades 50, got %d", ll.minTrades)
	}
}

func TestLearningLoop_RecordOutcome_FirstWin(t *testing.T) {
	ll := NewLearningLoop(10)
	ll.RecordOutcome(TradeOutcome{
		Model: "model1",
		PnL:   100,
	})
	stats := ll.GetStats("model1")
	if stats.Trades != 1 {
		t.Errorf("expected 1 trade, got %d", stats.Trades)
	}
	if stats.WinRate != 1.0 {
		t.Errorf("expected 100%% win rate, got %f", stats.WinRate)
	}
	if stats.Expectancy < 100-0.01 || stats.Expectancy > 100+0.01 {
		t.Errorf("expected expectancy ~100, got %f", stats.Expectancy)
	}
}

func TestLearningLoop_RecordOutcome_FirstLoss(t *testing.T) {
	ll := NewLearningLoop(10)
	ll.RecordOutcome(TradeOutcome{
		Model: "model1",
		PnL:   -50,
	})
	stats := ll.GetStats("model1")
	if stats.WinRate != 0 {
		t.Errorf("expected 0%% win rate, got %f", stats.WinRate)
	}
}

func TestLearningLoop_RecordOutcome_Multiple(t *testing.T) {
	ll := NewLearningLoop(10)
	ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 100})
	ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: -50})
	ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 75})
	ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: -25})
	stats := ll.GetStats("model1")
	if stats.Trades != 4 {
		t.Errorf("expected 4 trades, got %d", stats.Trades)
	}
	if stats.WinRate != 0.5 {
		t.Errorf("expected 50%% win rate, got %f", stats.WinRate)
	}
	expectedPnL := 100.0 - 50.0 + 75.0 - 25.0
	if stats.Expectancy < expectedPnL/4-0.01 || stats.Expectancy > expectedPnL/4+0.01 {
		t.Errorf("expected expectancy ~%f, got %f", expectedPnL/4, stats.Expectancy)
	}
}

func TestLearningLoop_GetStats_UnknownModel(t *testing.T) {
	ll := NewLearningLoop(10)
	stats := ll.GetStats("unknown")
	if stats.IsQualified {
		t.Errorf("expected not qualified for unknown model")
	}
	if stats.Trades != 0 {
		t.Errorf("expected 0 trades, got %d", stats.Trades)
	}
}

func TestLearningLoop_GetStats_InsufficientTrades(t *testing.T) {
	ll := NewLearningLoop(20)
	for i := 0; i < 15; i++ {
		ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 100})
	}
	stats := ll.GetStats("model1")
	if stats.IsQualified {
		t.Errorf("expected not qualified with insufficient trades")
	}
}

func TestLearningLoop_GetStats_InsufficientWinRate(t *testing.T) {
	ll := NewLearningLoop(20)
	// 20 trades, only 8 wins (40% < 50%)
	for i := 0; i < 20; i++ {
		if i < 8 {
			ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 100})
		} else {
			ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: -10})
		}
	}
	stats := ll.GetStats("model1")
	if stats.IsQualified {
		t.Errorf("expected not qualified with insufficient win rate")
	}
}

func TestLearningLoop_GetStats_Qualified(t *testing.T) {
	ll := NewLearningLoop(20)
	// 25 trades, 15 wins (60%), decent variance
	for i := 0; i < 25; i++ {
		if i < 15 {
			ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 100})
		} else {
			ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: -20})
		}
	}
	stats := ll.GetStats("model1")
	if !stats.IsQualified {
		t.Errorf("expected qualified model, got not qualified")
	}
	if stats.WinRate < 0.5-0.001 {
		t.Errorf("expected win rate > 50%%, got %f", stats.WinRate)
	}
}

func TestLearningLoop_GetAllStats(t *testing.T) {
	ll := NewLearningLoop(10)
	ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 100})
	ll.RecordOutcome(TradeOutcome{Model: "model2", PnL: -50})
	all := ll.GetAllStats()
	if len(all) != 2 {
		t.Errorf("expected 2 models, got %d", len(all))
	}
	if _, ok := all["model1"]; !ok {
		t.Errorf("expected model1 in stats")
	}
	if _, ok := all["model2"]; !ok {
		t.Errorf("expected model2 in stats")
	}
}

func TestLearningLoop_GetOutcomeHistory_Limit(t *testing.T) {
	ll := NewLearningLoop(10)
	for i := 0; i < 100; i++ {
		ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 10, Ticker: string(rune('A' + i%26))})
	}
	hist := ll.GetOutcomeHistory(10)
	if len(hist) != 10 {
		t.Errorf("expected 10 outcomes, got %d", len(hist))
	}
	// Should return most recent
	lastTicker := hist[len(hist)-1].Ticker
	expectedTicker := string(rune('A' + 99%26))
	if lastTicker != expectedTicker {
		t.Errorf("expected last ticker %s, got %s", expectedTicker, lastTicker)
	}
}

func TestLearningLoop_GetOutcomeHistory_ZeroLimit(t *testing.T) {
	ll := NewLearningLoop(10)
	ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 10})
	hist := ll.GetOutcomeHistory(0)
	if len(hist) != 1 {
		t.Errorf("expected all outcomes with limit 0, got %d", len(hist))
	}
}

func TestLearningLoop_OutcomeHistoryTruncation(t *testing.T) {
	ll := NewLearningLoop(10)
	for i := 0; i < 1100; i++ {
		ll.RecordOutcome(TradeOutcome{Model: "model1", PnL: 10})
	}
	ll.mu.RLock()
	histLen := len(ll.outcomeHistory)
	ll.mu.RUnlock()
	if histLen > 1000 {
		t.Errorf("expected history capped at 1000, got %d", histLen)
	}
}

// === ChampionChallenger tests ===

func TestChampionChallenger_New_Defaults(t *testing.T) {
	ll := NewLearningLoop(10)
	cc := NewChampionChallenger(ll)
	if cc.champion != "default" {
		t.Errorf("expected champion 'default', got %q", cc.champion)
	}
	if cc.challenger != "" {
		t.Errorf("expected empty challenger, got %q", cc.challenger)
	}
}

func TestChampionChallenger_SetChallenger(t *testing.T) {
	ll := NewLearningLoop(10)
	cc := NewChampionChallenger(ll)
	cc.SetChallenger("model2")
	if cc.GetChallenger() != "model2" {
		t.Errorf("expected challenger 'model2', got %q", cc.GetChallenger())
	}
}

func TestChampionChallenger_EvaluatePromotion_NoChallenger(t *testing.T) {
	ll := NewLearningLoop(10)
	cc := NewChampionChallenger(ll)
	promoted, reason := cc.EvaluatePromotion()
	if promoted {
		t.Errorf("expected no promotion without challenger")
	}
	if reason == "" {
		t.Errorf("expected reason for no promotion")
	}
}

func TestChampionChallenger_EvaluatePromotion_SameModel(t *testing.T) {
	ll := NewLearningLoop(10)
	cc := NewChampionChallenger(ll)
	cc.SetChallenger("default")
	promoted, _ := cc.EvaluatePromotion()
	if promoted {
		t.Errorf("expected no promotion when challenger is champion")
	}
}

func TestChampionChallenger_EvaluatePromotion_UnqualifiedChallenger(t *testing.T) {
	ll := NewLearningLoop(20)
	cc := NewChampionChallenger(ll)
	cc.SetChallenger("challenger")
	// Only 5 trades for challenger (below min of 20)
	for i := 0; i < 5; i++ {
		ll.RecordOutcome(TradeOutcome{Model: "challenger", PnL: 100})
	}
	// Champion has no trades
	promoted, reason := cc.EvaluatePromotion()
	if promoted {
		t.Errorf("expected no promotion for unqualified challenger")
	}
	if reason == "" {
		t.Errorf("expected reason")
	}
}

func TestChampionChallenger_EvaluatePromotion_ChallengerWorseWinRate(t *testing.T) {
	ll := NewLearningLoop(20)
	cc := NewChampionChallenger(ll)
	cc.SetChallenger("challenger")

	// Champion: 25 trades, 20 wins (80%)
	for i := 0; i < 25; i++ {
		if i < 20 {
			ll.RecordOutcome(TradeOutcome{Model: "default", PnL: 100})
		} else {
			ll.RecordOutcome(TradeOutcome{Model: "default", PnL: -10})
		}
	}

	// Challenger: 25 trades, 10 wins (40%)
	for i := 0; i < 25; i++ {
		if i < 10 {
			ll.RecordOutcome(TradeOutcome{Model: "challenger", PnL: 100})
		} else {
			ll.RecordOutcome(TradeOutcome{Model: "challenger", PnL: -10})
		}
	}

	promoted, _ := cc.EvaluatePromotion()
	if promoted {
		t.Errorf("expected no promotion when challenger has worse win rate")
	}
}

func TestChampionChallenger_EvaluatePromotion_Success(t *testing.T) {
	ll := NewLearningLoop(20)
	cc := NewChampionChallenger(ll)
	cc.SetChallenger("challenger")

	// Champion: 25 trades, 15 wins (60%), consistent PnL
	for i := 0; i < 25; i++ {
		if i < 15 {
			ll.RecordOutcome(TradeOutcome{Model: "default", PnL: 100})
		} else {
			ll.RecordOutcome(TradeOutcome{Model: "default", PnL: -10})
		}
	}

	// Challenger: 25 trades, 20 wins (80%) - clearly better
	for i := 0; i < 25; i++ {
		if i < 20 {
			ll.RecordOutcome(TradeOutcome{Model: "challenger", PnL: 100})
		} else {
			ll.RecordOutcome(TradeOutcome{Model: "challenger", PnL: -10})
		}
	}

	promoted, reason := cc.EvaluatePromotion()
	if !promoted {
		t.Errorf("expected promotion, got none. Reason: %s", reason)
	}
	if cc.GetChampion() != "challenger" {
		t.Errorf("expected champion to be 'challenger', got %q", cc.GetChampion())
	}
	if cc.GetChallenger() != "" {
		t.Errorf("expected challenger to be cleared, got %q", cc.GetChallenger())
	}
}

// === AdaptiveRisk tests ===

func TestAdaptiveRisk_New_Defaults(t *testing.T) {
	ar := NewAdaptiveRisk()
	if ar.MaxPositionPct != 10 {
		t.Errorf("expected MaxPositionPct 10, got %f", ar.MaxPositionPct)
	}
	if ar.MaxDrawdownPct != 5 {
		t.Errorf("expected MaxDrawdownPct 5, got %f", ar.MaxDrawdownPct)
	}
	if ar.MinConfidence != 0.55 {
		t.Errorf("expected MinConfidence 0.55, got %f", ar.MinConfidence)
	}
	if ar.MaxConcurrentTrades != 5 {
		t.Errorf("expected MaxConcurrentTrades 5, got %d", ar.MaxConcurrentTrades)
	}
}

func TestAdaptiveRisk_GetCurrentRisk_NoDrawdown(t *testing.T) {
	ar := NewAdaptiveRisk()
	rp := ar.GetCurrentRisk()
	if rp.PositionSizeMultiplier != 1.0 {
		t.Errorf("expected multiplier 1.0 with no drawdown, got %f", rp.PositionSizeMultiplier)
	}
	if rp.MinConfidence != 0.55 {
		t.Errorf("expected base MinConfidence 0.55, got %f", rp.MinConfidence)
	}
}

func TestAdaptiveRisk_GetCurrentRisk_ModerateDrawdown(t *testing.T) {
	ar := NewAdaptiveRisk()
	// Set equity to create drawdown
	ar.UpdateEquity(1000)
	ar.UpdateEquity(850) // 15% drawdown
	rp := ar.GetCurrentRisk()
	// 15% / 5% = 3.0 > 0.8, so should be 0.25 multiplier
	if rp.PositionSizeMultiplier != 0.25 {
		t.Errorf("expected 0.25 multiplier for high drawdown, got %f", rp.PositionSizeMultiplier)
	}
	if rp.MinConfidence < 0.65-0.001 {
		t.Errorf("expected increased MinConfidence >= 0.65, got %f", rp.MinConfidence)
	}
}

func TestAdaptiveRisk_GetCurrentRisk_LightDrawdown(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(980) // 2% drawdown
	rp := ar.GetCurrentRisk()
	// 2% / 5% = 0.4 < 0.5, so should be 1.0 multiplier
	if rp.PositionSizeMultiplier != 1.0 {
		t.Errorf("expected 1.0 multiplier for light drawdown, got %f", rp.PositionSizeMultiplier)
	}
}

func TestAdaptiveRisk_GetCurrentRisk_MediumDrawdown(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(965) // 3.5% drawdown
	rp := ar.GetCurrentRisk()
	// 3.5% / 5% = 0.7: > 0.5 but < 0.8, so 0.5 multiplier
	if rp.PositionSizeMultiplier != 0.5 {
		t.Errorf("expected 0.5 multiplier for medium drawdown, got %f", rp.PositionSizeMultiplier)
	}
}

func TestAdaptiveRisk_UpdateEquity_NewPeak(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(1200)
	ar.UpdateEquity(1100)
	dd := ar.GetCurrentDrawdown()
	// Peak is 1200, current 1100, dd = (1200-1100)/1200*100 = 8.33%
	expectedDD := (1200.0 - 1100.0) / 1200.0 * 100
	if dd < expectedDD-0.01 || dd > expectedDD+0.01 {
		t.Errorf("expected dd ~%f, got %f", expectedDD, dd)
	}
}

func TestAdaptiveRisk_UpdateEquity_AtPeak(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(1500)
	dd := ar.GetCurrentDrawdown()
	if dd != 0 {
		t.Errorf("expected 0 drawdown at peak, got %f", dd)
	}
}

func TestAdaptiveRisk_UpdateEquity_NonPositive(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(0)    // Should be ignored
	ar.UpdateEquity(-100) // Should be ignored
	dd := ar.GetCurrentDrawdown()
	if dd != 0 {
		t.Errorf("expected 0 drawdown, got %f", dd)
	}
}

func TestAdaptiveRisk_IsDrawdownBreached_NotBreached(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(960) // 4% drawdown < 5% max
	if ar.IsDrawdownBreached() {
		t.Errorf("expected no breach")
	}
}

func TestAdaptiveRisk_IsDrawdownBreached_AtLimit(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(950) // 5% drawdown == 5% max
	if !ar.IsDrawdownBreached() {
		t.Errorf("expected breach at limit")
	}
}

func TestAdaptiveRisk_IsDrawdownBreached_Exceeded(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.UpdateEquity(1000)
	ar.UpdateEquity(940) // 6% drawdown > 5% max
	if !ar.IsDrawdownBreached() {
		t.Errorf("expected breach when exceeded")
	}
}

func TestAdaptiveRisk_SetParameters(t *testing.T) {
	ar := NewAdaptiveRisk()
	ar.SetParameters(5, 3, 0.7)
	rp := ar.GetCurrentRisk()
	if rp.MaxPositionPct != 5 {
		t.Errorf("expected 5, got %f", rp.MaxPositionPct)
	}
	if rp.MaxDrawdownPct != 3 {
		t.Errorf("expected 3, got %f", rp.MaxDrawdownPct)
	}
	if rp.MinConfidence != 0.7 {
		t.Errorf("expected 0.7, got %f", rp.MinConfidence)
	}
}

// === FastLoop basic tests (no external dependencies) ===

func TestFastLoop_SetRetrainCallback_RateLimited(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	var mu sync.Mutex
	calls := 0
	fl.SetRetrainCallback(func() {
		mu.Lock()
		calls++
		mu.Unlock()
	})
	getCalls := func() int {
		mu.Lock()
		defer mu.Unlock()
		return calls
	}

	// First trigger should invoke callback (async via go func)
	fl.triggerRetrain("test")
	time.Sleep(50 * time.Millisecond)
	if got := getCalls(); got != 1 {
		t.Errorf("expected 1 call, got %d", got)
	}

	// Second trigger within 6h should be rate-limited
	fl.triggerRetrain("test again")
	time.Sleep(50 * time.Millisecond)
	if got := getCalls(); got != 1 {
		t.Errorf("expected rate limiting to prevent second call, got %d", got)
	}
}

func TestFastLoop_TriggerRetrain_NilCallback(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	// Should not panic with nil callback
	fl.triggerRetrain("test")
}

func TestFastLoop_GetDecisions_Empty(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	d := fl.GetDecisions(10)
	if len(d) != 0 {
		t.Errorf("expected empty decisions, got %d", len(d))
	}
}

func TestFastLoop_GetDecisions_LimitClamped(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	fl.mu.Lock()
	fl.decisions = []TradeDecision{
		{Ticker: "A", Action: "BUY"},
		{Ticker: "B", Action: "SELL"},
		{Ticker: "C", Action: "HOLD"},
	}
	fl.mu.Unlock()

	// Limit larger than available
	d := fl.GetDecisions(100)
	if len(d) != 3 {
		t.Errorf("expected 3, got %d", len(d))
	}

	// Limit smaller
	d = fl.GetDecisions(2)
	if len(d) != 2 {
		t.Errorf("expected 2, got %d", len(d))
	}
	// Should return most recent
	if d[0].Ticker != "B" || d[1].Ticker != "C" {
		t.Errorf("expected [B, C], got [%s, %s]", d[0].Ticker, d[1].Ticker)
	}

	// Limit 0 returns all
	d = fl.GetDecisions(0)
	if len(d) != 3 {
		t.Errorf("expected all with limit 0, got %d", len(d))
	}
}

// TestFastLoop_DecisionsRingBounded verifies the decision ring trims to
// maxDecisionsBound (keeping the most recent) once it grows past the cap —
// the guard that stops unbounded memory growth across 60s cycles.
func TestFastLoop_DecisionsRingBounded(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	fl.mu.Lock()
	for i := 0; i < maxDecisionsBound+10; i++ {
		fl.decisions = append(fl.decisions, TradeDecision{Ticker: "T", Action: "HOLD"})
	}
	fl.mu.Unlock()

	fl.mu.Lock()
	if len(fl.decisions) > maxDecisionsBound {
		fl.decisions = append([]TradeDecision(nil), fl.decisions[len(fl.decisions)-maxDecisionsBound:]...)
	}
	fl.mu.Unlock()

	d := fl.GetDecisions(0)
	if len(d) != maxDecisionsBound {
		t.Errorf("expected ring capped at %d, got %d", maxDecisionsBound, len(d))
	}
}

func TestFastLoop_SetEnabled(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	if !fl.IsEnabled() {
		t.Errorf("expected enabled by default")
	}
	fl.SetEnabled(false)
	if fl.IsEnabled() {
		t.Errorf("expected disabled")
	}
	fl.SetEnabled(true)
	if !fl.IsEnabled() {
		t.Errorf("expected enabled")
	}
}

// === TradeDecision tests ===

func TestTradeDecision_Struct(t *testing.T) {
	td := TradeDecision{
		Ticker:     "AAPL",
		Action:     "BUY",
		Confidence: 0.85,
		Price:      150.50,
		Reason:     "ML signal",
		Model:      "champion",
		Timestamp:  time.Now(),
	}
	if td.Ticker != "AAPL" {
		t.Errorf("expected AAPL, got %s", td.Ticker)
	}
	if td.Action != "BUY" {
		t.Errorf("expected BUY, got %s", td.Action)
	}
}

// === evaluateTicker / runCycle integration tests ===

func TestFastLoop_Run_StopsOnContextCancel(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, []string{"AAPL"}, 50*time.Millisecond)
	fl.enabled = true
	fl.mu.Lock()
	// prevent actual ticker processing by emptying tickers (evaluateTicker needs deps)
	fl.tickers = []string{}
	fl.mu.Unlock()

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		fl.Run(ctx)
		close(done)
	}()
	time.Sleep(120 * time.Millisecond)
	cancel()
	select {
	case <-done:
		// good — stopped
	case <-time.After(2 * time.Second):
		t.Errorf("Run did not stop after context cancel")
	}
}

func TestFastLoop_Run_DisabledSkipsCycle(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)
	fl.SetEnabled(false)
	// runCycle should return immediately when disabled (no decisions, no lastCycle)
	fl.mu.Lock()
	before := fl.lastCycle
	fl.mu.Unlock()
	fl.runCycle()
	fl.mu.Lock()
	after := fl.lastCycle
	fl.mu.Unlock()
	if !after.Equal(before) {
		t.Errorf("runCycle should not update lastCycle when disabled")
	}
}
