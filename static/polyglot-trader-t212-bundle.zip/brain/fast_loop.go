package brain

import (
	"context"
	"fmt"
	"log/slog"
	"sort"
	"sync"
	"time"

	"github.com/punit/polyglot-trader-t212/data"
	"github.com/punit/polyglot-trader-t212/mlservice"
)

// maxDecisionsBound caps the in-memory decision ring (memory growth guard).
// ponytail: 500 ≈ 2 days of 60s cycles for an 8-ticker universe; trim in
// runCycle, no new struct. Bump only if /api/paper/signals needs deeper history.
const maxDecisionsBound = 500

// TradeDecision is the result of a fast loop cycle.
type TradeDecision struct {
	Ticker     string
	Action     string // BUY, SELL, HOLD
	Confidence float64
	Price      float64
	Reason     string
	Model      string
	Timestamp  time.Time
	// Momentum is 20d return — used for cross-sectional buy ranking.
	Momentum float64
	// ATR is the ticker's atr_ratio (ATR14/price) — used for vol-scaled sizing.
	ATR float64
	// VolFactor scales position size: median-ATR-relative, clamped [0.5, 2.0].
	// 0 or 1 = no adjustment.
	VolFactor float64
}

// FastLoop is the autonomous trading engine.
type FastLoop struct {
	mu sync.RWMutex

	// Core components
	store    *data.Store
	fetcher  *data.HistoryFetcher
	features *data.FeatureEngine
	ml       *mlservice.Orchestrator
	learning *LearningLoop
	champion *ChampionChallenger
	drift    *DriftDetector
	risk     *AdaptiveRisk
	broker   PaperBroker // set via SetBroker; used for mark-to-market + equity

	// Config
	tickers  []string
	interval time.Duration
	enabled  bool

	// Callbacks
	onDrift     func()                // triggers retrain when drift detected
	onExecute   func(d TradeDecision) // executes decisions (set via SetExecuteCallback)
	retrainMu   sync.Mutex
	lastRetrain time.Time

	// modelQualityFn returns true when the model's validation AUC clears the
	// minimum bar. BUYs are blocked when it returns false. nil = allow (no gate).
	modelQualityFn func() bool

	// State
	lastCycle      time.Time
	decisions      []TradeDecision
	spyPrice       float64 // last fetched SPY close (0 = unknown)
	spyEMA         float64 // 50-period SMA of SPY closes (0 = unknown)
	spyBelowSMA    bool    // hysteresis state: bear regime (see spyRegimeStep)
	maxBuyPerCycle int     // momentum-ranked BUY budget per cycle (0 = unlimited)
}

// ponytail: regime hysteresis, ±0.5% band around the 50-SMA. SPY wobbles
// the SMA by a few bps in range-bound markets; a bare price>=SMA check
// would flip the buy gate on noise. Entering at -0.5% and exiting only at
// +0.5% keeps the regime sticky. 0.5% matches the label deadband — same
// "not worth trading" distance. Upgrade: ATR-scaled band if 0.5% proves
// too wide/narrow in live regime flips.
const (
	spyBearEnter = 0.995 // close <  SMA*0.995 -> enter bear regime
	spyBearExit  = 1.005 // close >  SMA*1.005 -> exit bear regime
)

// NewFastLoop creates the autonomous trading engine.
func NewFastLoop(
	store *data.Store,
	fetcher *data.HistoryFetcher,
	features *data.FeatureEngine,
	ml *mlservice.Orchestrator,
	tickers []string,
	interval time.Duration,
) *FastLoop {
	ll := NewLearningLoop(20)
	return &FastLoop{
		store:          store,
		fetcher:        fetcher,
		features:       features,
		ml:             ml,
		learning:       ll,
		champion:       NewChampionChallenger(ll),
		drift:          NewDriftDetector(50),
		risk:           NewAdaptiveRisk(),
		tickers:        tickers,
		interval:       interval,
		enabled:        true,
		maxBuyPerCycle: 2,
	}
}

// SetBroker wires the paper broker for mark-to-market and equity tracking.
func (fl *FastLoop) SetBroker(b PaperBroker) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	fl.broker = b
}

// SetMaxBuyPerCycle caps how many BUY decisions per cycle (momentum ranking).
func (fl *FastLoop) SetMaxBuyPerCycle(n int) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	fl.maxBuyPerCycle = n
}

// Run starts the fast loop in a background goroutine.
func (fl *FastLoop) Run(ctx context.Context) {
	fl.mu.Lock()
	fl.enabled = true
	fl.mu.Unlock()

	ticker := time.NewTicker(fl.interval)
	defer ticker.Stop()

	slog.Info("fast loop started", "tickers", len(fl.tickers), "interval", fl.interval.String())

	for {
		select {
		case <-ctx.Done():
			slog.Info("fast loop stopped")
			return
		case <-ticker.C:
			fl.runCycle()
		}
	}
}

func (fl *FastLoop) runCycle() {
	fl.mu.Lock()
	if !fl.enabled {
		fl.mu.Unlock()
		return
	}
	fl.mu.Unlock()

	start := time.Now()

	// Mark open positions to market before decisions (fresh equity/prices)
	fl.markToMarket()

	// Evaluate all tickers, then momentum-rank BUYs: when more tickers
	// qualify to buy than allowed, only the strongest 20d-momentum names
	// (above their 200-SMA) trade — the cross-sectional ranking pattern.
	var candidates []*TradeDecision
	for _, ticker := range fl.tickers {
		decision := fl.evaluateTicker(ticker)
		if decision != nil {
			fl.mu.Lock()
			fl.decisions = append(fl.decisions, *decision)
			fl.mu.Unlock()

			// Log decision
			slog.Info("decision",
				"ticker", decision.Ticker,
				"action", decision.Action,
				"confidence", decision.Confidence,
				"model", decision.Model,
				"reason", decision.Reason,
			)

			if decision.Action == "BUY" {
				candidates = append(candidates, decision)
			} else if decision.Action == "SELL" {
				// SELLs execute immediately — only BUYs are momentum-ranked
				fl.mu.RLock()
				onExec := fl.onExecute
				fl.mu.RUnlock()
				if onExec != nil {
					go onExec(*decision)
				}
			}

			// Record signal for learning
			fl.store.RecordSignal(data.SignalRecord{
				Ticker:     ticker,
				Model:      decision.Model,
				Signal:     decision.Action,
				Confidence: decision.Confidence,
			})
		}
	}

	// Rank candidates by 20d momentum (desc), cap at maxBuyPerCycle.
	fl.mu.RLock()
	maxBuy := fl.maxBuyPerCycle
	fl.mu.RUnlock()
	if maxBuy > 0 && len(candidates) > maxBuy {
		sort.SliceStable(candidates, func(i, j int) bool {
			return candidates[i].Momentum > candidates[j].Momentum
		})
	}
	// Vol-scaled sizing: ATR-based so high-vol names get smaller positions.
	fl.computeVolFactors(candidates)
	// ponytail: ring copies were appended before sizing ran, so sync the
	// computed VolFactor back — /api/sota/decisions & /api/paper/signals
	// otherwise always reported VolFactor=0 for BUYs.
	fl.mu.Lock()
	fl.syncRingVolFactorsLocked(candidates)
	fl.mu.Unlock()
	for i, decision := range candidates {
		// ponytail: i < maxBuy = winner after sort; all else demoted to HOLD
		if maxBuy > 0 && i >= maxBuy {
			decision.Action = "HOLD"
			decision.Reason = "momentum-ranked out of cycle buy budget"
			fl.mu.Lock()
			for j := range fl.decisions {
				if fl.decisions[j].Ticker == decision.Ticker && fl.decisions[j].Action == "BUY" {
					fl.decisions[j].Action = "HOLD"
					fl.decisions[j].Reason = decision.Reason
				}
			}
			fl.mu.Unlock()
			continue
		}
		fl.mu.RLock()
		onExec := fl.onExecute
		fl.mu.RUnlock()
		if onExec != nil {
			go onExec(*decision)
		}
	}

	// Update champion/challenger
	if promoted, reason := fl.champion.EvaluatePromotion(); promoted {
		slog.Info("model promotion", "reason", reason)
	}

	// Check for drift
	for _, model := range []string{fl.champion.GetChampion(), fl.champion.GetChallenger()} {
		if model == "" {
			continue
		}
		if drifted, reason := fl.drift.CheckDrift(model); drifted {
			slog.Warn("model drift detected", "model", model, "reason", reason)
			fl.triggerRetrain("drift: " + reason)
		}
	}

	fl.mu.Lock()
	fl.lastCycle = time.Now()
	fl.trimDecisionsLocked()
	fl.mu.Unlock()

	slog.Debug("fast loop cycle complete",
		"duration_ms", time.Since(start).Milliseconds(),
		"tickers", len(fl.tickers),
	)
}

func (fl *FastLoop) evaluateTicker(symbol string) *TradeDecision {
	// 1. Fetch data
	bars, err := fl.fetcher.FetchHistory(symbol, "1y")
	if err != nil {
		slog.Warn("data fetch failed", "ticker", symbol, "error", err)
		return nil
	}
	if len(bars) < 30 {
		return nil
	}

	// 2. Compute features
	features, err := fl.features.LatestFeatures(bars)
	if err != nil {
		slog.Warn("feature compute failed", "ticker", symbol, "error", err)
		return nil
	}

	// 3. Get prediction from ML
	pred, err := fl.ml.Predict(features)
	if err != nil {
		slog.Warn("prediction failed", "ticker", symbol, "error", err)
		return nil
	}

	// 4. Check risk
	riskParams := fl.risk.GetCurrentRisk()

	// 5. Extract key features for trend/momentum/volatility filters
	closePrice := bars[len(bars)-1].Close
	closeVsSMA200 := features["close_vs_sma200"] // >1 means above 200-SMA (uptrend)
	return20d := features["return_20d"]          // 20-day momentum
	atrRatio := features["atr_ratio"]            // ATR14/close — volatility proxy

	// 6. Make decision with enhanced filters
	decision := &TradeDecision{
		Ticker:     symbol,
		Price:      closePrice,
		Confidence: pred.Probabilities[predictionLabel(pred)],
		Model:      fl.champion.GetChampion(),
		Momentum:   return20d,
		ATR:        atrRatio,
	}

	predLabel := predictionLabel(pred)
	pUp := pred.Probabilities["buy"] // probability of going up
	// ponytail: close_vs_sma200 = 0 means <200 bars of history (ratio()
	// returns 0 for zero denominator) — treat unknown as pass, matching
	// the macro gate's "no SPY data → allowing" convention.
	aboveTrend := closeVsSMA200 > 1.0 || closeVsSMA200 == 0

	// Macro regime: SPY below its 50-SMA (with ±0.5% hysteresis band), or
	// no SPY data yet → allow. The hysteresis state persists across cycles.
	fl.mu.RLock()
	spyBullish := fl.spyPrice == 0 || fl.spyEMA == 0 || !fl.spyBelowSMA
	fl.mu.RUnlock()

	// Model quality gate: weak model (AUC below bar) can't buy.
	fl.mu.RLock()
	mqFn := fl.modelQualityFn
	fl.mu.RUnlock()
	modelOK := mqFn == nil || mqFn()

	// BUY: ML signal + trend filter + macro regime + quality gate + drawdown
	if predLabel == "buy" && pUp >= riskParams.MinConfidence {
		blocked := ""
		switch {
		case !aboveTrend:
			blocked = "below 200-SMA"
		case !spyBullish:
			blocked = "SPY below 50-SMA (macro bear regime)"
		case !modelOK:
			blocked = "model quality gate (AUC below bar)"
		case fl.risk.IsDrawdownBreached():
			blocked = "drawdown breaker tripped"
		}
		if blocked == "" {
			decision.Action = "BUY"
			decision.Reason = fmt.Sprintf("ML P(up)=%.2f≥%.2f, above 200-SMA, mom %.1f%%",
				pUp, riskParams.MinConfidence, return20d*100)
		} else {
			// ponytail: one-line visibility for the #1 "why no trades?" class
			// of question — which gate ate an otherwise-eligible BUY signal.
			slog.Debug("BUY signal blocked", "ticker", symbol, "pUp", pUp, "by", blocked)
			decision.Action = "HOLD"
			decision.Reason = fmt.Sprintf("signal held: P(up)=%.2f, blocked: %s", pUp, blocked)
		}
	} else if pUp <= 0.45 {
		// SELL: hysteresis exit — P(up) below 0.45 means the model sees
		// more downside than upside (p_down ≥ 0.55 in a binary model).
		decision.Action = "SELL"
		decision.Reason = fmt.Sprintf("exit: P(up)=%.2f ≤ 0.45", pUp)
	} else {
		// HOLD: everything else
		decision.Action = "HOLD"
		decision.Reason = fmt.Sprintf("hold: P(up)=%.2f, trend ok=%v",
			pUp, aboveTrend)
	}

	// 6. Record for learning (only on actionable signals, matching original semantics)
	if decision.Action != "HOLD" {
		fl.drift.RecordPrediction(decision.Model, decision.Confidence)
	}

	decision.Timestamp = time.Now()

	return decision
}

// markToMarket updates equity tracking and SPY macro regime data.
// Runs once per cycle before decisions.
// ponytail: 1 Yahoo call for SPY + reuse of position quotes from broker.
func (fl *FastLoop) markToMarket() {
	fl.mu.RLock()
	broker := fl.broker
	fl.mu.RUnlock()
	if broker != nil {
		// Update equity tracking for drawdown circuit breaker
		equity := broker.GetEquity()
		fl.risk.UpdateEquity(equity)
	}
	if fl.fetcher == nil {
		return
	}
	// Macro regime: fetch SPY and compute 50-SMA
	spyBars, err := fl.fetcher.FetchHistory("SPY", "3mo")
	if err != nil || len(spyBars) < 50 {
		return
	}
	closes := make([]float64, len(spyBars))
	for i, b := range spyBars {
		closes[i] = b.Close
	}
	last := closes[len(closes)-1]
	sma50 := sma(closes, 50)[len(closes)-1]
	fl.mu.Lock()
	fl.spyPrice = last
	fl.spyEMA = sma50
	// Advance regime hysteresis (±0.5% band — see spyBearEnter/Exit).
	if sma50 > 0 {
		switch {
		case !fl.spyBelowSMA && last < sma50*spyBearEnter:
			fl.spyBelowSMA = true
			slog.Info("SPY macro regime: bear", "close", last, "sma50", sma50)
		case fl.spyBelowSMA && last > sma50*spyBearExit:
			fl.spyBelowSMA = false
			slog.Info("SPY macro regime: bull", "close", last, "sma50", sma50)
		}
	}
	fl.mu.Unlock()
}

// computeVolFactors scales each candidate's position by its volatility
// relative to the cohort median. High-vol names get smaller positions,
// low-vol names get larger. Factor is clamped to [0.5, 2.0].
// ponytail: median is the robust reference point; full percentile would
// require more math for marginal gain.
func (fl *FastLoop) computeVolFactors(candidates []*TradeDecision) {
	if len(candidates) == 0 {
		return
	}
	atrs := make([]float64, 0, len(candidates))
	for _, c := range candidates {
		if c.ATR > 0 {
			atrs = append(atrs, c.ATR)
		}
	}
	if len(atrs) == 0 {
		return
	}
	sort.Float64s(atrs)
	median := atrs[len(atrs)/2]
	if median <= 0 {
		return
	}
	for _, c := range candidates {
		if c.ATR <= 0 {
			continue
		}
		ratio := c.ATR / median // high vol = ratio > 1
		// Scale down high vol, scale up low vol. Invert: 1/ratio clamped.
		factor := 1.0 / ratio
		if factor > 2.0 {
			factor = 2.0
		} else if factor < 0.5 {
			factor = 0.5
		}
		c.VolFactor = factor
	}
}

// syncRingVolFactorsLocked copies the computed VolFactor into the
// decision-ring entries for these tickers (they were appended pre-sizing).
// Caller holds fl.mu.
func (fl *FastLoop) syncRingVolFactorsLocked(candidates []*TradeDecision) {
	byTicker := make(map[string]float64, len(candidates))
	for _, c := range candidates {
		if c.VolFactor > 0 {
			byTicker[c.Ticker] = c.VolFactor
		}
	}
	if len(byTicker) == 0 {
		return
	}
	for i := range fl.decisions {
		if f, ok := byTicker[fl.decisions[i].Ticker]; ok {
			fl.decisions[i].VolFactor = f
		}
	}
}

// trimDecisionsLocked caps the decision ring at maxDecisionsBound, keeping
// the most recent. Caller holds fl.mu. The ring accumulated across all
// cycles: unbounded memory growth, and /api/paper/signals returned stale
// duplicate tickers spanning many cycles.
func (fl *FastLoop) trimDecisionsLocked() {
	if len(fl.decisions) > maxDecisionsBound {
		fl.decisions = append([]TradeDecision(nil), fl.decisions[len(fl.decisions)-maxDecisionsBound:]...)
	}
}

// SetModelQualityGate sets the function that validates model quality (AUC).
// Called by main.go after training to wire the live AUC gate.
func (fl *FastLoop) SetModelQualityGate(fn func() bool) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	fl.modelQualityFn = fn
}

// GetSpyPrice returns the last fetched SPY close (0 = unknown).
func (fl *FastLoop) GetSpyPrice() float64 {
	fl.mu.RLock()
	defer fl.mu.RUnlock()
	return fl.spyPrice
}

// GetSpyEMA returns the last computed SPY 50-SMA (0 = unknown).
func (fl *FastLoop) GetSpyEMA() float64 {
	fl.mu.RLock()
	defer fl.mu.RUnlock()
	return fl.spyEMA
}

// GetSpyBelowSMA reports the hysteresis regime state (bear regime latched).
func (fl *FastLoop) GetSpyBelowSMA() bool {
	fl.mu.RLock()
	defer fl.mu.RUnlock()
	return fl.spyBelowSMA
}

// sma returns simple moving averages for period; out[i] = 0 until enough data.
func sma(values []float64, period int) []float64 {
	out := make([]float64, len(values))
	sum := 0.0
	for i, v := range values {
		sum += v
		if i >= period {
			sum -= values[i-period]
		}
		if i >= period-1 {
			out[i] = sum / float64(period)
		}
	}
	return out
}

// predictionLabel returns the highest-probability action label from a prediction.
func predictionLabel(pred *mlservice.InferenceResult) string {
	best := "hold"
	bestProb := 0.0
	for label, prob := range pred.Probabilities {
		if prob > bestProb {
			bestProb = prob
			best = label
		}
	}
	return best
}

// SetRetrainCallback sets the function called when retraining is needed
// (drift detection). At most once per 6 hours to avoid thrashing.
func (fl *FastLoop) SetRetrainCallback(fn func()) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	fl.onDrift = fn
}

// GetDrift returns the drift detector (for wiring outcome hooks).
func (fl *FastLoop) GetDrift() *DriftDetector {
	return fl.drift
}

// SetExecuteCallback sets the function that actually executes decisions.
// Without it, decisions are logged but not traded.
func (fl *FastLoop) SetExecuteCallback(fn func(d TradeDecision)) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	fl.onExecute = fn
}

// triggerRetrain invokes the retrain callback with rate limiting.
func (fl *FastLoop) triggerRetrain(reason string) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	if fl.onDrift == nil {
		return
	}
	if time.Since(fl.lastRetrain) < 6*time.Hour {
		slog.Debug("retrain skipped (rate limited)", "reason", reason)
		return
	}
	fl.lastRetrain = time.Now()
	slog.Info("triggering retrain", "reason", reason)
	go fl.onDrift()
}

// GetDecisions returns recent trade decisions.
func (fl *FastLoop) GetDecisions(limit int) []TradeDecision {
	fl.mu.RLock()
	defer fl.mu.RUnlock()
	if limit <= 0 || limit > len(fl.decisions) {
		limit = len(fl.decisions)
	}
	decisions := make([]TradeDecision, limit)
	copy(decisions, fl.decisions[len(fl.decisions)-limit:])
	return decisions
}

// GetLastCycle returns the time the last cycle completed.
func (fl *FastLoop) GetLastCycle() time.Time {
	fl.mu.RLock()
	defer fl.mu.RUnlock()
	return fl.lastCycle
}

// SetLastCycle records when the loop last ran a cycle. A fresh loop (before
// its first tick) has a zero last-cycle, and callers that treat zero as
// "loop not alive" can't distinguish that from a loop that simply hasn't
// cycled yet — this knob lets the loop (and tests) pin a known last-cycle.
func (fl *FastLoop) SetLastCycle(t time.Time) {
	fl.mu.Lock()
	defer fl.mu.Unlock()
	fl.lastCycle = t
}

// GetLearning returns the learning loop.
func (fl *FastLoop) GetLearning() *LearningLoop {
	return fl.learning
}

// GetRisk returns the adaptive risk manager.
func (fl *FastLoop) GetRisk() *AdaptiveRisk {
	return fl.risk
}

// GetChampionChallenger returns the champion/challenger manager.
func (fl *FastLoop) GetChampionChallenger() *ChampionChallenger {
	return fl.champion
}

// IsEnabled returns whether the fast loop is active.
func (fl *FastLoop) IsEnabled() bool {
	fl.mu.RLock()
	defer fl.mu.RUnlock()
	return fl.enabled
}

// SetEnabled enables or disables the fast loop.
func (fl *FastLoop) SetEnabled(enabled bool) {
	fl.mu.Lock()
	fl.enabled = enabled
	fl.mu.Unlock()
	slog.Info("fast loop", "enabled", enabled)
}
