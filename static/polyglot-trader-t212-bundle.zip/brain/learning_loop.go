// Package brain implements the autonomous trading intelligence:
// learning loop, drift detection, champion/challenger promotion,
// adaptive risk management, and the fast-loop orchestrator.
package brain

import (
	"fmt"
	"log/slog"
	"math"
	"sync"
	"time"
)

// TradeOutcome records the result of a completed trade.
type TradeOutcome struct {
	Ticker     string
	Side       string
	Model      string
	SignalConf float64
	PnL        float64
	HoldingSec float64
}

// ModelPerformance tracks rolling stats per model.
type ModelPerformance struct {
	Model       string
	Trades      int
	Wins        int
	TotalPnL    float64
	TotalPnLPos float64
	TotalPnLNeg float64
	LastUpdate  time.Time
}

// PerformanceStats computes derived metrics from rolling stats.
type PerformanceStats struct {
	Model       string
	Trades      int
	WinRate     float64
	Sharpe      float64
	Expectancy  float64
	MaxDrawdown float64
	IsQualified bool
}

// LearningLoop tracks trade outcomes and model performance.
type LearningLoop struct {
	mu             sync.RWMutex
	performances   map[string]*ModelPerformance
	outcomeHistory []TradeOutcome
	minTrades      int
	driftHook      func(model string, win bool)
}

// NewLearningLoop creates a learning loop with the given minimum trades for promotion.
func NewLearningLoop(minTrades int) *LearningLoop {
	if minTrades <= 0 {
		minTrades = 20
	}
	return &LearningLoop{
		performances: make(map[string]*ModelPerformance),
		minTrades:    minTrades,
	}
}

// SetDriftHook registers a callback for trade outcomes (feeds drift detector).
func (l *LearningLoop) SetDriftHook(fn func(model string, win bool)) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.driftHook = fn
}

// RecordOutcome logs a trade outcome and updates model performance.
func (l *LearningLoop) RecordOutcome(outcome TradeOutcome) {
	l.mu.Lock()
	defer l.mu.Unlock()

	hook := l.driftHook

	if perf, ok := l.performances[outcome.Model]; ok {
		perf.Trades++
		perf.TotalPnL += outcome.PnL
		if outcome.PnL > 0 {
			perf.Wins++
			perf.TotalPnLPos += outcome.PnL
		} else {
			perf.TotalPnLNeg += outcome.PnL
		}
		perf.LastUpdate = time.Now()
	} else {
		l.performances[outcome.Model] = &ModelPerformance{
			Model:      outcome.Model,
			Trades:     1,
			TotalPnL:   outcome.PnL,
			LastUpdate: time.Now(),
		}
		if outcome.PnL > 0 {
			l.performances[outcome.Model].Wins = 1
			l.performances[outcome.Model].TotalPnLPos = outcome.PnL
		} else {
			l.performances[outcome.Model].TotalPnLNeg = outcome.PnL
		}
	}

	l.outcomeHistory = append(l.outcomeHistory, outcome)
	if len(l.outcomeHistory) > 1000 {
		l.outcomeHistory = l.outcomeHistory[len(l.outcomeHistory)-1000:]
	}

	if hook != nil && outcome.Model != "" {
		go hook(outcome.Model, outcome.PnL > 0)
	}
}

// GetStats returns computed performance stats for a model.
func (l *LearningLoop) GetStats(model string) PerformanceStats {
	l.mu.RLock()
	defer l.mu.RUnlock()

	perf, ok := l.performances[model]
	if !ok || perf.Trades == 0 {
		return PerformanceStats{Model: model, IsQualified: false}
	}

	winRate := float64(perf.Wins) / float64(perf.Trades)

	// Simple Sharpe: mean(pnl) / std(pnl)
	avgPnL := perf.TotalPnL / float64(perf.Trades)
	stdPnL := l.computeStdPnL(model)
	sharpe := 0.0
	if stdPnL > 0.001 {
		sharpe = avgPnL / stdPnL
	}

	expectancy := 0.0
	if perf.TotalPnLPos > 0 || perf.TotalPnLNeg < 0 {
		expectancy = perf.TotalPnL / float64(perf.Trades)
	}

	maxDD := l.computeMaxDrawdown(model)

	return PerformanceStats{
		Model:       model,
		Trades:      perf.Trades,
		WinRate:     winRate,
		Sharpe:      sharpe,
		Expectancy:  expectancy,
		MaxDrawdown: maxDD,
		IsQualified: perf.Trades >= l.minTrades && winRate > 0.5 && sharpe > 0.5,
	}
}

// GetAllStats returns performance stats for all models.
func (l *LearningLoop) GetAllStats() map[string]PerformanceStats {
	l.mu.RLock()
	models := make([]string, 0, len(l.performances))
	for m := range l.performances {
		models = append(models, m)
	}
	l.mu.RUnlock()

	stats := make(map[string]PerformanceStats, len(models))
	for _, m := range models {
		stats[m] = l.GetStats(m)
	}
	return stats
}

// GetOutcomeHistory returns recent trade outcomes.
func (l *LearningLoop) GetOutcomeHistory(limit int) []TradeOutcome {
	l.mu.RLock()
	defer l.mu.RUnlock()
	if limit <= 0 || limit > len(l.outcomeHistory) {
		limit = len(l.outcomeHistory)
	}
	hist := make([]TradeOutcome, limit)
	copy(hist, l.outcomeHistory[len(l.outcomeHistory)-limit:])
	return hist
}

// computeStdPnL computes rolling std of PnL for a model.
func (l *LearningLoop) computeStdPnL(model string) float64 {
	perf, ok := l.performances[model]
	if !ok || perf.Trades < 2 {
		return 0
	}
	avgPnL := perf.TotalPnL / float64(perf.Trades)

	var posAvg, negAvg float64
	losses := perf.Trades - perf.Wins
	if perf.Wins > 0 {
		posAvg = perf.TotalPnLPos / float64(perf.Wins)
	}
	if losses > 0 {
		negAvg = perf.TotalPnLNeg / float64(losses)
	}

	// Approximate variance
	variance := (posAvg-avgPnL)*(posAvg-avgPnL)*float64(perf.Wins)/float64(perf.Trades) +
		(negAvg-avgPnL)*(negAvg-avgPnL)*float64(losses)/float64(perf.Trades)

	return math.Sqrt(variance)
}

// computeMaxDrawdown computes max drawdown from outcome history.
func (l *LearningLoop) computeMaxDrawdown(model string) float64 {
	peak := 0.0
	maxDD := 0.0
	cumulative := 0.0

	for _, outcome := range l.outcomeHistory {
		if outcome.Model != model {
			continue
		}
		cumulative += outcome.PnL
		if cumulative > peak {
			peak = cumulative
		}
		dd := (peak - cumulative) / (peak + 1)
		if dd > maxDD {
			maxDD = dd
		}
	}

	return maxDD
}

// ChampionChallenger manages model promotion.
type ChampionChallenger struct {
	mu         sync.RWMutex
	champion   string
	challenger string
	learning   *LearningLoop
	minTrades  int

	// minPromotionAUC gates promotion on model quality (0 = disabled).
	minPromotionAUC float64
	// aucProvider returns a model's validation AUC (0 when unavailable).
	// nil = AUC gate disabled.
	aucProvider func(model string) float64
}

// NewChampionChallenger creates a champion/challenger manager.
func NewChampionChallenger(learning *LearningLoop) *ChampionChallenger {
	return &ChampionChallenger{
		champion:   "default",
		challenger: "",
		learning:   learning,
		minTrades:  20,
	}
}

// SetChallenger sets a challenger model.
func (cc *ChampionChallenger) SetChallenger(model string) {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	cc.challenger = model
	slog.Info("challenger set", "model", model)
}

// GetChampion returns the current champion model.
func (cc *ChampionChallenger) GetChampion() string {
	cc.mu.RLock()
	defer cc.mu.RUnlock()
	return cc.champion
}

// GetChallenger returns the current challenger model.
func (cc *ChampionChallenger) GetChallenger() string {
	cc.mu.RLock()
	defer cc.mu.RUnlock()
	return cc.challenger
}

// SetAUCGate wires the AUC promotion gate: challenger must clear minAUC.
// provider returns the model's validation AUC (0 when unknown).
func (cc *ChampionChallenger) SetAUCGate(minAUC float64, provider func(model string) float64) {
	cc.mu.Lock()
	defer cc.mu.Unlock()
	cc.minPromotionAUC = minAUC
	cc.aucProvider = provider
}

// EvaluatePromotion checks if challenger should become champion.
func (cc *ChampionChallenger) EvaluatePromotion() (bool, string) {
	cc.mu.RLock()
	challenger := cc.challenger
	champion := cc.champion
	minAUC := cc.minPromotionAUC
	aucProvider := cc.aucProvider
	cc.mu.RUnlock()

	if challenger == "" || challenger == champion {
		return false, "no challenger or same as champion"
	}

	champStats := cc.learning.GetStats(champion)
	challStats := cc.learning.GetStats(challenger)

	// Challenger must be qualified and better than champion
	if !challStats.IsQualified {
		return false, fmt.Sprintf("challenger not qualified: trades=%d winrate=%.2f",
			challStats.Trades, challStats.WinRate)
	}

	// AUC quality gate: challenger must clear the model-quality bar
	if minAUC > 0 && aucProvider != nil {
		auc := aucProvider(challenger)
		if auc > 0 && auc < minAUC {
			return false, fmt.Sprintf("challenger AUC %.3f < minimum %.3f", auc, minAUC)
		}
	}

	if challStats.WinRate < champStats.WinRate-0.05 {
		return false, fmt.Sprintf("challenger win rate %.2f < champion %.2f",
			challStats.WinRate, champStats.WinRate)
	}

	if challStats.Sharpe < champStats.Sharpe-0.1 {
		return false, fmt.Sprintf("challenger sharpe %.2f < champion %.2f",
			challStats.Sharpe, champStats.Sharpe)
	}

	cc.mu.Lock()
	cc.champion = challenger
	cc.challenger = ""
	cc.mu.Unlock()

	slog.Info("CHAMPION PROMOTED", "new_champion", challenger,
		"win_rate", challStats.WinRate, "sharpe", challStats.Sharpe)
	return true, "champion promoted"
}
