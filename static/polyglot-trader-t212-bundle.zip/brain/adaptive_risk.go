package brain

import (
	"sync"
	"time"
)

// AdaptiveRisk manages dynamic risk parameters based on market conditions
// and model performance.
type AdaptiveRisk struct {
	mu sync.RWMutex

	// Base parameters
	MaxPositionPct      float64 // max % portfolio per position
	MaxDrawdownPct      float64 // circuit breaker at this drawdown
	MinConfidence       float64 // min model confidence to trade
	MaxConcurrentTrades int

	// Dynamic state
	currentDrawdown float64
	peakEquity      float64
	lastUpdate      time.Time
}

// NewAdaptiveRisk creates an adaptive risk manager with defaults.
func NewAdaptiveRisk() *AdaptiveRisk {
	return &AdaptiveRisk{
		MaxPositionPct:      10,
		MaxDrawdownPct:      5,
		MinConfidence:       0.55,
		MaxConcurrentTrades: 5,
		peakEquity:          1, // normalize to 1
	}
}

// RiskParameters is the current risk configuration.
type RiskParameters struct {
	MaxPositionPct         float64
	MaxDrawdownPct         float64
	MinConfidence          float64
	MaxConcurrentTrades    int
	PositionSizeMultiplier float64
	IsLocked               bool
}

// GetCurrentRisk returns the current risk parameters adjusted for conditions.
func (a *AdaptiveRisk) GetCurrentRisk() RiskParameters {
	a.mu.RLock()
	defer a.mu.RUnlock()

	// Start with base parameters
	rp := RiskParameters{
		MaxPositionPct:         a.MaxPositionPct,
		MaxDrawdownPct:         a.MaxDrawdownPct,
		MinConfidence:          a.MinConfidence,
		MaxConcurrentTrades:    a.MaxConcurrentTrades,
		PositionSizeMultiplier: 1.0,
	}

	// If we're in drawdown, reduce position size
	if a.currentDrawdown > 0 {
		ddRatio := a.currentDrawdown / a.MaxDrawdownPct
		if ddRatio > 0.5 {
			// More than half way to max drawdown — halve positions
			rp.PositionSizeMultiplier = 0.5
		}
		if ddRatio > 0.8 {
			// Very close to max — quarter positions and require higher confidence
			rp.PositionSizeMultiplier = 0.25
			rp.MinConfidence = a.MinConfidence + 0.10
		}
	}

	return rp
}

// UpdateEquity tracks portfolio equity and updates drawdown.
func (a *AdaptiveRisk) UpdateEquity(equity float64) {
	if equity <= 0 {
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()

	if equity > a.peakEquity {
		a.peakEquity = equity
		a.currentDrawdown = 0
	} else if a.peakEquity > 0 {
		a.currentDrawdown = (a.peakEquity - equity) / a.peakEquity * 100
	}
	a.lastUpdate = time.Now()
}

// IsDrawdownBreached checks if max drawdown is exceeded.
func (a *AdaptiveRisk) IsDrawdownBreached() bool {
	a.mu.RLock()
	defer a.mu.RUnlock()
	return a.currentDrawdown >= a.MaxDrawdownPct
}

// GetCurrentDrawdown returns current drawdown percentage.
func (a *AdaptiveRisk) GetCurrentDrawdown() float64 {
	a.mu.RLock()
	defer a.mu.RUnlock()
	return a.currentDrawdown
}

// SetParameters updates risk parameters.
func (a *AdaptiveRisk) SetParameters(maxPositionPct, maxDrawdownPct, minConfidence float64) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.MaxPositionPct = maxPositionPct
	a.MaxDrawdownPct = maxDrawdownPct
	a.MinConfidence = minConfidence
}
