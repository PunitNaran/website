package brain

import (
	"log/slog"
	"sync"
	"time"
)

// DriftDetector monitors model performance degradation over time.
type DriftDetector struct {
	mu sync.RWMutex

	// Per-model rolling windows
	windowSize   int
	performances map[string]*RollingWindow
}

type RollingWindow struct {
	Predictions []float64
	Outcomes    []float64
}

// NewDriftDetector creates a drift detector.
func NewDriftDetector(windowSize int) *DriftDetector {
	if windowSize <= 0 {
		windowSize = 50
	}
	return &DriftDetector{
		windowSize:   windowSize,
		performances: make(map[string]*RollingWindow),
	}
}

// RecordPrediction logs a prediction for a model.
func (d *DriftDetector) RecordPrediction(model string, confidence float64) {
	d.mu.Lock()
	defer d.mu.Unlock()

	w, ok := d.performances[model]
	if !ok {
		w = &RollingWindow{}
		d.performances[model] = w
	}
	w.Predictions = append(w.Predictions, confidence)
	if len(w.Predictions) > d.windowSize {
		w.Predictions = w.Predictions[len(w.Predictions)-d.windowSize:]
	}
}

// RecordOutcome logs an outcome (1 for win, 0 for loss) for a model.
func (d *DriftDetector) RecordOutcome(model string, win bool) {
	d.mu.Lock()
	defer d.mu.Unlock()

	v := 0.0
	if win {
		v = 1.0
	}

	w, ok := d.performances[model]
	if !ok {
		w = &RollingWindow{}
		d.performances[model] = w
	}
	w.Outcomes = append(w.Outcomes, v)
	if len(w.Outcomes) > d.windowSize {
		w.Outcomes = w.Outcomes[len(w.Outcomes)-d.windowSize:]
	}
}

// CheckDrift compares early vs recent performance to detect drift.
// Returns true if significant drift is detected.
func (d *DriftDetector) CheckDrift(model string) (drifted bool, reason string) {
	d.mu.RLock()
	w, ok := d.performances[model]
	d.mu.RUnlock()

	if !ok || len(w.Outcomes) < 20 {
		return false, "insufficient data"
	}

	// Split into early and recent halves
	n := len(w.Outcomes)
	earlyEnd := n / 2
	recentStart := n - n/2

	earlyRate := mean(w.Outcomes[:earlyEnd])
	recentRate := mean(w.Outcomes[recentStart:])

	// Drift if recent win rate is >15% lower than early
	if recentRate < earlyRate-0.15 && earlyRate > 0.4 {
		return true, "performance degradation"
	}

	return false, "no drift"
}

// GetConfidenceStats returns mean confidence for a model.
func (d *DriftDetector) GetConfidenceStats(model string) (meanConf, recentMeanConf float64) {
	d.mu.RLock()
	w, ok := d.performances[model]
	d.mu.RUnlock()

	if !ok || len(w.Predictions) == 0 {
		return 0, 0
	}

	all := mean(w.Predictions)
	recent := w.Predictions
	if len(recent) > 20 {
		recent = recent[len(recent)-20:]
	}
	return all, mean(recent)
}

// LastCheck returns when drift was last checked.
func (d *DriftDetector) LastCheck() time.Time {
	return time.Now()
}

func mean(values []float64) float64 {
	if len(values) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range values {
		sum += v
	}
	return sum / float64(len(values))
}

// Ensure slog is used (for future alerting).
var _ = slog.Info
