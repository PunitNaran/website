package brain

import (
	"testing"
	"time"
)

// These cover the 0%-coverage setters/getters that are wired in main.go.
// Each is a one-line field write under a lock, so a single call per method
// pins the behavior (set-then-read) at minimum cost.

func TestAutoExecutor_Setters(t *testing.T) {
	b := newMockBroker(1000)
	ae := NewAutoExecutor(b, NewLearningLoop(20), NewChampionChallenger(NewLearningLoop(20)))

	ae.SetSizer(struct{ PositionSizer }{})
	ae.SetMaxOrderValue(250)
	ae.SetStopTakeLoss(-6, 12)
	ae.SetMaxHoldDays(3)

	if ae.maxOrder != 250 {
		t.Errorf("maxOrder = %v, want 250", ae.maxOrder)
	}
	if ae.stopPct != -6 || ae.takePct != 12 {
		t.Errorf("stop/take = %v/%v, want -6/12", ae.stopPct, ae.takePct)
	}
	if ae.maxHoldDays != 3 {
		t.Errorf("maxHoldDays = %d, want 3", ae.maxHoldDays)
	}
	// SetStopTakeLoss only overwrites on valid sign.
	ae.SetStopTakeLoss(1, -1)
	if ae.stopPct != -6 {
		t.Errorf("stopPct mutated by positive stop, want -6")
	}
	if ae.takePct != 12 {
		t.Errorf("takePct mutated by negative take, want 12")
	}
}

func TestFixedFractionSizer(t *testing.T) {
	s := fixedFractionSizer{fraction: 0.25}
	if got := s.Size(0.9, 1000); got != 250 {
		t.Errorf("Size = %v, want 250 (equity*frac, prob ignored)", got)
	}
}

func TestPeriodKey(t *testing.T) {
	now := time.Date(2026, 10, 14, 12, 0, 0, 0, time.UTC)
	if got := periodKey("daily", now); got != "2026-10-14" {
		t.Errorf("daily = %v, want 2026-10-14", got)
	}
	weekly := periodKey("weekly", now)
	if weekly == "" {
		t.Error("weekly period key empty")
	}
	if got := periodKey("monthly", now); got != "2026-10" {
		t.Errorf("monthly = %v, want 2026-10", got)
	}
	if got := periodKey("nonsense", now); got != "" {
		t.Errorf("unknown period = %v, want empty", got)
	}
}

func TestFastLoop_SpyGettersAndSetters(t *testing.T) {
	fl := NewFastLoop(nil, nil, nil, nil, nil, time.Second)

	if fl.GetSpyPrice() != 0 || fl.GetSpyEMA() != 0 || fl.GetSpyBelowSMA() {
		t.Error("fresh loop: SPY price/EMA should be 0 and regime bull")
	}

	fl.mu.Lock()
	fl.spyPrice = 99.5
	fl.spyEMA = 100.0
	fl.spyBelowSMA = true
	fl.mu.Unlock()

	if fl.GetSpyPrice() != 99.5 || fl.GetSpyEMA() != 100 || !fl.GetSpyBelowSMA() {
		t.Error("SPY getters did not reflect set state")
	}

	// Setters that main.go wires after construction.
	fl.SetBroker(newMockBroker(1000))
	fl.SetMaxBuyPerCycle(5)
	if fl.maxBuyPerCycle != 5 {
		t.Errorf("maxBuyPerCycle = %d, want 5", fl.maxBuyPerCycle)
	}
	fl.SetModelQualityGate(func() bool { return true })
	fl.SetExecuteCallback(func(d TradeDecision) {})
	fl.SetLastCycle(time.Now())
	if fl.GetLastCycle().IsZero() {
		t.Error("SetLastCycle did not set")
	}
	if fl.GetDrift() == nil {
		t.Error("GetDrift nil on a constructed loop")
	}
}

func TestSma(t *testing.T) {
	// period 2 over [1,2,3,4] → [0, 1.5, 2.5, 3.5]
	got := sma([]float64{1, 2, 3, 4}, 2)
	want := []float64{0, 1.5, 2.5, 3.5}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("sma[%d] = %v, want %v (full %v)", i, got[i], want[i], got)
		}
	}
	// empty input
	if out := sma([]float64{}, 3); len(out) != 0 {
		t.Errorf("sma of empty = %v, want empty", out)
	}
}

func TestLearningLoop_Setters(t *testing.T) {
	ll := NewLearningLoop(20)
	fired := make(chan struct{}, 1)
	ll.SetDriftHook(func(model string, win bool) { fired <- struct{}{} })
	ll.RecordOutcome(TradeOutcome{Ticker: "AAPL", Side: "BUY", Model: "m", PnL: 1})
	select {
	case <-fired:
	case <-time.After(2 * time.Second):
		t.Fatal("drift hook not fired by RecordOutcome")
	}
}

func TestChampionChallenger_SetAUCGate(t *testing.T) {
	ll := NewLearningLoop(20)
	cc := NewChampionChallenger(ll)
	cc.SetAUCGate(0.60, func(model string) float64 { return 0.65 })
	if cc.minPromotionAUC != 0.60 {
		t.Errorf("minPromotionAUC = %v, want 0.60", cc.minPromotionAUC)
	}
}
