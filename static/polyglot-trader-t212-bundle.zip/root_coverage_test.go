package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/punit/polyglot-trader-t212/brain"
	"github.com/punit/polyglot-trader-t212/risk"
)

// --- CircuitBreaker ---

func TestCircuitBreaker_AllowRequest_Closed(t *testing.T) {
	cb := NewCircuitBreaker(3, -100, time.Second)
	allowed, retry := cb.AllowRequest()
	if !allowed || retry != 0 {
		t.Errorf("closed breaker: allowed=%v retry=%v, want true/0", allowed, retry)
	}
}

func TestCircuitBreaker_RecordFailure_Opens(t *testing.T) {
	cb := NewCircuitBreaker(2, -100, 50*time.Millisecond)
	cb.RecordFailure(2, 0)
	cb.RecordFailure(2, 0)
	// Now open
	allowed, retry := cb.AllowRequest()
	if allowed || retry <= 0 {
		t.Errorf("open breaker: allowed=%v retry=%v, want false/positive", allowed, retry)
	}
}

func TestCircuitBreaker_RecordFailure_HalfOpenToOpen(t *testing.T) {
	cb := NewCircuitBreaker(1, -100, 10*time.Millisecond)
	cb.RecordFailure(1, 0) // opens
	time.Sleep(15 * time.Millisecond)
	allowed, _ := cb.AllowRequest() // transitions to half-open
	if !allowed {
		t.Error("expected half-open to allow")
	}
	if cb.State() != CircuitHalfOpen {
		t.Errorf("state = %d, want half-open %d", cb.State(), CircuitHalfOpen)
	}
	cb.RecordFailure(1, 0) // re-opens
	if cb.State() != CircuitOpen {
		t.Errorf("state = %d, want open %d", cb.State(), CircuitOpen)
	}
}

func TestCircuitBreaker_RecordSuccess_ClosesHalfOpen(t *testing.T) {
	cb := NewCircuitBreaker(1, -100, 10*time.Millisecond)
	cb.RecordFailure(1, 0) // opens
	time.Sleep(15 * time.Millisecond)
	cb.AllowRequest()  // → half-open
	cb.RecordSuccess() // → closed
	if cb.State() != CircuitClosed {
		t.Errorf("state = %d, want closed %d", cb.State(), CircuitClosed)
	}
}

func TestCircuitBreaker_Reset(t *testing.T) {
	cb := NewCircuitBreaker(1, -100, time.Second)
	cb.RecordFailure(1, 0)
	if cb.State() != CircuitOpen {
		t.Fatal("expected open")
	}
	cb.Reset()
	if cb.State() != CircuitClosed {
		t.Errorf("state = %d, want closed", cb.State())
	}
}

func TestCircuitBreaker_Stats(t *testing.T) {
	cb := NewCircuitBreaker(3, -100, time.Second)
	cb.RecordSuccess()
	cb.RecordFailure(3, -50)
	stats := cb.Stats()
	if stats["total_calls"].(int64) != 2 {
		t.Errorf("total_calls = %v, want 2", stats["total_calls"])
	}
	if stats["daily_pnl"].(float64) != -50 {
		t.Errorf("daily_pnl = %v, want -50", stats["daily_pnl"])
	}
}

// --- KillSwitch ---

func TestKillSwitch_Activate_Idempotent(t *testing.T) {
	isolateStateDir(t) // Activate() → logKillEvent() writes kill_events.json; keep it out of the real audit log
	ks := &KillSwitch{}
	ks.Activate()
	if !ks.IsActive() {
		t.Error("expected active")
	}
	ks.Activate() // idempotent
	if !ks.IsActive() {
		t.Error("expected still active")
	}
	ks.Reset()
	if ks.IsActive() {
		t.Error("expected inactive after reset")
	}
}

func TestKillSwitch_handleKillSwitch_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/kill-switch", nil)
	w := httptest.NewRecorder()
	handleKillSwitch(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestKillSwitch_handleKillSwitch_Activate(t *testing.T) {
	isolateStateDir(t)
	killSwitch.Reset()
	paperTrader.portfolio = PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 5, EntryPrice: 10, CurrentPrice: 10},
	}}

	req := httptest.NewRequest(http.MethodPost, "/api/kill-switch", nil)
	w := httptest.NewRecorder()
	handleKillSwitch(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
	var resp map[string]string
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["status"] != "halted" {
		t.Errorf("status = %v, want halted", resp["status"])
	}
	if !killSwitch.IsActive() {
		t.Error("expected kill switch active")
	}
	// Positions should be flattened
	if len(paperTrader.Portfolio().Positions) != 0 {
		t.Errorf("positions = %d, want 0", len(paperTrader.Portfolio().Positions))
	}
	killSwitch.Reset()
}

// TestKillEvent_FileSplit guards the two-writer bug: kill events must land in
// their own append-only JSONL file (kill_events.json), never clobbering
// paper_trades.json, which must stay a single valid JSON array.
func TestKillEvent_FileSplit(t *testing.T) {
	isolateStateDir(t)
	killSwitch.Reset()
	// A trade first: writes paper_trades.json as a JSON array.
	pt := &PaperTrader{portfolio: PaperPortfolio{Cash: 1000}}
	setStoredPriceQuotes(t, pt)
	if err := pt.ExecuteTrade("AAPL", "BUY", 1, 10.0, "test"); err != nil {
		t.Fatalf("setup buy failed: %v", err)
	}
	// Activate the kill switch → appends to kill_events.json + rewrites the
	// trade array with a close-out SELL.
	killSwitch.Activate()
	defer killSwitch.Reset()

	// 1) kill_events.json exists and is valid JSONL.
	raw, err := os.ReadFile("kill_events.json")
	if err != nil {
		t.Fatalf("kill_events.json missing: %v", err)
	}
	lines := []string{}
	for _, ln := range splitNonEmptyLines(string(raw)) {
		var ev map[string]any
		if err := json.Unmarshal([]byte(ln), &ev); err != nil {
			t.Fatalf("kill_events.json line not valid JSON: %q (%v)", ln, err)
		}
		if ev["event"] != "kill_switch" {
			t.Errorf("kill event = %v, want kill_switch", ev["event"])
		}
		lines = append(lines, ln)
	}
	if len(lines) == 0 {
		t.Fatal("no kill events recorded")
	}

	// 2) paper_trades.json must still parse as a JSON array (no clobber).
	ta, err := os.ReadFile("paper_trades.json")
	if err != nil {
		t.Fatalf("paper_trades.json missing: %v", err)
	}
	var arr []map[string]any
	if err := json.Unmarshal(ta, &arr); err != nil {
		t.Fatalf("paper_trades.json not a JSON array (clobbered?): %v", err)
	}
}

// splitNonEmptyLines returns non-empty lines, stripping surrounding whitespace.
func splitNonEmptyLines(s string) []string {
	var out []string
	for _, ln := range strings.Split(s, "\n") {
		if t := strings.TrimSpace(ln); t != "" {
			out = append(out, t)
		}
	}
	return out
}

// --- Config helpers ---

func TestGetEnvNum(t *testing.T) {
	os.Setenv("TEST_GET_ENV_NUM", "42.5")
	defer os.Unsetenv("TEST_GET_ENV_NUM")
	if got := getEnvNum("TEST_GET_ENV_NUM", 1); got != 42.5 {
		t.Errorf("got %v, want 42.5", got)
	}
	// Missing → default
	if got := getEnvNum("TEST_NON_EXISTENT_XYZ", 7.0); got != 7.0 {
		t.Errorf("got %v, want 7.0", got)
	}
}

func TestMustParseFloat64(t *testing.T) {
	if got := mustParseFloat64("3.14", 0); got != 3.14 {
		t.Errorf("got %v, want 3.14", got)
	}
	if got := mustParseFloat64("abc", 9.9); got != 9.9 {
		t.Errorf("got %v, want 9.9", got)
	}
}

func TestGetContentType(t *testing.T) {
	tests := []struct{ path, want string }{
		{"/a.html", "text/html; charset=utf-8"},
		{"/a.css", "text/css"},
		{"/a.js", "application/javascript"},
		{"/a.png", "image/png"},
		{"/a.jpg", "image/jpeg"},
		{"/a.jpeg", "image/jpeg"},
		{"/a.gif", "image/gif"},
		{"/a.ico", "image/x-icon"},
		{"/a.bin", "application/octet-stream"},
	}
	for _, tc := range tests {
		if got := getContentType(tc.path); got != tc.want {
			t.Errorf("getContentType(%q) = %q, want %q", tc.path, got, tc.want)
		}
	}
}

func TestNormalizePort(t *testing.T) {
	if got := normalizePort("8081"); got != ":8081" {
		t.Errorf("got %q, want :8081", got)
	}
	if got := normalizePort(":9090"); got != ":9090" {
		t.Errorf("got %q, want :9090", got)
	}
}

func TestAuthHeader(t *testing.T) {
	h := authHeader()
	auth := h.Get("Authorization")
	if !bytes.HasPrefix([]byte(auth), []byte("Basic ")) {
		t.Errorf("auth = %q, want Basic prefix", auth)
	}
}

func TestConfig_Validate(t *testing.T) {
	c := &Config{
		T212ReadKey:       "k",
		T212ReadSecret:    "s",
		CircuitMaxErrors:  3,
		CircuitRecoverSec: 60,
		RetryMaxRetries:   2,
		RetryMultiplier:   2.0,
	}
	if err := c.Validate(); err != nil {
		t.Errorf("valid config: %v", err)
	}
	c2 := &Config{T212ReadKey: "", CircuitMaxErrors: 1, CircuitRecoverSec: 1, RetryMaxRetries: 0, RetryMultiplier: 1.0}
	if err := c2.Validate(); err == nil {
		t.Error("expected error for missing key")
	}
}

func TestParseUniverse(t *testing.T) {
	os.Setenv("TRADING_UNIVERSE", "aapl, msft,GOOGL")
	defer os.Unsetenv("TRADING_UNIVERSE")
	u := parseUniverse()
	if len(u) != 3 || u[0] != "AAPL" || u[1] != "MSFT" || u[2] != "GOOGL" {
		t.Errorf("universe = %v", u)
	}
}

// --- RuntimeConfig ---

func TestRuntimeConfig_AutoExecuteEnabled(t *testing.T) {
	if !runtimeCfg.AutoExecuteEnabled() {
		t.Error("expected auto execute enabled")
	}
	runtimeCfg.AutoExecute = false
	if runtimeCfg.AutoExecuteEnabled() {
		t.Error("expected auto execute disabled")
	}
	runtimeCfg.AutoExecute = true
}

func TestRuntimeConfig_Snapshot(t *testing.T) {
	snap := runtimeCfg.Snapshot()
	if snap.MinTradeSize != runtimeCfg.MinTradeSize {
		t.Error("snapshot mismatch")
	}
}

func TestToF64(t *testing.T) {
	if got := toF64(3.14); got != 3.14 {
		t.Errorf("got %v, want 3.14", got)
	}
	if got := toF64("not a float"); got != 0 {
		t.Errorf("got %v, want 0", got)
	}
}

func TestHandleConfig_Get(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/config", nil)
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleConfig)(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["config"] == nil {
		t.Error("expected config in response")
	}
}

func TestHandleConfig_Post(t *testing.T) {
	isolateStateDir(t)
	body := `{"min_trade_size": 10, "auto_execute": false}`
	req := httptest.NewRequest(http.MethodPost, "/api/config", bytes.NewBuffer([]byte(body)))
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleConfig)(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
	if runtimeCfg.MinTradeSize != 10 {
		t.Errorf("min_trade_size = %v, want 10", runtimeCfg.MinTradeSize)
	}
	if runtimeCfg.AutoExecute {
		t.Error("expected auto_execute false")
	}
	runtimeCfg.MinTradeSize = 5
	runtimeCfg.AutoExecute = true
}

func TestHandleConfig_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodPut, "/api/config", nil)
	req.Header.Set("Authorization", basicAuth("test-key", "test-secret"))
	w := httptest.NewRecorder()
	authMiddleware(handleConfig)(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

// --- HTTP handlers: paper ---

func TestHandlePaperPortfolio_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/paper/portfolio", nil)
	w := httptest.NewRecorder()
	handlePaperPortfolio(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandlePaperPortfolio_OK(t *testing.T) {
	isolateStateDir(t)
	req := httptest.NewRequest(http.MethodGet, "/api/paper/portfolio", nil)
	w := httptest.NewRecorder()
	handlePaperPortfolio(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
}

func TestHandlePaperPositions_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/paper/positions", nil)
	w := httptest.NewRecorder()
	handlePaperPositions(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandlePaperPositions_OK(t *testing.T) {
	isolateStateDir(t)
	req := httptest.NewRequest(http.MethodGet, "/api/paper/positions", nil)
	w := httptest.NewRecorder()
	handlePaperPositions(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
}

func TestHandlePaperTrades_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/paper/trades", nil)
	w := httptest.NewRecorder()
	handlePaperTrades(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandlePaperTrades_OK(t *testing.T) {
	isolateStateDir(t)
	req := httptest.NewRequest(http.MethodGet, "/api/paper/trades", nil)
	w := httptest.NewRecorder()
	handlePaperTrades(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
}

func TestHandlePaperSignals_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/paper/signals", nil)
	w := httptest.NewRecorder()
	handlePaperSignals(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandlePaperSignals_OK(t *testing.T) {
	isolateStateDir(t)
	req := httptest.NewRequest(http.MethodGet, "/api/paper/signals", nil)
	w := httptest.NewRecorder()
	handlePaperSignals(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
}

func TestHandlePaperExecuteTrade_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/paper/execute", nil)
	w := httptest.NewRecorder()
	handlePaperExecuteTrade(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandlePaperExecuteTrade_Valid(t *testing.T) {
	isolateStateDir(t)
	body := `{"ticker":"AAPL","side":"BUY","quantity":2,"price":50,"reason":"test"}`
	req := httptest.NewRequest(http.MethodPost, "/api/paper/execute", bytes.NewBuffer([]byte(body)))
	w := httptest.NewRecorder()
	handlePaperExecuteTrade(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200: %s", w.Code, w.Body.String())
	}
}

func TestHandlePaperExecuteTrade_MissingFields(t *testing.T) {
	isolateStateDir(t)
	body := `{"ticker":"","side":"","quantity":0}`
	req := httptest.NewRequest(http.MethodPost, "/api/paper/execute", bytes.NewBuffer([]byte(body)))
	w := httptest.NewRecorder()
	handlePaperExecuteTrade(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("got %d, want 400", w.Code)
	}
}

// --- HTTP handlers: main ---

func TestHandleQuotes(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/quotes", nil)
	w := httptest.NewRecorder()
	handleQuotes(w, req)
	if w.Code != http.StatusNotImplemented {
		t.Errorf("got %d, want 501", w.Code)
	}
}

func TestHandleEquity_OK(t *testing.T) {
	isolateStateDir(t)
	req := httptest.NewRequest(http.MethodGet, "/api/equity", nil)
	w := httptest.NewRecorder()
	handleEquity(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
}

func TestHandleSotaStatus_Disabled(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/sota/status", nil)
	w := httptest.NewRecorder()
	handleSotaStatus(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d, want 200", w.Code)
	}
	var resp map[string]interface{}
	json.NewDecoder(w.Body).Decode(&resp)
	if resp["status"] != "disabled" {
		t.Errorf("status = %v, want disabled", resp["status"])
	}
}

func TestHandleSotaDecisions_Disabled(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/sota/decisions", nil)
	w := httptest.NewRecorder()
	handleSotaDecisions(w, req)
	if w.Code != http.StatusServiceUnavailable {
		t.Errorf("got %d, want 503", w.Code)
	}
}

func TestHandleSotaTrain_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/sota/train", nil)
	w := httptest.NewRecorder()
	handleSotaTrain(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandleSotaTrain_NotInitialized(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/sota/train", nil)
	w := httptest.NewRecorder()
	handleSotaTrain(w, req)
	if w.Code != http.StatusServiceUnavailable {
		t.Errorf("got %d, want 503", w.Code)
	}
}

func TestHandleSotaCloseAll_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/sota/close-all", nil)
	w := httptest.NewRecorder()
	handleSotaCloseAll(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandleSotaCloseAll_NotInitialized(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/sota/close-all", nil)
	w := httptest.NewRecorder()
	handleSotaCloseAll(w, req)
	if w.Code != http.StatusServiceUnavailable {
		t.Errorf("got %d, want 503", w.Code)
	}
}

// --- paperBrokerAdapter ---

func TestPaperBrokerAdapter_ExecuteTrade(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 100}
	a := &paperBrokerAdapter{}
	err := a.ExecuteTrade("AAPL", "BUY", 1, 10, "test")
	if err != nil {
		t.Fatalf("ExecuteTrade: %v", err)
	}
}

func TestPaperBrokerAdapter_GetPositionPrice(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "FAKETK1", Quantity: 1, EntryPrice: 10, CurrentPrice: 12},
	}}
	a := &paperBrokerAdapter{}
	// Yahoo will fail in test env → falls back to stored price
	p := a.GetPositionPrice("FAKETK1")
	if p != 12 {
		t.Errorf("price = %v, want 12", p)
	}
}

func TestPaperBrokerAdapter_GetEquity(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 1, EntryPrice: 10, CurrentPrice: 12},
	}}
	a := &paperBrokerAdapter{}
	eq := a.GetEquity()
	if eq <= 0 {
		t.Errorf("equity = %v, want > 0", eq)
	}
}

func TestPaperBrokerAdapter_Positions(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 100, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 1, EntryPrice: 10, CurrentPrice: 12, Reason: "test"},
	}}
	a := &paperBrokerAdapter{}
	positions := a.Positions()
	if len(positions) != 1 {
		t.Fatalf("positions = %d, want 1", len(positions))
	}
	if positions[0].Ticker != "AAPL" {
		t.Errorf("ticker = %v, want AAPL", positions[0].Ticker)
	}
}

// --- autoRiskGateCheck ---

func TestAutoRiskGateCheck_OK(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 1000, TotalValue: 1000}
	// fastLoop nil → spyPrice=0, spyEMA=0 → MacroRegime gate passes
	d := brain.TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 150}
	if !autoRiskGateCheck(d) {
		t.Error("expected autoRiskGateCheck to pass")
	}
}

func TestAutoRiskGateCheck_Blocked(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{
		Cash: 1000, TotalValue: 1000,
		DailyPnL: -100, PnLDayKey: time.Now().Format("2006-01-02"),
	}
	d := brain.TradeDecision{Ticker: "AAPL", Action: "BUY", Price: 150}
	if autoRiskGateCheck(d) {
		t.Error("expected autoRiskGateCheck to block (drawdown breach)")
	}
}

// --- kellySizerAdapter ---

func TestKellySizerAdapter_Size(t *testing.T) {
	k := risk.NewQuarterKellySizer(10, 80, 5)
	adapter := &kellySizerAdapter{kelly: k}
	n := adapter.Size(0.7, 1000)
	if n <= 0 {
		t.Errorf("Size(0.7, 1000) = %v, want > 0", n)
	}
}

// --- ResetPaper ---

func TestResetPaper(t *testing.T) {
	isolateStateDir(t)
	paperTrader.portfolio = PaperPortfolio{Cash: 999, Positions: []PaperPosition{
		{Ticker: "AAPL", Quantity: 1, EntryPrice: 10, CurrentPrice: 12},
	}}
	ResetPaper()
	pf := paperTrader.portfolio
	if pf.Cash != 1000 {
		t.Errorf("cash = %v, want 1000", pf.Cash)
	}
	if len(pf.Positions) != 0 {
		t.Errorf("positions = %d, want 0", len(pf.Positions))
	}
}

// --- handleJSON (via a test T212 server) ---

func TestHandleJSON_Success(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()
	baseURL = srv.URL
	w := httptest.NewRecorder()
	handleJSON(w, "/api/v0/equity/positions")
	if w.Code != http.StatusOK {
		t.Errorf("got %d, want 200", w.Code)
	}
}

func TestHandleJSON_APIError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer srv.Close()
	baseURL = srv.URL
	w := httptest.NewRecorder()
	handleJSON(w, "/api/v0/equity/positions")
	if w.Code != http.StatusInternalServerError {
		t.Errorf("got %d, want 500", w.Code)
	}
}

func TestHandleJSON_Params(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.RawQuery == "a=1&b=2" {
			w.Write([]byte(`{}`))
			return
		}
		w.WriteHeader(404)
	}))
	defer srv.Close()
	baseURL = srv.URL
	w := httptest.NewRecorder()
	handleJSON(w, "/api/test", "a=1", "b=2")
	if w.Code != http.StatusOK {
		t.Errorf("got %d, want 200", w.Code)
	}
}

// --- handleInstruments ---

func TestHandleInstruments_MethodNotAllowed(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/instruments", nil)
	w := httptest.NewRecorder()
	handleInstruments(w, req)
	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("got %d, want 405", w.Code)
	}
}

func TestHandleInstruments_OK(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/instruments", nil)
	w := httptest.NewRecorder()
	handleInstruments(w, req)
	if w.Code != http.StatusOK {
		t.Errorf("got %d, want 200", w.Code)
	}
}

// --- Config Reload ---

func TestConfig_Reload(t *testing.T) {
	isolateStateDir(t)
	os.Unsetenv("T212_BASE_URL")
	os.WriteFile(".env", []byte("T212_BASE_URL=http://test\n"), 0644)
	c := &Config{}
	c.Reload()
	if c.T212BaseURL != "http://test" {
		t.Errorf("base_url = %v, want http://test", c.T212BaseURL)
	}
	os.Setenv("T212_BASE_URL", "https://api.trading212.com")
}

// --- RuntimeConfig LoadFile / SaveFile ---

func TestRuntimeConfig_SaveLoadFile(t *testing.T) {
	isolateStateDir(t)
	runtimeCfg.DailyBudget = 50
	runtimeCfg.SaveFile()
	runtimeCfg.DailyBudget = 100
	runtimeCfg.LoadFile()
	if runtimeCfg.DailyBudget != 50 {
		t.Errorf("daily_budget = %v, want 50", runtimeCfg.DailyBudget)
	}
	runtimeCfg.DailyBudget = 0
}

// --- RuntimeConfig LoadEnv ---

func TestRuntimeConfig_LoadEnv(t *testing.T) {
	os.Setenv("TRADING_DAILY_BUDGET", "75")
	os.Setenv("MIN_TRADE_SIZE", "12")
	os.Setenv("TRADING_STOP_LOSS_PCT", "6")
	os.Setenv("TRADING_TAKE_PROFIT_PCT", "9")
	defer func() {
		os.Unsetenv("TRADING_DAILY_BUDGET")
		os.Unsetenv("MIN_TRADE_SIZE")
		os.Unsetenv("TRADING_STOP_LOSS_PCT")
		os.Unsetenv("TRADING_TAKE_PROFIT_PCT")
	}()
	runtimeCfg.LoadEnv()
	if runtimeCfg.DailyBudget != 75 {
		t.Errorf("daily_budget = %v, want 75", runtimeCfg.DailyBudget)
	}
	if runtimeCfg.MinTradeSize != 12 {
		t.Errorf("min_trade_size = %v, want 12", runtimeCfg.MinTradeSize)
	}
	if runtimeCfg.StopLossPct != -6 {
		t.Errorf("stop_loss_pct = %v, want -6", runtimeCfg.StopLossPct)
	}
	if runtimeCfg.TakeProfitPct != 9 {
		t.Errorf("take_profit_pct = %v, want 9", runtimeCfg.TakeProfitPct)
	}
}

// --- handleSotaDecisions with limit param ---

func TestHandleSotaDecisions_LimitParam(t *testing.T) {
	// fastLoop nil → 503 regardless of limit
	req := httptest.NewRequest(http.MethodGet, "/api/sota/decisions?limit=5", nil)
	w := httptest.NewRecorder()
	handleSotaDecisions(w, req)
	if w.Code != http.StatusServiceUnavailable {
		t.Errorf("got %d, want 503", w.Code)
	}
}

// --- IsShuttingDown ---

func TestIsShuttingDown(t *testing.T) {
	if IsShuttingDown() {
		t.Error("expected not shutting down")
	}
}

// --- envOr ---

func TestEnvOr(t *testing.T) {
	os.Setenv("TEST_ENV_OR", "val")
	defer os.Unsetenv("TEST_ENV_OR")
	if got := envOr("TEST_ENV_OR", "def"); got != "val" {
		t.Errorf("got %v, want val", got)
	}
	if got := envOr("TEST_NON_EXISTENT", "def"); got != "def" {
		t.Errorf("got %v, want def", got)
	}
}

// --- envFloat ---

func TestEnvFloat(t *testing.T) {
	os.Setenv("TEST_ENV_FLOAT", "2.5")
	defer os.Unsetenv("TEST_ENV_FLOAT")
	if got := envFloat("TEST_ENV_FLOAT", 1.0); got != 2.5 {
		t.Errorf("got %v, want 2.5", got)
	}
	if got := envFloat("TEST_NON_EXISTENT_X", 3.0); got != 3.0 {
		t.Errorf("got %v, want 3.0", got)
	}
}

// --- Config getEnv ---

func TestGetEnv(t *testing.T) {
	os.Setenv("TEST_GET_ENV_KEY", "hello")
	defer os.Unsetenv("TEST_GET_ENV_KEY")
	if got := getEnv("TEST_GET_ENV_KEY", "def"); got != "hello" {
		t.Errorf("got %v, want hello", got)
	}
	if got := getEnv("TEST_NON_EXISTENT_Y", "def"); got != "def" {
		t.Errorf("got %v, want def", got)
	}
}

// --- mustParseInt ---

func TestMustParseInt(t *testing.T) {
	if got := mustParseInt("42", 0); got != 42 {
		t.Errorf("got %v, want 42", got)
	}
	if got := mustParseInt("abc", 7); got != 7 {
		t.Errorf("got %v, want 7", got)
	}
}
