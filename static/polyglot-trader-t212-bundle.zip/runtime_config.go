package main

import (
	"encoding/json"
	"log/slog"
	"net/http"
	"os"
	"sync"

	"github.com/punit/polyglot-trader-t212/risk"
)

// RuntimeConfig holds live-editable trading parameters.
// Env vars are defaults at boot; POST /api/config overrides at runtime.
type RuntimeConfig struct {
	DailyBudget   float64 `json:"daily_budget"`
	WeeklyBudget  float64 `json:"weekly_budget"`
	MonthlyBudget float64 `json:"monthly_budget"`
	MaxOrderValue float64 `json:"max_order_value"` // max £ notional per single order (0 = unlimited)
	MinTradeSize  float64 `json:"min_trade_size"`  // min £ notional per order; below this the sizer skips
	MinConfidence float64 `json:"min_confidence"`  // min model confidence to auto-trade
	StopLossPct   float64 `json:"stop_loss_pct"`   // negative, e.g. -4
	TakeProfitPct float64 `json:"take_profit_pct"` // positive, e.g. 8
	AutoExecute   bool    `json:"auto_execute"`    // master switch for ML auto-execution
}

var (
	runtimeCfg = &RuntimeConfig{MinTradeSize: 5, MinConfidence: 0.55, StopLossPct: -4, TakeProfitPct: 8, AutoExecute: true}
	runtimeMu  sync.RWMutex

	// minValidAUC is the model-quality bar, seeded from MIN_VALID_AUC env in
	// LoadEnv (default 0.53 — see updateModelQualityGate for why the bar is
	// 0.53, not 0.55).
	minValidAUC = 0.53
)

// kellySizer is set at startup; Apply() pushes MinTradeSize into it.
var kellySizer *risk.QuarterKellySizer

const configFile = "runtime_config.json"

// LoadFile restores runtimeCfg from a previous save (if any) so UI/API
// edits survive a pod restart. Env defaults are already loaded.
func (rc *RuntimeConfig) LoadFile() {
	data, err := os.ReadFile(configFile)
	if err != nil {
		return // no saved config yet — env/struct defaults stand
	}
	var saved RuntimeConfig
	if err := json.Unmarshal(data, &saved); err != nil {
		slog.Warn("runtime config: failed to load saved config, using defaults", "error", err)
		return
	}
	runtimeMu.Lock()
	rc.MinTradeSize, rc.MinConfidence = saved.MinTradeSize, saved.MinConfidence
	rc.StopLossPct, rc.TakeProfitPct, rc.AutoExecute = saved.StopLossPct, saved.TakeProfitPct, saved.AutoExecute
	rc.DailyBudget, rc.WeeklyBudget, rc.MonthlyBudget = saved.DailyBudget, saved.WeeklyBudget, saved.MonthlyBudget
	rc.MaxOrderValue = saved.MaxOrderValue
	runtimeMu.Unlock()
	slog.Info("runtime config: loaded saved config from disk")
}

// SaveFile persists the current config so it survives restarts.
func (rc *RuntimeConfig) SaveFile() {
	snap := rc.Snapshot()
	data, err := json.MarshalIndent(snap, "", "  ")
	if err != nil {
		return
	}
	if err := atomicWrite(configFile, data, 0644); err != nil {
		slog.Warn("runtime config: failed to persist config", "error", err)
	}
}

// loadEnvDefaults seeds runtimeCfg from env (only non-zero values override).
func (rc *RuntimeConfig) LoadEnv() {
	runtimeMu.Lock()
	defer runtimeMu.Unlock()
	if v := getEnvF64("MIN_VALID_AUC", 0); v > 0 && v <= 1 {
		minValidAUC = v
	}
	if v := getEnvF64("TRADING_DAILY_BUDGET", 0); v > 0 {
		rc.DailyBudget = v
	}
	if v := getEnvF64("TRADING_WEEKLY_BUDGET", 0); v > 0 {
		rc.WeeklyBudget = v
	}
	if v := getEnvF64("TRADING_MONTHLY_BUDGET", 0); v > 0 {
		rc.MonthlyBudget = v
	}
	if v := getEnvF64("MAX_DOLLARS_PER_ORDER", 0); v > 0 {
		rc.MaxOrderValue = v
	}
	if v := getEnvF64("MIN_TRADE_SIZE", 0); v > 0 {
		rc.MinTradeSize = v
	}
	if v := getEnvF64("MIN_CONFIDENCE", 0); v > 0 && v <= 1 {
		rc.MinConfidence = v
	}
	if v := getEnvF64("TRADING_STOP_LOSS_PCT", 0); v > 0 {
		rc.StopLossPct = -v
	}
	if v := getEnvF64("TRADING_TAKE_PROFIT_PCT", 0); v > 0 {
		rc.TakeProfitPct = v
	}
	if os.Getenv("SOTA_EXECUTE") == "false" {
		rc.AutoExecute = false
	}
}

// Apply pushes current settings to live components (nil-safe).
func (rc *RuntimeConfig) Apply() {
	runtimeMu.RLock()
	defer runtimeMu.RUnlock()
	if autoExec != nil {
		autoExec.SetBudgets(rc.DailyBudget, rc.WeeklyBudget, rc.MonthlyBudget)
		autoExec.SetMaxOrderValue(rc.MaxOrderValue)
		autoExec.SetStopTakeLoss(rc.StopLossPct, rc.TakeProfitPct)
	}
	if kellySizer != nil && rc.MinTradeSize > 0 {
		kellySizer.SetMinTradeSize(rc.MinTradeSize)
	}
	if fastLoop != nil {
		rp := fastLoop.GetRisk().GetCurrentRisk()
		fastLoop.GetRisk().SetParameters(rp.MaxPositionPct, rp.MaxDrawdownPct, rc.MinConfidence)
	}
	slog.Info("runtime config applied",
		"daily_budget", rc.DailyBudget,
		"weekly_budget", rc.WeeklyBudget,
		"monthly_budget", rc.MonthlyBudget,
		"max_order_value", rc.MaxOrderValue,
		"min_trade_size", rc.MinTradeSize,
		"min_confidence", rc.MinConfidence,
		"stop_loss_pct", rc.StopLossPct,
		"take_profit_pct", rc.TakeProfitPct,
		"auto_execute", rc.AutoExecute,
	)
}

// AutoExecuteEnabled reports the live master switch for auto-execution.
func (rc *RuntimeConfig) AutoExecuteEnabled() bool {
	runtimeMu.RLock()
	defer runtimeMu.RUnlock()
	return rc.AutoExecute
}

// Snapshot returns a copy of the config (safe for JSON).
func (rc *RuntimeConfig) Snapshot() RuntimeConfig {
	runtimeMu.RLock()
	defer runtimeMu.RUnlock()
	return *rc
}

// toF64 converts a JSON-decoded number safely.
func toF64(v interface{}) float64 {
	if f, ok := v.(float64); ok {
		return f
	}
	return 0
}

// handleConfig is the HTTP handler for GET/POST /api/config.
// GET: full runtime settings + live budget usage + kill switch state.
// POST: partial update of any known field.
func handleConfig(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		rc := runtimeCfg.Snapshot()
		resp := map[string]interface{}{
			"config": rc,
		}
		if autoExec != nil {
			resp["budget"] = autoExec.GetBudgetState()
		}
		resp["kill_switch"] = killSwitch.IsActive()
		if fastLoop != nil {
			resp["fast_loop_enabled"] = fastLoop.IsEnabled()
			resp["risk"] = fastLoop.GetRisk().GetCurrentRisk()
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(resp)

	case http.MethodPost:
		var req map[string]interface{}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "invalid request body", 400)
			return
		}
		runtimeMu.Lock()
		if v, ok := req["daily_budget"]; ok {
			runtimeCfg.DailyBudget = toF64(v)
		}
		if v, ok := req["weekly_budget"]; ok {
			runtimeCfg.WeeklyBudget = toF64(v)
		}
		if v, ok := req["monthly_budget"]; ok {
			runtimeCfg.MonthlyBudget = toF64(v)
		}
		if v, ok := req["max_order_value"]; ok {
			runtimeCfg.MaxOrderValue = toF64(v)
		}
		if v, ok := req["min_trade_size"]; ok {
			if c := toF64(v); c > 0 && c < 1000000 {
				runtimeCfg.MinTradeSize = c
			}
		}
		if v, ok := req["min_confidence"]; ok {
			if c := toF64(v); c > 0 && c <= 1 {
				runtimeCfg.MinConfidence = c
			}
		}
		if v, ok := req["stop_loss_pct"]; ok {
			if c := toF64(v); c < 0 && c >= -50 {
				runtimeCfg.StopLossPct = c
			}
		}
		if v, ok := req["take_profit_pct"]; ok {
			if c := toF64(v); c > 0 && c < 500 {
				runtimeCfg.TakeProfitPct = c
			}
		}
		if v, ok := req["auto_execute"]; ok {
			if b, ok2 := v.(bool); ok2 {
				runtimeCfg.AutoExecute = b
			}
		}
		runtimeMu.Unlock()
		runtimeCfg.SaveFile()
		runtimeCfg.Apply()
		// Paper reset is destructive; only when explicitly requested
		if reset, ok := req["reset_paper"]; ok {
			if b, ok2 := reset.(bool); ok2 && b {
				ResetPaper()
			}
		}
		slog.Info("runtime config updated via /api/config")
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"status": "updated",
			"config": runtimeCfg.Snapshot(),
		})

	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}
