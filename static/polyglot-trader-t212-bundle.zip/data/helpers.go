package data

import "encoding/json"

// featuresToJSON converts a feature map to a JSON string for SQLite storage.
func featuresToJSON(f map[string]float64) string {
	if f == nil {
		return "{}"
	}
	data, err := json.Marshal(f)
	if err != nil {
		return "{}"
	}
	return string(data)
}
