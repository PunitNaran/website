package data

import (
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// ---------- helpers ----------

// genCandles makes n strictly increasing candles with deterministic values.
func genCandles(n int, ticker string) []OHLCV {
	base := time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC)
	rows := make([]OHLCV, n)
	price := 100.0
	for i := 0; i < n; i++ {
		c := price * 1.001
		rows[i] = OHLCV{
			Ticker: ticker,
			Date:   base.AddDate(0, 0, i),
			Open:   price,
			High:   c + 0.01,
			Low:    price - 0.01,
			Close:  c,
			Volume: 1000 + float64(i),
		}
		price = c
	}
	return rows
}

func approx(a, b float64) bool { return math.Abs(a-b) < 1e-9 }

// ---------- indicators ----------

func TestSMA(t *testing.T) {
	got := SMA([]float64{1, 2, 3, 4, 5}, 3)
	want := []float64{0, 0, 2, 3, 4}
	for i := range want {
		if !approx(got[i], want[i]) {
			t.Fatalf("SMA[%d] = %v, want %v", i, got[i], want[i])
		}
	}
	// n < period → all zeros
	if g := SMA([]float64{1, 2}, 5); g[0] != 0 || g[1] != 0 {
		t.Fatalf("SMA short series should be zero: %v", g)
	}
}

func TestEMA(t *testing.T) {
	got := EMA([]float64{1, 2, 3}, 2)
	if !approx(got[0], 1) || !approx(got[1], 5.0/3.0) || !approx(got[2], 23.0/9.0) {
		t.Fatalf("EMA = %v, want [1 1.6667 2.5556]", got)
	}
	if len(EMA(nil, 5)) != 0 {
		t.Fatal("EMA(nil) should be empty")
	}
}

func TestRSI(t *testing.T) {
	// All gains → RSI = 100 from the first valid index.
	up := make([]float64, 20)
	for i := range up {
		up[i] = float64(i)
	}
	got := RSI(up, 14)
	if !approx(got[14], 100) || !approx(got[19], 100) {
		t.Fatalf("RSI all-up: got[%d]=%v got[%d]=%v, want 100", 14, got[14], 19, got[19])
	}
	if got[0] != 0 || got[13] != 0 {
		t.Fatalf("RSI warmup should be zero: %v %v", got[0], got[13])
	}
	// All losses → RSI = 0.
	down := make([]float64, 20)
	for i := range down {
		down[i] = 100 - float64(i)
	}
	gd := RSI(down, 14)
	if !approx(gd[14], 0) || !approx(gd[19], 0) {
		t.Fatalf("RSI all-down = %v, want 0", gd[14:])
	}
	// n < period+1 → all zeros.
	if g := RSI([]float64{1, 2}, 14); g[0] != 0 || g[1] != 0 {
		t.Fatal("RSI short series should be zero")
	}
}

func TestMACD(t *testing.T) {
	constant := make([]float64, 50)
	for i := range constant {
		constant[i] = 5
	}
	macd, signal := MACD(constant)
	for i := range macd {
		if !approx(macd[i], 0) || !approx(signal[i], 0) {
			t.Fatalf("MACD constant series: macd[%d]=%v signal[%d]=%v", i, macd[i], i, signal[i])
		}
	}
	// Rising series → positive MACD at the end.
	up := genCandles(60, "X")
	closes := make([]float64, 60)
	for i, r := range up {
		closes[i] = r.Close
	}
	m2, s2 := MACD(closes)
	if m2[59] <= 0 || s2[59] <= 0 {
		t.Fatalf("MACD rising: macd=%v signal=%v, want positive", m2[59], s2[59])
	}
}

func TestBollingerBands(t *testing.T) {
	constant := make([]float64, 30)
	for i := range constant {
		constant[i] = 10
	}
	upper, lower := BollingerBands(constant, 20, 2.0)
	for i := 19; i < 30; i++ {
		if !approx(upper[i], 10) || !approx(lower[i], 10) {
			t.Fatalf("BB constant: upper[%d]=%v lower[%d]=%v", i, upper[i], i, lower[i])
		}
	}
	if upper[0] != 0 || lower[0] != 0 {
		t.Fatal("BB warmup should be zero")
	}
	// Rising data: upper > lower.
	up := genCandles(30, "X")
	closes := make([]float64, 30)
	for i, r := range up {
		closes[i] = r.Close
	}
	u2, l2 := BollingerBands(closes, 20, 2.0)
	if u2[29] <= l2[29] {
		t.Fatalf("BB: upper %v should exceed lower %v", u2[29], l2[29])
	}
}

func TestATR(t *testing.T) {
	n := 20
	highs, lows, closes := make([]float64, n), make([]float64, n), make([]float64, n)
	for i := 0; i < n; i++ {
		closes[i] = float64(i + 10)
		highs[i] = float64(i + 11)
		lows[i] = float64(i + 9)
	}
	got := ATR(highs, lows, closes, 14)
	// True range is 2 every bar → ATR = 2 from index 14 on.
	if !approx(got[14], 2) || !approx(got[19], 2) {
		t.Fatalf("ATR = %v, want 2", got[14:])
	}
	if got[0] != 0 || got[13] != 0 {
		t.Fatal("ATR warmup should be zero")
	}
	// n < period+1 → zeros.
	if g := ATR([]float64{1}, []float64{0}, []float64{1}, 14); g[0] != 0 {
		t.Fatal("ATR short series should be zero")
	}
	// Gap up: true range uses prevClose-low.
	h := []float64{10, 20}
	l := []float64{9, 11}
	c := []float64{9.5, 19}
	g2 := ATR(h, l, c, 1)
	if !approx(g2[1], 10.5) { // max(20-11, 20-9.5) = 10.5
		t.Fatalf("ATR gap = %v, want 10.5", g2[1])
	}
}

func TestStdev(t *testing.T) {
	v := []float64{1, 2, 3}
	if !approx(stdev(v, 0, 3), 2.0/3.0) {
		t.Fatalf("stdev = %v, want 0.6667", stdev(v, 0, 3))
	}
	if stdev(v, 2, 2) != 0 || stdev(v, -1, 2) != 0 || stdev(v, 0, 5) != 0 {
		t.Fatal("stdev invalid ranges should be 0")
	}
}

func TestSmallHelpers(t *testing.T) {
	if pctChange(110, 100) != 0.1 {
		t.Fatal("pctChange")
	}
	if pctChange(5, 0) != 0 {
		t.Fatal("pctChange prev=0 should be 0")
	}
	if ratio(10, 4) != 2.5 {
		t.Fatal("ratio")
	}
	if ratio(10, 0) != 0 {
		t.Fatal("ratio b=0 should be 0")
	}
	if bbPosition(6, 10, 2) != 0.5 {
		t.Fatal("bbPosition")
	}
	if bbPosition(5, 7, 7) != 0.5 {
		t.Fatal("bbPosition upper==lower should be 0.5")
	}
	vols := []float64{1, 2, 3, 4, 5}
	if got := volumeRatio(vols, 3, 2); !approx(got, 1.6) {
		t.Fatalf("volumeRatio = %v, want 1.6", got)
	}
	if volumeRatio(vols, 1, 2) != 1.0 {
		t.Fatal("volumeRatio i<period should be 1")
	}
	if volumeRatio([]float64{0}, 0, 1) != 1.0 {
		t.Fatal("volumeRatio zero vol should be 1")
	}
	if closePosition(5.5, 6, 5) != 0.5 {
		t.Fatal("closePosition")
	}
	if closePosition(5, 5, 5) != 0.5 {
		t.Fatal("closePosition high==low should be 0.5")
	}
}

func TestDataError(t *testing.T) {
	e := &DataError{msg: "boom"}
	if e.Error() != "boom" {
		t.Fatalf("DataError.Error = %q", e.Error())
	}
}

// ---------- features ----------

func TestFeaturesToJSON(t *testing.T) {
	if featuresToJSON(nil) != "{}" {
		t.Fatal("featuresToJSON(nil) should be {}")
	}
	got := featuresToJSON(map[string]float64{"a": 1, "b": 2.5})
	var m map[string]float64
	if err := json.Unmarshal([]byte(got), &m); err != nil || m["a"] != 1 || m["b"] != 2.5 {
		t.Fatalf("featuresToJSON = %q err=%v", got, err)
	}
}

func TestComputeFeatures(t *testing.T) {
	fe := NewFeatureEngine()
	rows := genCandles(200, "TEST")
	f := fe.ComputeFeatures(rows)
	if len(f) != 200-120 {
		t.Fatalf("len(features) = %d, want %d", len(f), 80)
	}
	first := f[0]
	if first.Ticker != "TEST" || !first.Date.Equal(rows[120].Date) {
		t.Fatalf("first feature: ticker=%v date=%v", first.Ticker, first.Date)
	}
	// Monotonic +0.1%/day → 5-day return ≈ +0.50% (> +0.5% deadband) →
	// every row with 5 bars of forward data wins. The last 5 rows lack a
	// 5-day forward window → TargetWin=-1 (deadband/no-data).
	for i, fr := range f {
		if i < len(f)-5 && fr.TargetWin != 1 {
			t.Fatalf("row %d TargetWin = %d, want 1", i, fr.TargetWin)
		}
		if i >= len(f)-5 && fr.TargetWin != -1 {
			t.Fatalf("row %d (last 5) TargetWin = %d, want -1", i, fr.TargetWin)
		}
		if fr.Features["rsi14"] != 100 {
			t.Fatalf("rsi14 = %v, want 100 on rising data", fr.Features["rsi14"])
		}
	}
	last := f[len(f)-1]
	if last.Target != 0 || last.TargetWin != -1 {
		t.Fatalf("last row: target=%v win=%v, want 0/-1 (no 5-day forward window)", last.Target, last.TargetWin)
	}
	// < 30 rows → nil.
	if fe.ComputeFeatures(genCandles(29, "T")) != nil {
		t.Fatal("ComputeFeatures(<30) should be nil")
	}
}

func TestLatestFeatures(t *testing.T) {
	fe := NewFeatureEngine()
	f, err := fe.LatestFeatures(genCandles(200, "TEST"))
	if err != nil {
		t.Fatalf("LatestFeatures: %v", err)
	}
	for _, k := range []string{"close", "rsi14", "sma20", "macd", "bb_upper", "atr14"} {
		if _, ok := f[k]; !ok {
			t.Fatalf("missing feature key %q", k)
		}
	}
	// < 30 rows → error.
	if _, err := fe.LatestFeatures(genCandles(29, "T")); err == nil {
		t.Fatal("LatestFeatures(<30) should error")
	}
	// >= 30 but < 121 rows: ComputeFeatures returns nothing → error.
	if _, err := fe.LatestFeatures(genCandles(100, "T")); err == nil {
		t.Fatal("LatestFeatures(100) should error (no computed rows)")
	}
}

// ---------- store ----------

func newTestStore(t *testing.T) *Store {
	t.Helper()
	s, err := NewStore(t.TempDir())
	if err != nil {
		t.Fatalf("NewStore: %v", err)
	}
	t.Cleanup(func() { s.Close() })
	return s
}

func TestStoreOHLCVRoundTrip(t *testing.T) {
	s := newTestStore(t)
	rows := genCandles(50, "AAPL")
	if err := s.SaveOHLCV(nil); err != nil {
		t.Fatalf("SaveOHLCV(nil): %v", err)
	}
	if err := s.SaveOHLCV(rows); err != nil {
		t.Fatalf("SaveOHLCV: %v", err)
	}

	from := rows[0].Date
	to := rows[len(rows)-1].Date
	got, err := s.GetOHLCV("AAPL", from, to)
	if err != nil {
		t.Fatalf("GetOHLCV: %v", err)
	}
	if len(got) != 50 {
		t.Fatalf("len = %d, want 50", len(got))
	}
	if got[0].Close != rows[0].Close || !got[0].Date.Equal(rows[0].Date) {
		t.Fatalf("row 0 mismatch: %+v", got[0])
	}
	// Range subset: only rows 10..19.
	sub, err := s.GetOHLCV("AAPL", rows[10].Date, rows[19].Date)
	if err != nil || len(sub) != 10 {
		t.Fatalf("subset: n=%d err=%v, want 10", len(sub), err)
	}
	// Unknown ticker → empty.
	none, err := s.GetOHLCV("NOPE", from, to)
	if err != nil || len(none) != 0 {
		t.Fatalf("unknown ticker: n=%d err=%v", len(none), err)
	}
	// Upsert: same rows with changed close → no duplicate, updated value.
	rows[0].Close = 999
	if err := s.SaveOHLCV(rows[:1]); err != nil {
		t.Fatalf("SaveOHLCV upsert: %v", err)
	}
	again, _ := s.GetOHLCV("AAPL", from, to)
	if len(again) != 50 || again[0].Close != 999 {
		t.Fatalf("upsert: n=%d close=%v, want 50/999", len(again), again[0].Close)
	}
}

func TestGetOHLCVRange(t *testing.T) {
	s := newTestStore(t)
	if err := s.SaveOHLCV(genCandles(40, "TSLA")); err != nil {
		t.Fatalf("SaveOHLCV: %v", err)
	}
	got, err := s.GetOHLCVRange("TSLA")
	if err != nil {
		t.Fatalf("GetOHLCVRange: %v", err)
	}
	if len(got) != 40 || got[0].Ticker != "TSLA" {
		t.Fatalf("range: n=%d ticker=%v", len(got), got[0].Ticker)
	}
}

func TestStoreFeaturesAndTraining(t *testing.T) {
	s := newTestStore(t)
	if err := s.SaveFeatures(nil); err != nil {
		t.Fatalf("SaveFeatures(nil): %v", err)
	}

	fe := NewFeatureEngine()
	f := fe.ComputeFeatures(genCandles(200, "T1"))
	if err := s.SaveFeatures(f); err != nil {
		t.Fatalf("SaveFeatures: %v", err)
	}

	// BuildTrainingData: T1 has 200 candles (enough), T2 only 10 (skipped).
	if err := s.SaveOHLCV(genCandles(200, "T1")); err != nil {
		t.Fatalf("SaveOHLCV: %v", err)
	}
	if err := s.SaveOHLCV(genCandles(10, "T2")); err != nil {
		t.Fatalf("SaveOHLCV: %v", err)
	}
	if err := s.BuildTrainingData([]string{"T1", "T2", "MISSING"}, fe); err != nil {
		t.Fatalf("BuildTrainingData: %v", err)
	}
	var count int
	if err := s.db.QueryRow("SELECT COUNT(*) FROM features WHERE ticker='T1'").Scan(&count); err != nil {
		t.Fatalf("count features: %v", err)
	}
	if count != 80 {
		t.Fatalf("features for T1 = %d, want 80", count)
	}
	var t2count int
	if err := s.db.QueryRow("SELECT COUNT(*) FROM features WHERE ticker='T2'").Scan(&t2count); err != nil {
		t.Fatalf("count T2: %v", err)
	}
	if t2count != 0 {
		t.Fatalf("T2 should have no features, got %d", t2count)
	}
}

func TestStoreSignalsAndTrades(t *testing.T) {
	s := newTestStore(t)
	now := time.Date(2026, 8, 1, 12, 0, 0, 0, time.UTC)

	sigID, err := s.RecordSignal(SignalRecord{
		Timestamp:  now,
		Ticker:     "AAPL",
		Model:      "m1",
		Signal:     "buy",
		Confidence: 0.9,
		Features:   map[string]float64{"rsi14": 71},
		Price:      100,
	})
	if err != nil || sigID <= 0 {
		t.Fatalf("RecordSignal: id=%d err=%v", sigID, err)
	}

	// Trade without status → defaults to 'open' in DB? No: RecordTrade inserts
	// the given status; pass "open" explicitly to exercise GetOpenTrades.
	tradeID, err := s.RecordTrade(TradeRecord{
		SignalID:   sigID,
		Ticker:     "AAPL",
		Side:       "buy",
		Quantity:   10,
		EntryPrice: 100,
		EntryTime:  now,
		Model:      "m1",
		Status:     "open",
	})
	if err != nil || tradeID <= 0 {
		t.Fatalf("RecordTrade: id=%d err=%v", tradeID, err)
	}

	open, err := s.GetOpenTrades()
	if err != nil || len(open) != 1 || open[0].ID != tradeID || open[0].Model != "m1" {
		t.Fatalf("GetOpenTrades: %+v err=%v", open, err)
	}

	exit := now.Add(24 * time.Hour)
	if err := s.UpdateTradeClose(tradeID, 110, exit, 100); err != nil {
		t.Fatalf("UpdateTradeClose: %v", err)
	}

	// Open trade is now closed → GetOpenTrades empty.
	open2, err := s.GetOpenTrades()
	if err != nil || len(open2) != 0 {
		t.Fatalf("GetOpenTrades after close: n=%d err=%v", len(open2), err)
	}

	// Unknown model → empty.
	none, err := s.GetTradesByModel("nope")
	if err != nil || len(none) != 0 {
		t.Fatalf("GetTradesByModel(nope): n=%d err=%v", len(none), err)
	}

	// Closed trade for m1 → returned with exit fields.
	byModel, err := s.GetTradesByModel("m1")
	if err != nil || len(byModel) != 1 {
		t.Fatalf("GetTradesByModel(m1): n=%d err=%v", len(byModel), err)
	}
	tr := byModel[0]
	if tr.Status != "closed" || tr.ExitPrice != 110 || tr.PnL != 100 || !tr.ExitTime.Equal(exit) {
		t.Fatalf("trade: %+v", tr)
	}
}

// ---------- fetcher ----------

const goodNewFormat = `{"chart":{"result":[{"meta":{"range":"1y"},
	"timestamp":[1000,2000,3000],
	"indicators":{"quote":[{"open":[100,0,101],
	"high":[101,2.1,0],
	"low":[99,1.9,0],
	"close":[100.5,2.0,101.5],
	"volume":[1000,20,0]}]}}]}}`

const legacyFormat = `{"chart":{"result":[{"meta":{"range":"1y"},
	"timestamp":[1000,2000,3000],
	"quote":[
	{"open":100,"high":101,"low":99,"close":100.5,"volume":10},
	{"open":101,"high":102,"low":100,"close":101.5,"volume":null},
	{"open":102,"high":103,"low":101,"close":null,"volume":5}]}]}}`

func TestFetchHistoryNewFormat(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.Contains(r.URL.Path, "AAPL") {
			w.WriteHeader(404)
			return
		}
		fmt.Fprint(w, goodNewFormat)
	}))
	defer srv.Close()

	f := NewHistoryFetcher()
	f.SetBaseURL(srv.URL)
	rows, err := f.FetchHistory("AAPL", "1y")
	if err != nil {
		t.Fatalf("FetchHistory: %v", err)
	}
	// Row 1 skipped (open=0); rows 0 and 2 kept.
	if len(rows) != 2 {
		t.Fatalf("len = %d, want 2", len(rows))
	}
	r0, r1 := rows[0], rows[1]
	if r0.Ticker != "AAPL" || r0.Open != 100 || r0.Close != 100.5 || r0.Volume != 1000 || r0.High != 101 {
		t.Fatalf("row0: %+v", r0)
	}
	// Row 2: high/low were 0 → replaced with close; volume 0.
	if r1.High != 101.5 || r1.Low != 101.5 || r1.Volume != 0 || r1.Close != 101.5 {
		t.Fatalf("row1: %+v", r1)
	}
	if !r0.Date.Equal(time.Unix(1000, 0).UTC()) || !r1.Date.Equal(time.Unix(3000, 0).UTC()) {
		t.Fatalf("dates: %v %v", r0.Date, r1.Date)
	}
}

func TestFetchHistoryLegacyFormat(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, legacyFormat)
	}))
	defer srv.Close()

	f := NewHistoryFetcher()
	f.SetBaseURL(srv.URL)
	rows, err := f.FetchHistory("MSFT", "2y")
	if err != nil {
		t.Fatalf("FetchHistory legacy: %v", err)
	}
	// Third row has null close → skipped.
	if len(rows) != 2 {
		t.Fatalf("len = %d, want 2", len(rows))
	}
	if rows[0].Open != 100 || rows[0].Volume != 10 {
		t.Fatalf("row0: %+v", rows[0])
	}
	if rows[1].Volume != 0 { // null volume → 0
		t.Fatalf("row1 volume = %v, want 0", rows[1].Volume)
	}
}

func TestFetchHistoryErrors(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.Contains(r.URL.Path, "BADJSON"):
			fmt.Fprint(w, "this is not json")
		case strings.Contains(r.URL.Path, "CHARTERR"):
			fmt.Fprint(w, `{"chart":{"error":{"code":"500"}}}`)
		case strings.Contains(r.URL.Path, "NORESULT"):
			fmt.Fprint(w, `{"chart":{"result":[]}}`)
		case strings.Contains(r.URL.Path, "MISMATCH"):
			fmt.Fprint(w, `{"chart":{"result":[{"timestamp":[1,2],"quote":[
				{"open":1,"high":2,"low":0.5,"close":1.5,"volume":1},
				{"open":1,"high":2,"low":0.5,"close":1.5,"volume":1},
				{"open":1,"high":2,"low":0.5,"close":1.5,"volume":1}]}]}}`)
		case strings.Contains(r.URL.Path, "NODATA"):
			fmt.Fprint(w, `{"chart":{"result":[{"timestamp":[1,2]}]}}`)
		default:
			w.WriteHeader(404)
		}
	}))
	defer srv.Close()

	f := NewHistoryFetcher()
	f.SetBaseURL(srv.URL)
	cases := []struct {
		ticker string
		err    string
	}{
		{"BADJSON", "decode"},
		{"CHARTERR", "no data"},
		{"NORESULT", "no data"},
		{"MISMATCH", "mismatched data lengths"},
		{"NODATA", "no data"},
		{"ERR404", "yahoo status 404"},
	}
	for _, c := range cases {
		if _, err := f.FetchHistory(c.ticker, "1y"); err == nil || !strings.Contains(err.Error(), c.err) {
			t.Errorf("FetchHistory(%s): err=%v, want containing %q", c.ticker, err, c.err)
		}
	}
}

// TestFetchHistoryCache self-checks the TTL cache: two consecutive
// FetchHistory calls in the same range must hit the network exactly once.
// If the cache regresses (e.g. TTL removed), calls hit the counter twice
// and this fails.
func TestFetchHistoryCache(t *testing.T) {
	calls := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		fmt.Fprint(w, goodNewFormat)
	}))
	defer srv.Close()

	f := NewHistoryFetcher()
	f.SetBaseURL(srv.URL)

	if _, err := f.FetchHistory("AAPL", "1y"); err != nil {
		t.Fatalf("first fetch: %v", err)
	}
	if _, err := f.FetchHistory("AAPL", "1y"); err != nil {
		t.Fatalf("second fetch: %v", err)
	}
	if calls != 1 {
		t.Fatalf("calls = %d, want 1 (2nd call should be served from cache)", calls)
	}

	// A different range must not be served from the same cache entry.
	if _, err := f.FetchHistory("AAPL", "2y"); err != nil {
		t.Fatalf("2y fetch: %v", err)
	}
	if calls != 2 {
		t.Fatalf("calls = %d, want 2 (2y is a distinct range key)", calls)
	}

	// TTL=0 disables the cache → every call hits the network.
	f.SetTTL(0)
	f.FetchHistory("MSFT", "1y")
	f.FetchHistory("MSFT", "1y")
	if calls != 4 {
		t.Fatalf("calls = %d, want 4 (TTL 0 disables cache)", calls)
	}
}

func TestFetchUniverse(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.Contains(r.URL.Path, "GOOD") {
			fmt.Fprint(w, goodNewFormat)
			return
		}
		w.WriteHeader(404)
	}))
	defer srv.Close()

	s := newTestStore(t)
	f := NewHistoryFetcher()
	f.SetBaseURL(srv.URL)
	if err := f.FetchUniverse([]string{"GOOD", "BAD"}, "1y", s); err != nil {
		t.Fatalf("FetchUniverse: %v", err)
	}
	got, err := s.GetOHLCV("GOOD", time.Time{}, time.Now().UTC())
	if err != nil || len(got) == 0 {
		t.Fatalf("GOOD candles: n=%d err=%v", len(got), err)
	}
	bad, err := s.GetOHLCV("BAD", time.Time{}, time.Now().UTC())
	if err != nil || len(bad) != 0 {
		t.Fatalf("BAD candles: n=%d err=%v, want 0", len(bad), err)
	}
}
