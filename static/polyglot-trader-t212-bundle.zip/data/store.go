package data

import (
	"database/sql"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"time"

	_ "modernc.org/sqlite"
)

// Store manages historical data and trade tracking via SQLite.
type Store struct {
	db *sql.DB
}

// OHLCV is a single candle.
type OHLCV struct {
	Ticker string    `json:"ticker"`
	Date   time.Time `json:"date"`
	Open   float64   `json:"open"`
	High   float64   `json:"high"`
	Low    float64   `json:"low"`
	Close  float64   `json:"close"`
	Volume float64   `json:"volume"`
}

// FeatureRow stores computed features for a ticker/date.
type FeatureRow struct {
	Ticker    string             `json:"ticker"`
	Date      time.Time          `json:"date"`
	Features  map[string]float64 `json:"features"`
	Target    float64            `json:"target"`     // Forward return (for training)
	TargetWin int                `json:"target_win"` // 1 if positive
}

// SignalRecord is a logged prediction.
type SignalRecord struct {
	ID         int64              `json:"id"`
	Timestamp  time.Time          `json:"timestamp"`
	Ticker     string             `json:"ticker"`
	Model      string             `json:"model"`
	Signal     string             `json:"signal"`
	Confidence float64            `json:"confidence"`
	Features   map[string]float64 `json:"features"`
	Price      float64            `json:"price"`
}

// TradeRecord is a paper trade with outcome tracking.
type TradeRecord struct {
	ID         int64     `json:"id"`
	SignalID   int64     `json:"signal_id"`
	Ticker     string    `json:"ticker"`
	Side       string    `json:"side"`
	Quantity   float64   `json:"quantity"`
	EntryPrice float64   `json:"entry_price"`
	ExitPrice  float64   `json:"exit_price"`
	EntryTime  time.Time `json:"entry_time"`
	ExitTime   time.Time `json:"exit_time"`
	PnL        float64   `json:"pnl"`
	Model      string    `json:"model"`
	Status     string    `json:"status"` // open, closed
}

// NewStore creates or opens the SQLite database.
func NewStore(dataDir string) (*Store, error) {
	os.MkdirAll(dataDir, 0755)
	dbPath := filepath.Join(dataDir, "trading.db")

	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, fmt.Errorf("open sqlite: %w", err)
	}

	// Enable WAL mode for concurrent reads
	db.Exec("PRAGMA journal_mode=WAL")
	db.Exec("PRAGMA synchronous=NORMAL")

	store := &Store{db: db}
	if err := store.migrate(); err != nil {
		db.Close()
		return nil, fmt.Errorf("migrate: %w", err)
	}

	slog.Info("data store initialized", "path", dbPath)
	return store, nil
}

// migrate creates tables if they don't exist.
func (s *Store) migrate() error {
	schema := `
	-- OHLCV historical data
	CREATE TABLE IF NOT EXISTS ohlcv (
		ticker TEXT NOT NULL,
		date DATETIME NOT NULL,
		open REAL NOT NULL,
		high REAL NOT NULL,
		low REAL NOT NULL,
		close REAL NOT NULL,
		volume REAL NOT NULL,
		PRIMARY KEY (ticker, date)
	);
	CREATE INDEX IF NOT EXISTS idx_ohlcv_ticker_date ON ohlcv (ticker, date DESC);
	
	-- Features
	CREATE TABLE IF NOT EXISTS features (
		ticker TEXT NOT NULL,
		date DATETIME NOT NULL,
		features JSON NOT NULL,
		target REAL DEFAULT 0,
		target_win INTEGER DEFAULT 0,
		PRIMARY KEY (ticker, date)
	);
	
	-- Signals
	CREATE TABLE IF NOT EXISTS signals (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		timestamp DATETIME NOT NULL,
		ticker TEXT NOT NULL,
		model TEXT NOT NULL,
		signal TEXT NOT NULL,
		confidence REAL NOT NULL,
		features JSON NOT NULL,
		price REAL NOT NULL
	);
	CREATE INDEX IF NOT EXISTS idx_signals_timestamp ON signals (timestamp DESC);
	CREATE INDEX IF NOT EXISTS idx_signals_model ON signals (model);
	
	-- Trades
	CREATE TABLE IF NOT EXISTS trades (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		signal_id INTEGER,
		ticker TEXT NOT NULL,
		side TEXT NOT NULL,
		quantity REAL NOT NULL,
		entry_price REAL NOT NULL,
		exit_price REAL,
		entry_time DATETIME NOT NULL,
		exit_time DATETIME,
		pnl REAL DEFAULT 0,
		model TEXT NOT NULL,
		status TEXT NOT NULL DEFAULT 'open'
	);
	CREATE INDEX IF NOT EXISTS idx_trades_status ON trades (status);
	CREATE INDEX IF NOT EXISTS idx_trades_model ON trades (model);
	`
	_, err := s.db.Exec(schema)
	return err
}

// SaveOHLCV stores historical candles (upsert).
func (s *Store) SaveOHLCV(rows []OHLCV) error {
	if len(rows) == 0 {
		return nil
	}

	tx, err := s.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	stmt, err := tx.Prepare(`
		INSERT INTO ohlcv (ticker, date, open, high, low, close, volume)
		VALUES (?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT (ticker, date) DO UPDATE SET
			open=excluded.open, high=excluded.high, low=excluded.low,
			close=excluded.close, volume=excluded.volume
	`)
	if err != nil {
		return err
	}
	defer stmt.Close()

	for _, r := range rows {
		_, err := stmt.Exec(r.Ticker, r.Date, r.Open, r.High, r.Low, r.Close, r.Volume)
		if err != nil {
			return err
		}
	}

	return tx.Commit()
}

// GetOHLCV retrieves candles for a ticker in date range.
func (s *Store) GetOHLCV(ticker string, from, to time.Time) ([]OHLCV, error) {
	rows, err := s.db.Query(`
		SELECT ticker, date, open, high, low, close, volume
		FROM ohlcv
		WHERE ticker = ? AND date >= ? AND date <= ?
		ORDER BY date ASC
	`, ticker, from, to)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []OHLCV
	for rows.Next() {
		var r OHLCV
		if err := rows.Scan(&r.Ticker, &r.Date, &r.Open, &r.High, &r.Low, &r.Close, &r.Volume); err != nil {
			return nil, err
		}
		result = append(result, r)
	}
	return result, nil
}

// SaveFeatures stores computed features.
func (s *Store) SaveFeatures(rows []FeatureRow) error {
	if len(rows) == 0 {
		return nil
	}

	tx, err := s.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	stmt, err := tx.Prepare(`
		INSERT INTO features (ticker, date, features, target, target_win)
		VALUES (?, ?, ?, ?, ?)
		ON CONFLICT (ticker, date) DO UPDATE SET
			features=excluded.features, target=excluded.target, target_win=excluded.target_win
	`)
	if err != nil {
		return err
	}
	defer stmt.Close()

	for _, r := range rows {
		_, err := stmt.Exec(r.Ticker, r.Date, featuresToJSON(r.Features), r.Target, r.TargetWin)
		if err != nil {
			return err
		}
	}

	return tx.Commit()
}

// RecordSignal logs a prediction.
func (s *Store) RecordSignal(sig SignalRecord) (int64, error) {
	result, err := s.db.Exec(`
		INSERT INTO signals (timestamp, ticker, model, signal, confidence, features, price)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`, sig.Timestamp, sig.Ticker, sig.Model, sig.Signal, sig.Confidence, featuresToJSON(sig.Features), sig.Price)
	if err != nil {
		return 0, err
	}

	return result.LastInsertId()
}

// RecordTrade logs a paper trade.
func (s *Store) RecordTrade(trade TradeRecord) (int64, error) {
	result, err := s.db.Exec(`
		INSERT INTO trades (signal_id, ticker, side, quantity, entry_price, entry_time, model, status)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)
	`, trade.SignalID, trade.Ticker, trade.Side, trade.Quantity, trade.EntryPrice, trade.EntryTime, trade.Model, trade.Status)
	if err != nil {
		return 0, err
	}

	return result.LastInsertId()
}

// UpdateTradeClose records trade exit.
func (s *Store) UpdateTradeClose(tradeID int64, exitPrice float64, exitTime time.Time, pnl float64) error {
	_, err := s.db.Exec(`
		UPDATE trades
		SET exit_price = ?, exit_time = ?, pnl = ?, status = 'closed'
		WHERE id = ?
	`, exitPrice, exitTime, pnl, tradeID)
	return err
}

// GetOpenTrades retrieves all open trades.
func (s *Store) GetOpenTrades() ([]TradeRecord, error) {
	rows, err := s.db.Query(`
		SELECT id, signal_id, ticker, side, quantity, entry_price, entry_time, model
		FROM trades
		WHERE status = 'open'
		ORDER BY entry_time ASC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var trades []TradeRecord
	for rows.Next() {
		var t TradeRecord
		if err := rows.Scan(&t.ID, &t.SignalID, &t.Ticker, &t.Side, &t.Quantity, &t.EntryPrice, &t.EntryTime, &t.Model); err != nil {
			return nil, err
		}
		trades = append(trades, t)
	}
	return trades, nil
}

// GetTradesByModel retrieves trades for a specific model.
func (s *Store) GetTradesByModel(model string) ([]TradeRecord, error) {
	rows, err := s.db.Query(`
		SELECT id, signal_id, ticker, side, quantity, entry_price, exit_price, entry_time, exit_time, pnl, model, status
		FROM trades
		WHERE model = ? AND status = 'closed'
		ORDER BY exit_time DESC
		LIMIT 100
	`, model)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var trades []TradeRecord
	for rows.Next() {
		var t TradeRecord
		var exitTime *time.Time
		var exitPrice *float64

		if err := rows.Scan(&t.ID, &t.SignalID, &t.Ticker, &t.Side, &t.Quantity, &t.EntryPrice, &exitPrice, &t.EntryTime, &exitTime, &t.PnL, &t.Model, &t.Status); err != nil {
			return nil, err
		}
		if exitPrice != nil {
			t.ExitPrice = *exitPrice
		}
		if exitTime != nil {
			t.ExitTime = *exitTime
		}
		trades = append(trades, t)
	}
	return trades, nil
}

// Close closes the database.
func (s *Store) Close() error {
	return s.db.Close()
}
