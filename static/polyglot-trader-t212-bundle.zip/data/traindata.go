package data

import (
	"log/slog"
)

// BuildTrainingData reads stored OHLCV for each ticker, computes features
// with targets, and writes them to the features table. Call after fetch.
func (s *Store) BuildTrainingData(tickers []string, fe *FeatureEngine) error {
	total := 0
	for _, ticker := range tickers {
		// Fetch all stored candles for this ticker
		rows, err := s.GetOHLCVRange(ticker)
		if err != nil {
			slog.Warn("get ohlcv failed", "ticker", ticker, "error", err)
			continue
		}
		if len(rows) < 30 {
			slog.Warn("insufficient candles, skipping", "ticker", ticker, "n", len(rows))
			continue
		}

		features := fe.ComputeFeatures(rows)
		if len(features) == 0 {
			continue
		}

		if err := s.SaveFeatures(features); err != nil {
			slog.Error("save features failed", "ticker", ticker, "error", err)
			continue
		}

		total += len(features)
		slog.Info("training features built", "ticker", ticker, "rows", len(features))
	}

	slog.Info("training data complete", "tickers", len(tickers), "features", total)
	return nil
}

// GetOHLCVRange fetches all candles for a ticker (full history).
func (s *Store) GetOHLCVRange(ticker string) ([]OHLCV, error) {
	rows, err := s.db.Query(`
		SELECT ticker, date, open, high, low, close, volume
		FROM ohlcv
		WHERE ticker = ?
		ORDER BY date ASC
	`, ticker)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []OHLCV
	for rows.Next() {
		var r OHLCV
		if err := rows.Scan(&r.Ticker, &r.Date, &r.Open, &r.High, &r.Low, &r.Close, &r.Volume); err != nil {
			return nil, err
		}
		result = append(result, r)
	}
	return result, nil
}
