package data

import (
	"log/slog"
	"time"
)

// FeatureEngine computes technical features from OHLCV data.
type FeatureEngine struct {
	lookback int
}

// NewFeatureEngine creates an engine with standard lookback period.
func NewFeatureEngine() *FeatureEngine {
	return &FeatureEngine{lookback: 120}
}

// ComputeFeatures calculates the full feature set for a ticker's candle series.
// Returns one FeatureRow per candle that has enough history (last `lookback` rows).
func (fe *FeatureEngine) ComputeFeatures(rows []OHLCV) []FeatureRow {
	if len(rows) < 30 {
		return nil
	}

	n := len(rows)
	closes := make([]float64, n)
	opens := make([]float64, n)
	highs := make([]float64, n)
	lows := make([]float64, n)
	vols := make([]float64, n)

	for i, r := range rows {
		closes[i] = r.Close
		opens[i] = r.Open
		highs[i] = r.High
		lows[i] = r.Low
		vols[i] = r.Volume
	}

	// Precompute indicators (each length n, first elements zero-filled).
	sma20 := SMA(closes, 20)
	sma50 := SMA(closes, 50)
	sma200 := SMA(closes, 200)
	ema12 := EMA(closes, 12)
	ema26 := EMA(closes, 26)
	rsi14 := RSI(closes, 14)
	macdLine, macdSignal := MACD(closes)
	upperBB, lowerBB := BollingerBands(closes, 20, 2.0)
	atr14 := ATR(highs, lows, closes, 14)

	var features []FeatureRow
	for i := fe.lookback; i < n; i++ {
		f := map[string]float64{
			// Price action
			"close":  closes[i],
			"open":   opens[i],
			"high":   highs[i],
			"low":    lows[i],
			"volume": vols[i],

			// Momentum
			"return_1d":  pctChange(closes[i], closes[i-1]),
			"return_5d":  pctChange(closes[i], closes[i-5]),
			"return_20d": pctChange(closes[i], closes[i-20]),
			"return_60d": pctChange(closes[i], closes[i-60]),

			// Trend
			"sma20":           sma20[i],
			"sma50":           sma50[i],
			"sma200":          sma200[i],
			"close_vs_sma20":  ratio(closes[i], sma20[i]),
			"close_vs_sma50":  ratio(closes[i], sma50[i]),
			"close_vs_sma200": ratio(closes[i], sma200[i]),
			"ema12":           ema12[i],
			"ema26":           ema26[i],

			// Oscillators
			"rsi14":       rsi14[i],
			"macd":        macdLine[i],
			"macd_signal": macdSignal[i],
			"macd_hist":   macdLine[i] - macdSignal[i],

			// Volatility
			"bb_upper":      upperBB[i],
			"bb_lower":      lowerBB[i],
			"bb_position":   bbPosition(closes[i], upperBB[i], lowerBB[i]),
			"atr14":         atr14[i],
			"atr_ratio":     ratio(atr14[i], closes[i]),
			"volatility_20": stdev(closes, i-20, i+1),

			// Volume
			"vol_ratio_20":  volumeRatio(vols, i, 20),
			"vol_change_5d": pctChange(vols[i], vols[i-5]),

			// Range
			"hl_range":        ratio(highs[i]-lows[i], closes[i]),
			"close_pos_range": closePosition(closes[i], highs[i], lows[i]),
		}

		// Target: 5-day forward return with a ±0.5% deadband. 1=up (>+0.5%),
		// 0=down (<-0.5%), -1=no-trade (|ret|<=0.5%, dropped at train time).
		// The old 1-day next-day direction was ~50/50 noise; a 5-day return is
		// persistent and the deadband removes the coin-flip middle, so the model
		// predicts "a real 5-day move" instead of "did it tick up a penny".
		var target float64
		targetWin := -1
		if i+5 < n {
			target = pctChange(closes[i+5], closes[i])
			if target > 0.005 {
				targetWin = 1
			} else if target < -0.005 {
				targetWin = 0
			}
		}

		features = append(features, FeatureRow{
			Ticker:    rows[i].Ticker,
			Date:      rows[i].Date,
			Features:  f,
			Target:    target,
			TargetWin: targetWin,
		})
	}

	slog.Info("features computed", "rows", len(rows), "features", len(features))
	return features
}

// LatestFeatures computes features only for the last candle (for live inference).
func (fe *FeatureEngine) LatestFeatures(rows []OHLCV) (map[string]float64, error) {
	if len(rows) < 30 {
		return nil, errInsufficientData
	}

	all := fe.ComputeFeatures(rows)
	if len(all) == 0 {
		return nil, errInsufficientData
	}
	return all[len(all)-1].Features, nil
}

// ---------- Technical indicator implementations (pure Go, no deps) ----------

func SMA(values []float64, period int) []float64 {
	n := len(values)
	out := make([]float64, n)
	if n < period {
		return out
	}
	sum := 0.0
	for i := 0; i < n; i++ {
		sum += values[i]
		if i >= period {
			sum -= values[i-period]
		}
		if i >= period-1 {
			out[i] = sum / float64(period)
		}
	}
	return out
}

func EMA(values []float64, period int) []float64 {
	n := len(values)
	out := make([]float64, n)
	if n == 0 {
		return out
	}
	k := 2.0 / float64(period+1)
	out[0] = values[0]
	for i := 1; i < n; i++ {
		out[i] = values[i]*k + out[i-1]*(1-k)
	}
	return out
}

func RSI(closes []float64, period int) []float64 {
	n := len(closes)
	out := make([]float64, n)
	if n < period+1 {
		return out
	}

	gains := 0.0
	losses := 0.0
	for i := 1; i <= period; i++ {
		diff := closes[i] - closes[i-1]
		if diff > 0 {
			gains += diff
		} else {
			losses -= diff
		}
	}
	avgGain := gains / float64(period)
	avgLoss := losses / float64(period)

	if avgLoss == 0 {
		out[period] = 100.0
	} else {
		rs := avgGain / avgLoss
		out[period] = 100.0 - (100.0 / (1.0 + rs))
	}

	for i := period + 1; i < n; i++ {
		diff := closes[i] - closes[i-1]
		var gain, loss float64
		if diff > 0 {
			gain = diff
		} else {
			loss = -diff
		}
		avgGain = (avgGain*float64(period-1) + gain) / float64(period)
		avgLoss = (avgLoss*float64(period-1) + loss) / float64(period)
		if avgLoss == 0 {
			out[i] = 100.0
		} else {
			rs := avgGain / avgLoss
			out[i] = 100.0 - (100.0 / (1.0 + rs))
		}
	}
	return out
}

func MACD(closes []float64) (macd, signal []float64) {
	ema12 := EMA(closes, 12)
	ema26 := EMA(closes, 26)
	macd = make([]float64, len(closes))
	for i := range closes {
		macd[i] = ema12[i] - ema26[i]
	}
	signal = EMA(macd, 9)
	return
}

func BollingerBands(closes []float64, period int, mult float64) (upper, lower []float64) {
	n := len(closes)
	sma := SMA(closes, period)
	upper = make([]float64, n)
	lower = make([]float64, n)
	for i := period - 1; i < n; i++ {
		sd := stdev(closes, i-period+1, i+1)
		upper[i] = sma[i] + mult*sd
		lower[i] = sma[i] - mult*sd
	}
	return
}

func ATR(highs, lows, closes []float64, period int) []float64 {
	n := len(closes)
	out := make([]float64, n)
	if n < period+1 {
		return out
	}
	trueRanges := make([]float64, n)
	trueRanges[0] = highs[0] - lows[0]
	for i := 1; i < n; i++ {
		tr := highs[i] - lows[i]
		prevClose := closes[i-1]
		if d := highs[i] - prevClose; d > tr {
			tr = d
		}
		if d := prevClose - lows[i]; d > tr {
			tr = d
		}
		trueRanges[i] = tr
	}

	sum := 0.0
	for i := 1; i <= period; i++ {
		sum += trueRanges[i]
	}
	out[period] = sum / float64(period)
	for i := period + 1; i < n; i++ {
		out[i] = (out[i-1]*float64(period-1) + trueRanges[i]) / float64(period)
	}
	return out
}

func stdev(values []float64, start, end int) float64 {
	if end <= start || start < 0 || end > len(values) {
		return 0
	}
	mean := 0.0
	count := 0
	for i := start; i < end; i++ {
		mean += values[i]
		count++
	}
	if count == 0 {
		return 0
	}
	mean /= float64(count)
	sumSq := 0.0
	for i := start; i < end; i++ {
		d := values[i] - mean
		sumSq += d * d
	}
	return (sumSq / float64(count))
}

func pctChange(cur, prev float64) float64 {
	if prev == 0 {
		return 0
	}
	return (cur - prev) / prev
}

func ratio(a, b float64) float64 {
	if b == 0 {
		return 0
	}
	return a / b
}

func bbPosition(price, upper, lower float64) float64 {
	if upper == lower {
		return 0.5
	}
	return (price - lower) / (upper - lower)
}

func volumeRatio(vols []float64, i, period int) float64 {
	if i < period || vols[i] == 0 {
		return 1.0
	}
	sum := 0.0
	for j := i - period; j < i; j++ {
		sum += vols[j]
	}
	avg := sum / float64(period)
	if avg == 0 {
		return 1.0
	}
	return vols[i] / avg
}

func closePosition(close, high, low float64) float64 {
	if high == low {
		return 0.5
	}
	return (close - low) / (high - low)
}

var errInsufficientData = &DataError{msg: "insufficient data for feature computation"}

// DataError is returned when data is insufficient.
type DataError struct {
	msg string
}

func (e *DataError) Error() string { return e.msg }

// Ensure time is used.
var _ = time.Now
