package data

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"sync"
	"time"
)

// HistoryFetcher downloads OHLCV data from Yahoo Finance.
//
// ponytail: a per-ticker TTL cache. The 60s fast loop refetched a full 1y
// chart for every ticker every minute (~13k Yahoo calls/day — 429 bait);
// daily bars don't move intraday, so a 5-minute cache is lossless for the
// decision loop and cuts the hot-path calls to ~1/min. The 1h slow loop's
// 2y retrain fetches are unaffected (different range key).
type HistoryFetcher struct {
	client  *http.Client
	baseURL string
	ttl     time.Duration
	mu      sync.Mutex
	cache   map[string]cacheEntry
}

type cacheEntry struct {
	bars []OHLCV
	at   time.Time
}

// NewHistoryFetcher creates a new fetcher with the default 5m cache TTL.
func NewHistoryFetcher() *HistoryFetcher {
	return &HistoryFetcher{
		client:  &http.Client{Timeout: 30 * time.Second},
		baseURL: "https://query1.finance.yahoo.com",
		ttl:     5 * time.Minute,
		cache:   map[string]cacheEntry{},
	}
}

// SetBaseURL overrides the Yahoo Finance base URL (used in tests).
func (f *HistoryFetcher) SetBaseURL(url string) {
	f.baseURL = url
}

// SetTTL overrides the history cache TTL (0 = cache disabled, tests).
func (f *HistoryFetcher) SetTTL(d time.Duration) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.ttl = d
}

// validBar is the central OHLC sanity check (Vibe-Trading loader-guard lesson):
// bars with non-positive prices or high < low corrupt every downstream return
// and indicator, so they are dropped at the data boundary.
// ponytail: minimal guard (positive + high>=low); full bracketing check if
// providers ever emit structurally broken bars again.
func validBar(open, high, low, close float64) bool {
	return open > 0 && high > 0 && low > 0 && close > 0 && high >= low
}

// FetchHistory downloads OHLCV data for a ticker, served from a per-ticker
// TTL cache when fresh (see HistoryFetcher — the 60s loop's 1y fetches are
// the dominant Yahoo traffic source).
// rangeStr is in format "1y", "2y", "5y" (years).
func (f *HistoryFetcher) FetchHistory(ticker string, rangeStr string) ([]OHLCV, error) {
	f.mu.Lock()
	ttl := f.ttl
	if ttl > 0 {
		if e, ok := f.cache[ticker+"|"+rangeStr]; ok && time.Since(e.at) < ttl {
			f.mu.Unlock()
			return e.bars, nil
		}
	}
	f.mu.Unlock()

	bars, err := f.fetchYahoo(ticker, rangeStr)
	if err != nil {
		return nil, err
	}
	if ttl > 0 {
		f.mu.Lock()
		f.cache[ticker+"|"+rangeStr] = cacheEntry{bars: bars, at: time.Now()}
		f.mu.Unlock()
	}
	return bars, nil
}

// fetchYahoo performs the raw network fetch + parse (no caching).
func (f *HistoryFetcher) fetchYahoo(ticker string, rangeStr string) ([]OHLCV, error) {
	url := fmt.Sprintf("%s/v8/finance/chart/%s?interval=1d&range=%s", f.baseURL, ticker, rangeStr)

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; polyglot-trader/1.0)")

	resp, err := f.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("yahoo fetch: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("yahoo status %d", resp.StatusCode)
	}

	var data struct {
		Chart struct {
			Result []struct {
				Meta struct {
					Range string `json:"range"`
				} `json:"meta"`
				Timestamp []int64 `json:"timestamp"`
				// New Yahoo format: indicators.quote[0] with parallel arrays.
				Indicators struct {
					Quote []struct {
						Open   []float64 `json:"open"`
						High   []float64 `json:"high"`
						Low    []float64 `json:"low"`
						Close  []float64 `json:"close"`
						Volume []float64 `json:"volume"`
					} `json:"quote"`
				} `json:"indicators"`
				// Legacy format (kept for compat if Yahoo reverts).
				Quote []struct {
					Open   *float64 `json:"open"`
					High   *float64 `json:"high"`
					Low    *float64 `json:"low"`
					Close  *float64 `json:"close"`
					Volume *float64 `json:"volume"`
				} `json:"quote"`
			} `json:"result"`
			Error *struct {
				Code string `json:"code"`
			} `json:"error"`
		} `json:"chart"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, fmt.Errorf("yahoo decode: %w", err)
	}

	if data.Chart.Error != nil || len(data.Chart.Result) == 0 {
		return nil, fmt.Errorf("yahoo: no data for %s", ticker)
	}

	result := data.Chart.Result[0]

	var ohlcv []OHLCV

	if len(result.Indicators.Quote) > 0 {
		// New format: parallel arrays under indicators.quote[0].
		// Yahoo encodes missing values as null → Go decodes as 0.
		q := result.Indicators.Quote[0]
		n := len(result.Timestamp)
		for i := 0; i < n; i++ {
			if i >= len(q.Open) || i >= len(q.High) || i >= len(q.Low) || i >= len(q.Close) {
				break
			}
			if q.Open[i] <= 0 || q.Close[i] <= 0 {
				continue
			}
			high := q.High[i]
			low := q.Low[i]
			vol := 0.0
			if i < len(q.Volume) && q.Volume[i] > 0 {
				vol = q.Volume[i]
			}
			if high <= 0 {
				high = q.Close[i]
			}
			if low <= 0 {
				low = q.Close[i]
			}
			if !validBar(q.Open[i], high, low, q.Close[i]) {
				continue
			}
			ohlcv = append(ohlcv, OHLCV{
				Ticker: ticker,
				Date:   time.Unix(result.Timestamp[i], 0).UTC(),
				Open:   q.Open[i],
				High:   high,
				Low:    low,
				Close:  q.Close[i],
				Volume: vol,
			})
		}
	} else if len(result.Quote) > 0 {
		// Legacy format: quote as array of objects.
		if len(result.Timestamp) != len(result.Quote) {
			return nil, fmt.Errorf("yahoo: mismatched data lengths")
		}
		for i, ts := range result.Timestamp {
			q := result.Quote[i]
			if q.Open == nil || q.High == nil || q.Low == nil || q.Close == nil {
				continue
			}
			if !validBar(*q.Open, *q.High, *q.Low, *q.Close) {
				continue
			}
			volume := 0.0
			if q.Volume != nil {
				volume = *q.Volume
			}
			ohlcv = append(ohlcv, OHLCV{
				Ticker: ticker,
				Date:   time.Unix(ts, 0).UTC(),
				Open:   *q.Open,
				High:   *q.High,
				Low:    *q.Low,
				Close:  *q.Close,
				Volume: volume,
			})
		}
	} else {
		return nil, fmt.Errorf("yahoo: no data for %s", ticker)
	}

	slog.Info("fetched history", "ticker", ticker, "range", rangeStr, "candles", len(ohlcv))
	return ohlcv, nil
}

// FetchUniverse fetches history for multiple tickers.
func (f *HistoryFetcher) FetchUniverse(tickers []string, rangeStr string, store *Store) error {
	total := 0
	for _, ticker := range tickers {
		ohlcv, err := f.FetchHistory(ticker, rangeStr)
		if err != nil {
			slog.Warn("fetch failed", "ticker", ticker, "error", err)
			continue
		}

		if err := store.SaveOHLCV(ohlcv); err != nil {
			slog.Error("save failed", "ticker", ticker, "error", err)
			continue
		}

		total += len(ohlcv)
	}

	slog.Info("universe fetch complete", "tickers", len(tickers), "candles", total)
	return nil
}
