package risk

import (
	"math"
)

// QuarterKellySizer calculates Kelly-optimal position sizing with quarter-Kelly
// safety margin to reduce variance from probability estimation error.
//
// Formula: f = 0.25 × (p·W − (1−p)) / W
// where p = win probability, W = win/loss payout ratio.
// The old ((2p−1)/W) form is only correct at W=1; with a non-symmetric
// stop (e.g. −6%/+9% → W=1.5) it under-sizes by ~3.6× at p=0.53.
type QuarterKellySizer struct {
	maxPositionPct      float64 // e.g. 0.10 → 10% of equity
	maxTotalExposurePct float64 // e.g. 0.80 → 80% of equity
	minTradeSize        float64 // minimum notional value in account currency
}

// NewQuarterKellySizer creates a Kelly position sizer.
func NewQuarterKellySizer(maxPositionPct, maxTotalExposurePct, minTradeSize float64) *QuarterKellySizer {
	return &QuarterKellySizer{
		maxPositionPct:      maxPositionPct,
		maxTotalExposurePct: maxTotalExposurePct,
		minTradeSize:        minTradeSize,
	}
}

// Size computes the Kelly fraction for a ticker.
// Returns 0.0 if the Kelly criterion is negative or sub-threshold.
func (s *QuarterKellySizer) Size(ticker string, probability, winLossRatio, currentExposure float64) float64 {
	// Clamp probability to [0, 1]
	p := math.Max(0.0, math.Min(1.0, probability))
	w := math.Max(0.1, winLossRatio)

	// Full Kelly: f = (p·W − (1−p)) / W
	fFull := (p*w - (1.0 - p)) / w

	// Quarter-Kelly
	fKelly := 0.25 * fFull

	// Negative or zero → no position warranted
	if fKelly <= 0.0 {
		return 0.0
	}

	// Clamp to max position size
	maxFrac := s.maxPositionPct / 100.0
	fKelly = math.Min(fKelly, maxFrac)

	// Clamp to remaining exposure capacity
	remaining := s.maxTotalExposurePct/100.0 - currentExposure
	if remaining <= 0 {
		return 0.0
	}
	fKelly = math.Min(fKelly, remaining)

	return fKelly
}

// ComputeNotional converts a Kelly fraction to a dollar notional.
// Returns 0.0 if below minimum trade size.
func (s *QuarterKellySizer) ComputeNotional(equity, fKelly float64) float64 {
	notional := equity * fKelly
	if notional < s.minTradeSize {
		return 0.0
	}
	return notional
}

// SizeFromLightGBM extracts win probability from a LightGBM output map
// and computes the Kelly position size.
func (s *QuarterKellySizer) SizeFromLightGBM(ticker string, lightgbmOutput map[string]float64, winLossRatio, currentExposure float64) float64 {
	probability := lightgbmOutput["probability"]
	return s.Size(ticker, probability, winLossRatio, currentExposure)
}

// SetMinTradeSize updates the notional floor at runtime.
// ponytail: bare write, safe — single-writer (config endpoint), float64 writes
// are atomic on amd64/arm64. Add a mutex only if contention shows up.
func (s *QuarterKellySizer) SetMinTradeSize(v float64) {
	s.minTradeSize = v
}

// MinTradeSize returns the current notional floor.
func (s *QuarterKellySizer) MinTradeSize() float64 {
	return s.minTradeSize
}

// SensitivityTable returns Kelly fraction for every 5% probability increment,
// useful for debugging model sensitivity.
func (s *QuarterKellySizer) SensitivityTable(winLossRatio float64) []SensitivityRow {
	rows := make([]SensitivityRow, 0, 21)
	for p := 0; p <= 100; p += 5 {
		rows = append(rows, SensitivityRow{
			Probability: float64(p) / 100.0,
			Size:        s.Size("", float64(p)/100.0, winLossRatio, 0),
		})
	}
	return rows
}

// SensitivityRow is one row of a Kelly sensitivity table.
type SensitivityRow struct {
	Probability float64
	Size        float64
}
