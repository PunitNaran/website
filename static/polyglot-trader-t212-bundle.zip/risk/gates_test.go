package risk

import (
	"fmt"
	"testing"
	"time"
)

func TestMacroRegimeGate_BuyInBullish(t *testing.T) {
	g := &MacroRegimeGate{SpyPrice: 450, SpyEMA: 448}
	res := g.Evaluate(Buy)
	if !res.Passed {
		t.Errorf("expected buy pass in bullish regime, got: %s", res.Reason)
	}
}

func TestMacroRegimeGate_BuyInBearish(t *testing.T) {
	g := &MacroRegimeGate{SpyPrice: 440, SpyEMA: 448}
	res := g.Evaluate(Buy)
	if res.Passed {
		t.Error("expected buy block in bearish regime")
	}
	if res.Name != "MacroRegime" {
		t.Errorf("expected gate name MacroRegime, got %s", res.Name)
	}
}

func TestMacroRegimeGate_SellAlwaysPass(t *testing.T) {
	g := &MacroRegimeGate{SpyPrice: 440, SpyEMA: 448}
	res := g.Evaluate(Sell)
	if !res.Passed {
		t.Error("expected sell to always pass macro gate")
	}
}

func TestMacroRegimeGate_ZeroPrices(t *testing.T) {
	g := &MacroRegimeGate{SpyPrice: 0, SpyEMA: 0}
	res := g.Evaluate(Buy)
	if !res.Passed {
		t.Error("expected pass when prices are zero")
	}
}

func TestMarginFloorGate_AboveFloor(t *testing.T) {
	g := &MarginFloorGate{FreeMargin: 5000, TotalEquity: 10000, MinFloorPct: 0.15}
	res := g.Evaluate()
	if !res.Passed {
		t.Errorf("expected pass, got: %s", res.Reason)
	}
}

func TestMarginFloorGate_AtFloor(t *testing.T) {
	g := &MarginFloorGate{FreeMargin: 1500, TotalEquity: 10000, MinFloorPct: 0.15}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail at floor")
	}
}

func TestMarginFloorGate_BelowFloor(t *testing.T) {
	g := &MarginFloorGate{FreeMargin: 1000, TotalEquity: 10000, MinFloorPct: 0.15}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail below floor")
	}
}

func TestMarginFloorGate_ZeroEquity(t *testing.T) {
	g := &MarginFloorGate{FreeMargin: 0, TotalEquity: 0}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail with zero equity")
	}
}

func TestMaxDrawdownGate_WithinLimit(t *testing.T) {
	g := &MaxDrawdownGate{DailyPnL: -500, MaxLossPct: 0.05, TotalEquity: 10000}
	res := g.Evaluate()
	if !res.Passed {
		t.Errorf("expected pass, got: %s", res.Reason)
	}
}

func TestMaxDrawdownGate_ExceedsLimit(t *testing.T) {
	g := &MaxDrawdownGate{DailyPnL: -1000, MaxLossPct: 0.05, TotalEquity: 10000}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail when drawdown exceeds limit")
	}
}

func TestMaxDrawdownGate_PositivePnL(t *testing.T) {
	g := &MaxDrawdownGate{DailyPnL: 500, MaxLossPct: 0.05, TotalEquity: 10000}
	res := g.Evaluate()
	if !res.Passed {
		t.Error("expected pass with positive P&L")
	}
}

func TestAssetCorrelationGate_BelowLimit(t *testing.T) {
	g := &AssetCorrelationGate{SectorExposurePct: 30, MaxSectorPct: 40, Sector: "TECH"}
	res := g.Evaluate()
	if !res.Passed {
		t.Errorf("expected pass, got: %s", res.Reason)
	}
}

func TestAssetCorrelationGate_AtLimit(t *testing.T) {
	g := &AssetCorrelationGate{SectorExposurePct: 40, MaxSectorPct: 40, Sector: "TECH"}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail at sector limit")
	}
}

func TestAssetCorrelationGate_ExceedsLimit(t *testing.T) {
	g := &AssetCorrelationGate{SectorExposurePct: 50, MaxSectorPct: 40, Sector: "FINANCE"}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail above sector limit")
	}
}

func TestAssetCorrelationGate_EmptySector(t *testing.T) {
	g := &AssetCorrelationGate{SectorExposurePct: 50, MaxSectorPct: 40}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail even with empty sector")
	}
	if res.Reason == "" {
		t.Error("expected reason in result")
	}
}

func TestWashTimeoutGate_NoPriorTrade(t *testing.T) {
	g := &WashTimeoutGate{LastTradeTime: nil, MinCooldown: 15 * time.Minute, Ticker: "AAPL"}
	res := g.Evaluate()
	if !res.Passed {
		t.Error("expected pass with no prior trade")
	}
}

func TestWashTimeoutGate_CooldownNotMet(t *testing.T) {
	past := time.Now().Add(-5 * time.Minute)
	g := &WashTimeoutGate{LastTradeTime: &past, MinCooldown: 15 * time.Minute, Ticker: "AAPL"}
	res := g.Evaluate()
	if res.Passed {
		t.Error("expected fail when cooldown not met")
	}
}

func TestWashTimeoutGate_CooldownMet(t *testing.T) {
	past := time.Now().Add(-20 * time.Minute)
	g := &WashTimeoutGate{LastTradeTime: &past, MinCooldown: 15 * time.Minute, Ticker: "AAPL"}
	res := g.Evaluate()
	if !res.Passed {
		t.Errorf("expected pass, got: %s", res.Reason)
	}
}

func TestNewRiskGates_Empty(t *testing.T) {
	rg := NewRiskGates()
	if rg == nil {
		t.Fatal("expected non-nil RiskGates")
	}
}

func TestRiskGates_Evaluate_AllGatesConfigured(t *testing.T) {
	r := NewRiskGates()
	order := &Order{
		Scheme:              "ISA",
		Ticker:              "AAPL",
		Side:                Buy,
		Quantity:            10,
		LimitPrice:          150,
		MarketPrice:         150,
		PositionValue:       100, // within all static gate limits (2% of 10000=200)
		TotalPortfolioValue: 10000,
		Sector:              "TECH",
	}

	result := r.Evaluate(order)
	if !result.Passed {
		t.Errorf("expected pass with nil gates, got: %s", result.FailReason)
	}
	// Should return all 11 results (5 dynamic bypassed + 6 static passing, incl model quality)
	if len(result.Gates) != 11 {
		t.Errorf("expected 11 gate results, got %d", len(result.Gates))
	}
}

func TestRiskGates_MacroRegimeFail(t *testing.T) {
	r := NewRiskGates()
	r.MacroRegime = &MacroRegimeGate{SpyPrice: 440, SpyEMA: 448}

	order := &Order{
		Scheme:              "ISA",
		Ticker:              "AAPL",
		Side:                Buy,
		Quantity:            10,
		LimitPrice:          150,
		MarketPrice:         150,
		PositionValue:       100, // small enough to pass static gates
		TotalPortfolioValue: 10000,
		Sector:              "TECH",
	}

	result := r.Evaluate(order)
	if result.Passed {
		t.Error("expected failure due to macro regime gate")
	}
	if result.FailedGate != "MacroRegime" {
		t.Errorf("expected first fail at MacroRegime, got %s", result.FailedGate)
	}
}

func TestRiskGates_MarginFloorFail(t *testing.T) {
	r := NewRiskGates()
	r.MacroRegime = &MacroRegimeGate{SpyPrice: 450, SpyEMA: 448} // buy allowed
	r.MarginFloor = &MarginFloorGate{FreeMargin: 100, TotalEquity: 10000}

	order := &Order{
		Scheme:              "ISA",
		Ticker:              "AAPL",
		Side:                Buy,
		Quantity:            10,
		LimitPrice:          150,
		MarketPrice:         150,
		PositionValue:       100, // small enough to pass static gates
		TotalPortfolioValue: 10000,
		Sector:              "TECH",
	}

	result := r.Evaluate(order)
	if result.Passed {
		t.Error("expected failure due to margin floor gate")
	}
	if result.FailedGate != "MarginFloor" {
		t.Errorf("expected first fail at MarginFloor, got %s", result.FailedGate)
	}
}

func TestRiskGates_StaticMaxRiskFail(t *testing.T) {
	rg := NewRiskGates()
	// All dynamic gates nil
	// Static gates: MaxRiskPerOrder allows up to 2% of portfolio
	order := &Order{
		Scheme:              "ISA",
		Ticker:              "AAPL",
		Side:                Buy,
		Quantity:            10,
		LimitPrice:          150,
		MarketPrice:         150,
		PositionValue:       5000, // 50% of $10k portfolio — exceeds 2%
		TotalPortfolioValue: 10000,
	}

	result := rg.Evaluate(order)
	if result.Passed {
		t.Error("expected failure at MaxRiskPerOrder")
	}
	if result.FailedGate != "MaxRiskPerOrder" {
		t.Errorf("expected fail at MaxRiskPerOrder, got %s", result.FailedGate)
	}
}

func TestRiskGates_StaticLiquidityFail(t *testing.T) {
	r := NewRiskGates()
	// Position 40% of portfolio exceeds MaxRiskPerOrder (30%); it would also
	// exceed LiquidityCheck (20000), but MaxRiskPerOrder is evaluated first.
	order := &Order{
		Scheme:              "ISA",
		Ticker:              "AAPL",
		Side:                Buy,
		Quantity:            10,
		LimitPrice:          150,
		MarketPrice:         150,
		PositionValue:       400000,   // 40% of $1M — exceeds MaxRiskPerOrder (30%)
		TotalPortfolioValue: 1000000,
		Sector:              "TECH",
	}

	result := r.Evaluate(order)
	if result.Passed {
		t.Error("expected failure")
	}
	// MaxRiskPerOrder fires first due to 30% portfolio limit
	if result.FailedGate != "MaxRiskPerOrder" {
		t.Errorf("expected fail at MaxRiskPerOrder (30%% portfolio limit), got %s", result.FailedGate)
	}
}

func TestRiskGates_AllPass(t *testing.T) {
	rg := NewRiskGates()
	rg.MacroRegime = &MacroRegimeGate{SpyPrice: 450, SpyEMA: 448}
	rg.MarginFloor = &MarginFloorGate{FreeMargin: 5000, TotalEquity: 10000}
	rg.MaxDrawdown = &MaxDrawdownGate{DailyPnL: -100, MaxLossPct: 0.05, TotalEquity: 10000}
	rg.AssetCorrelation = &AssetCorrelationGate{SectorExposurePct: 20, MaxSectorPct: 40, Sector: "TECH"}
	now := time.Now().Add(-20 * time.Minute)
	rg.WashTimeout = &WashTimeoutGate{LastTradeTime: &now, MinCooldown: 15 * time.Minute, Ticker: "AAPL"}

	order := &Order{
		Scheme:              "ISA",
		Ticker:              "AAPL",
		Side:                Buy,
		Quantity:            10,
		LimitPrice:          150,
		MarketPrice:         150,
		PositionValue:       100, // small, passes all static gates
		TotalPortfolioValue: 10000,
		Sector:              "TECH",
	}

	result := rg.Evaluate(order)
	if !result.Passed {
		t.Errorf("expected all gates to pass, failed at %s: %s", result.FailedGate, result.FailReason)
	}
}

func TestEvaluateStatic_LiquidityCheck(t *testing.T) {
	rg := NewRiskGates()
	g := &RiskGate{Name: "LiquidityCheck", MaxRisk: 0.1, MaxQty: 200, MaxValue: 20000}
	order := &Order{PositionValue: 20001, TotalPortfolioValue: 100000}
	res := rg.evaluateStatic(g, order)
	if res.Passed {
		t.Error("expected LiquidityCheck to fail")
	}
}

func TestEvaluateStatic_AllStaticNames(t *testing.T) {
	rg := NewRiskGates()
	for _, name := range []string{"MaxRiskPerOrder", "MaxDailyLoss", "MaxOpenPositions", "CorrelationCheck", "LiquidityCheck"} {
		g := &RiskGate{Name: name, MaxRisk: 0.01, MaxQty: 1, MaxValue: 100}
		order := &Order{PositionValue: 1, TotalPortfolioValue: 10000}
		res := rg.evaluateStatic(g, order)
		if !res.Passed {
			t.Errorf("expected %s to pass with small order", name)
		}
	}
}

func TestDefaultGates_Initialized(t *testing.T) {
	if len(DefaultGates) != 5 {
		t.Errorf("expected 5 default gates, got %d", len(DefaultGates))
	}
	for _, g := range DefaultGates {
		if g.Name == "" {
			t.Error("expected non-empty gate name")
		}
	}
}

func TestGateResultFull_PropagatesFailReason(t *testing.T) {
	rg := NewRiskGates()
	rg.MacroRegime = &MacroRegimeGate{SpyPrice: 440, SpyEMA: 448}
	order := &Order{
		Scheme: "ISA", Ticker: "AAPL", Side: Buy,
		Quantity: 1, LimitPrice: 150, MarketPrice: 150,
		PositionValue: 100, TotalPortfolioValue: 10000,
	}
	result := rg.Evaluate(order)
	if result.FailReason == "" {
		t.Error("expected non-empty fail reason")
	}
}

func BenchmarkMacroRegimeGate(b *testing.B) {
	g := &MacroRegimeGate{SpyPrice: 450, SpyEMA: 448}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		g.Evaluate(Buy)
	}
}

func BenchmarkMarginFloorGate(b *testing.B) {
	g := &MarginFloorGate{FreeMargin: 5000, TotalEquity: 10000}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		g.Evaluate()
	}
}

func BenchmarkRiskGates_Evaluate(b *testing.B) {
	rg := NewRiskGates()
	rg.MacroRegime = &MacroRegimeGate{SpyPrice: 450, SpyEMA: 448}
	rg.MarginFloor = &MarginFloorGate{FreeMargin: 5000, TotalEquity: 10000}
	rg.MaxDrawdown = &MaxDrawdownGate{DailyPnL: -100, MaxLossPct: 0.05, TotalEquity: 10000}
	rg.AssetCorrelation = &AssetCorrelationGate{SectorExposurePct: 20, MaxSectorPct: 40, Sector: "TECH"}
	now := time.Now().Add(-20 * time.Minute)
	rg.WashTimeout = &WashTimeoutGate{LastTradeTime: &now, MinCooldown: 15 * time.Minute, Ticker: "AAPL"}
	order := &Order{
		Scheme: "ISA", Ticker: "AAPL", Side: Buy,
		Quantity: 10, LimitPrice: 150, MarketPrice: 150,
		PositionValue: 100, TotalPortfolioValue: 10000,
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		rg.Evaluate(order)
	}
}

// needed for fmt.Sprintf in some test strings
var _ = fmt.Sprintf

func TestMacroRegimeGate_BearFlagWins(t *testing.T) {
	// Hysteresis state (bear latched) blocks the buy even when price is
	// currently above the EMA — that's the whole point of the band.
	g := &MacroRegimeGate{SpyPrice: 449, SpyEMA: 448, Bear: true}
	res := g.Evaluate(Buy)
	if res.Passed {
		t.Fatalf("expected blocked buy on latched bear regime, got pass")
	}
	// No SPY data at all → allow, even with a stale latched state.
	g2 := &MacroRegimeGate{SpyPrice: 0, SpyEMA: 0, Bear: true}
	if !g2.Evaluate(Buy).Passed {
		t.Fatalf("expected allow on no SPY data")
	}
}
