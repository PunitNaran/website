package risk

import (
	"testing"
)

// These tests guard the static gate formulas — each gate must check
// the metric it is actually named for.

func TestMaxDailyLossGate(t *testing.T) {
	g := &RiskGate{Name: "MaxDailyLoss", MaxRisk: 0.05}
	order := &Order{TotalPortfolioValue: 10000}

	if r := NewRiskGates().evaluateStatic(g, &Order{TotalPortfolioValue: 10000, DailyPnL: -600}); r.Passed {
		t.Error("expected block: daily P&L -600 breaches -500 limit")
	}
	if r := NewRiskGates().evaluateStatic(g, &Order{TotalPortfolioValue: 10000, DailyPnL: -100}); !r.Passed {
		t.Error("expected allow: daily P&L -100 within -500 limit")
	}
	_ = order
}

func TestMaxOpenPositionsGate(t *testing.T) {
	g := &RiskGate{Name: "MaxOpenPositions", MaxQty: 10}

	// Buy at limit should block
	if r := NewRiskGates().evaluateStatic(g, &Order{Side: Buy, OpenPositions: 10}); r.Passed {
		t.Error("expected block: 10 open + 1 new = 11 > max 10")
	}
	// Buy under limit should pass
	if r := NewRiskGates().evaluateStatic(g, &Order{Side: Buy, OpenPositions: 5}); !r.Passed {
		t.Error("expected allow: 5 open + 1 new = 6 <= max 10")
	}
	// Sell should always pass (closing positions)
	if r := NewRiskGates().evaluateStatic(g, &Order{Side: Sell, OpenPositions: 100}); !r.Passed {
		t.Error("expected allow: sell should bypass open positions check")
	}
}

func TestCorrelationCheckGate(t *testing.T) {
	g := &RiskGate{Name: "CorrelationCheck", MaxRisk: 0.30}

	if r := NewRiskGates().evaluateStatic(g, &Order{SectorExposurePct: 50}); r.Passed {
		t.Error("expected block: sector exposure 50% > 30% limit")
	}
	if r := NewRiskGates().evaluateStatic(g, &Order{SectorExposurePct: 20}); !r.Passed {
		t.Error("expected allow: sector exposure 20% < 30% limit")
	}
}

func TestMaxRiskPerOrderGate(t *testing.T) {
	g := &RiskGate{Name: "MaxRiskPerOrder", MaxRisk: 0.02}

	if r := NewRiskGates().evaluateStatic(g, &Order{PositionValue: 300, TotalPortfolioValue: 10000}); r.Passed {
		t.Error("expected block: position 300 > 200 (2% of 10000)")
	}
	if r := NewRiskGates().evaluateStatic(g, &Order{PositionValue: 100, TotalPortfolioValue: 10000}); !r.Passed {
		t.Error("expected allow: position 100 < 200")
	}
}

func TestLiquidityCheckGate(t *testing.T) {
	g := &RiskGate{Name: "LiquidityCheck", MaxValue: 5000}

	if r := NewRiskGates().evaluateStatic(g, &Order{PositionValue: 8000}); r.Passed {
		t.Error("expected block: position 8000 > max 5000")
	}
	if r := NewRiskGates().evaluateStatic(g, &Order{PositionValue: 3000}); !r.Passed {
		t.Error("expected allow: position 3000 < 5000")
	}
}

func TestDefaultGates_AllEvaluate(t *testing.T) {
	g := NewRiskGates()
	order := &Order{
		Side:                Buy,
		PositionValue:       100,
		TotalPortfolioValue: 10000,
		DailyPnL:            -50,
		OpenPositions:       3,
		SectorExposurePct:   20,
	}
	for _, gate := range DefaultGates {
		r := g.evaluateStatic(&gate, order)
		if !r.Passed {
			t.Errorf("expected allow for %s on conservative order, got block: %s", gate.Name, r.Reason)
		}
	}
}
