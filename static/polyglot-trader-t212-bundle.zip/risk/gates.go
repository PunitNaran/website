// Package risk implements the 5-gate enhanced risk matrix for order validation.
// All orders must pass all gates before execution.
package risk

import (
	"fmt"
	"time"
)

// OrderSide represents a trading direction.
type OrderSide string

const (
	Buy  OrderSide = "BUY"
	Sell OrderSide = "SELL"
)

// RiskGate defines a single risk check.
type RiskGate struct {
	Name     string
	MaxRisk  float64 // Max risk per order (% of portfolio)
	MaxQty   float64 // Max quantity per order
	MaxValue float64 // Max value per order (USD)
}

// DefaultGates are the static gate configurations.
var DefaultGates = []RiskGate{
	{Name: "MaxRiskPerOrder", MaxRisk: 0.30, MaxQty: 100, MaxValue: 5000},
	{Name: "MaxDailyLoss", MaxRisk: 0.05, MaxQty: 500, MaxValue: 25000},
	{Name: "MaxOpenPositions", MaxRisk: 0.50, MaxQty: 10, MaxValue: 100000},
	{Name: "CorrelationCheck", MaxRisk: 0.30, MaxQty: 5, MaxValue: 50000},
	{Name: "LiquidityCheck", MaxRisk: 0.10, MaxQty: 200, MaxValue: 20000},
}

// Order carries enough data for each gate to validate.
type Order struct {
	Scheme              string
	Ticker              string
	Side                OrderSide
	Quantity            float64
	LimitPrice          float64
	MarketPrice         float64
	PositionValue       float64
	TotalPortfolioValue float64
	DailyPnL            float64    // today's realized+unrealized P&L (for MaxDailyLoss)
	OpenPositions       int        // current open position count (for MaxOpenPositions)
	Sector              string     // for AssetCorrelation gate
	SectorExposurePct   float64    // sector exposure % of portfolio (for CorrelationCheck)
	LastTradeTime       *time.Time // for WashTimeout gate
}

// GateResult records the outcome of a single gate evaluation.
type GateResult struct {
	Name   string
	Passed bool
	Reason string
}

// GateResultFull is the aggregate of all gate evaluations.
type GateResultFull struct {
	Passed     bool
	FailedGate string
	FailReason string
	Gates      []GateResult
}

// MacroRegimeGate checks SPY EMA against current price.
// In a bear regime (price < 50-period EMA), buying signals are blocked.
// ModelQualityGate blocks trading when the model's validation AUC is
// below the minimum threshold. AUC is the robust scale-invariant edge
// measure (F1 depends on an arbitrary probability threshold).
type ModelQualityGate struct {
	ModelAUC    float64
	MinValidAUC float64
	Source      string // "validation"
}

func (g *ModelQualityGate) Evaluate() GateResult {
	if g.ModelAUC < g.MinValidAUC {
		return GateResult{
			Name:   "ModelQuality",
			Passed: false,
			Reason: fmt.Sprintf("Model %s AUC %.3f < minimum %.3f", g.Source, g.ModelAUC, g.MinValidAUC),
		}
	}
	return GateResult{Name: "ModelQuality", Passed: true, Reason: "Model quality acceptable"}
}

// MacroRegimeGate checks SPY EMA against current price.
// In a bear regime (price < 50-period EMA), buying signals are blocked.
// Bear, when true, is an explicit regime state (e.g. from the hysteresis
// state machine) and wins over the price comparison, which is kept for
// callers that don't compute one.
type MacroRegimeGate struct {
	SpyPrice float64
	SpyEMA   float64
	Bear     bool
}

func (g *MacroRegimeGate) Evaluate(side OrderSide) GateResult {
	name := "MacroRegime"
	if side == Sell {
		return GateResult{Name: name, Passed: true, Reason: "Sell signal — macro gate bypassed"}
	}
	if g.SpyPrice == 0 && g.SpyEMA == 0 {
		return GateResult{Name: name, Passed: true, Reason: "No SPY data available — allowing"}
	}
	if g.Bear {
		return GateResult{
			Name:   name,
			Passed: false,
			Reason: fmt.Sprintf("SPY $%.2f < EMA $%.2f — bear regime, buy blocked", g.SpyPrice, g.SpyEMA),
		}
	}
	if g.SpyPrice < g.SpyEMA {
		return GateResult{
			Name:   name,
			Passed: false,
			Reason: fmt.Sprintf("SPY $%.2f < EMA $%.2f — bear regime, buy blocked", g.SpyPrice, g.SpyEMA),
		}
	}
	return GateResult{Name: name, Passed: true, Reason: fmt.Sprintf("SPY $%.2f > EMA $%.2f — bullish", g.SpyPrice, g.SpyEMA)}
}

// MarginFloorGate ensures free margin stays above 15% of total equity.
type MarginFloorGate struct {
	FreeMargin  float64
	TotalEquity float64
	MinFloorPct float64 // default 0.15
}

func (g *MarginFloorGate) Evaluate() GateResult {
	name := "MarginFloor"
	minFloor := g.MinFloorPct
	if minFloor <= 0 {
		minFloor = 0.15 // default 15%
	}
	floor := g.TotalEquity * minFloor
	if g.TotalEquity <= 0 {
		return GateResult{Name: name, Passed: false, Reason: "Total equity is zero"}
	}
	if g.FreeMargin <= floor {
		return GateResult{Name: name, Passed: false, Reason: fmt.Sprintf("Free margin $%.2f <= floor $%.2f (%.0f%% of equity $%.2f)", g.FreeMargin, floor, minFloor*100, g.TotalEquity)}
	}
	return GateResult{Name: name, Passed: true, Reason: fmt.Sprintf("Free margin $%.2f > floor $%.2f", g.FreeMargin, floor)}
}

// MaxDrawdownGate is the daily P&L circuit breaker.
type MaxDrawdownGate struct {
	DailyPnL    float64
	MaxLossPct  float64
	TotalEquity float64
}

func (g *MaxDrawdownGate) Evaluate() GateResult {
	name := "MaxDrawdown"
	lossLimit := g.TotalEquity * g.MaxLossPct
	if g.DailyPnL < -lossLimit {
		return GateResult{Name: name, Passed: false, Reason: fmt.Sprintf("Daily P&L $%.2f below limit -$%.2f", g.DailyPnL, lossLimit)}
	}
	return GateResult{Name: name, Passed: true, Reason: fmt.Sprintf("Daily P&L $%.2f within limit", g.DailyPnL)}
}

// AssetCorrelationGate limits sector exposure to < 40% to avoid correlated stacking.
type AssetCorrelationGate struct {
	SectorExposurePct float64
	MaxSectorPct      float64 // default 40.0
	Sector            string
}

func (g *AssetCorrelationGate) Evaluate() GateResult {
	name := "AssetCorrelation"
	sector := g.Sector
	if sector == "" {
		sector = "UNKNOWN"
	}
	if g.SectorExposurePct >= g.MaxSectorPct {
		return GateResult{Name: name, Passed: false, Reason: fmt.Sprintf("Sector '%s' exposure %.1f%% >= %.0f%% limit — correlated stacking", sector, g.SectorExposurePct, g.MaxSectorPct)}
	}
	return GateResult{Name: name, Passed: true, Reason: fmt.Sprintf("Sector '%s' exposure %.1f%% < %.0f%%", sector, g.SectorExposurePct, g.MaxSectorPct)}
}

// WashTimeoutGate enforces a 15-minute cooldown between trades for the same ticker.
type WashTimeoutGate struct {
	LastTradeTime *time.Time
	MinCooldown   time.Duration // default 15 minutes
	Ticker        string
}

func (g *WashTimeoutGate) Evaluate() GateResult {
	name := "WashTimeout"
	if g.LastTradeTime == nil {
		return GateResult{Name: name, Passed: true, Reason: "No prior trade — no cooldown required"}
	}
	elapsed := time.Since(*g.LastTradeTime)
	if elapsed < g.MinCooldown {
		remaining := g.MinCooldown - elapsed
		return GateResult{Name: name, Passed: false, Reason: fmt.Sprintf("Last trade for %s was %.0fs ago — cooldown not met, %.0fs remaining", g.Ticker, elapsed.Seconds(), remaining.Seconds())}
	}
	return GateResult{Name: name, Passed: true, Reason: fmt.Sprintf("Last trade for %s was %.0fs ago — cooldown satisfied", g.Ticker, elapsed.Seconds())}
}

// RiskGates runs all gate evaluations in sequence, short-circuiting on first failure.
type RiskGates struct {
	MacroRegime      *MacroRegimeGate
	MarginFloor      *MarginFloorGate
	MaxDrawdown      *MaxDrawdownGate
	AssetCorrelation *AssetCorrelationGate
	WashTimeout      *WashTimeoutGate
	ModelQuality     *ModelQualityGate
}

// NewRiskGates creates a RiskGates instance with the 5 enhanced gates
// plus the original 5 static gates.
func NewRiskGates() *RiskGates {
	return &RiskGates{}
}

// Evaluate runs all gates in order. Returns early on first failure.
func (r *RiskGates) Evaluate(order *Order) GateResultFull {
	results := make([]GateResult, 0, 10)

	// 1. MacroRegime gate
	if r.MacroRegime != nil {
		result := r.MacroRegime.Evaluate(order.Side)
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	} else {
		results = append(results, GateResult{Name: "MacroRegime", Passed: true, Reason: "Gate not configured — bypassing"})
	}

	// 2. MarginFloor gate
	if r.MarginFloor != nil {
		result := r.MarginFloor.Evaluate()
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	} else {
		results = append(results, GateResult{Name: "MarginFloor", Passed: true, Reason: "Gate not configured — bypassing"})
	}

	// 3. MaxDrawdown gate
	if r.MaxDrawdown != nil {
		result := r.MaxDrawdown.Evaluate()
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	} else {
		results = append(results, GateResult{Name: "MaxDrawdown", Passed: true, Reason: "Gate not configured — bypassing"})
	}

	// 4. AssetCorrelation gate
	if r.AssetCorrelation != nil {
		result := r.AssetCorrelation.Evaluate()
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	} else {
		results = append(results, GateResult{Name: "AssetCorrelation", Passed: true, Reason: "Gate not configured — bypassing"})
	}

	// 5. WashTimeout gate
	if r.WashTimeout != nil {
		result := r.WashTimeout.Evaluate()
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	} else {
		results = append(results, GateResult{Name: "WashTimeout", Passed: true, Reason: "Gate not configured — bypassing"})
	}

	// 6. ModelQuality gate
	if r.ModelQuality != nil {
		result := r.ModelQuality.Evaluate()
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	} else {
		results = append(results, GateResult{Name: "ModelQuality", Passed: true, Reason: "Gate not configured — bypassing"})
	}

	// 7. Static gates (original 5)
	for _, g := range DefaultGates {
		result := r.evaluateStatic(&g, order)
		results = append(results, result)
		if !result.Passed {
			return GateResultFull{Passed: false, FailedGate: result.Name, FailReason: result.Reason, Gates: results}
		}
	}

	// All gates passed
	return GateResultFull{Passed: true, Gates: results}
}

// evaluateStatic checks a static RiskGate config against an order.
// Each gate validates the metric it is actually named for.
func (r *RiskGates) evaluateStatic(g *RiskGate, order *Order) GateResult {
	switch g.Name {
	case "MaxRiskPerOrder":
		if order.PositionValue > order.TotalPortfolioValue*g.MaxRisk {
			return GateResult{Name: g.Name, Passed: false, Reason: fmt.Sprintf("position $%.2f exceeds max risk per order $%.2f (%.2f%% of portfolio)", order.PositionValue, order.TotalPortfolioValue*g.MaxRisk, g.MaxRisk*100)}
		}
	case "MaxDailyLoss":
		if order.DailyPnL < -order.TotalPortfolioValue*g.MaxRisk {
			return GateResult{Name: g.Name, Passed: false, Reason: fmt.Sprintf("daily P&L $%.2f breaches max daily loss -$%.2f (%.2f%% of portfolio)", order.DailyPnL, order.TotalPortfolioValue*g.MaxRisk, g.MaxRisk*100)}
		}
	case "MaxOpenPositions":
		if order.Side == Buy && float64(order.OpenPositions+1) > g.MaxQty {
			return GateResult{Name: g.Name, Passed: false, Reason: fmt.Sprintf("%d open positions would exceed max %d", order.OpenPositions+1, int(g.MaxQty))}
		}
	case "CorrelationCheck":
		if order.SectorExposurePct > g.MaxRisk*100 {
			return GateResult{Name: g.Name, Passed: false, Reason: fmt.Sprintf("sector exposure %.1f%% exceeds correlation limit %.0f%%", order.SectorExposurePct, g.MaxRisk*100)}
		}
	case "LiquidityCheck":
		if order.PositionValue > g.MaxValue {
			return GateResult{Name: g.Name, Passed: false, Reason: fmt.Sprintf("exceeds liquidity max value ($%.2f)", g.MaxValue)}
		}
	}
	return GateResult{Name: g.Name, Passed: true, Reason: fmt.Sprintf("OK ($%.0f value, %d positions)", order.PositionValue, order.OpenPositions)}
}
