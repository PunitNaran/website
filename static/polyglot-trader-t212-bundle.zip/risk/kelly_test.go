package risk

import (
	"math"
	"testing"
)

func TestKellySizer_BasicSize(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 80.0, 100.0)

	// p=0.6, W=1.5 → f = 0.25 * (p·W − (1−p)) / W = 0.25*(0.9−0.4)/1.5
	// = 0.25*0.3333 = 0.0833 (below the 10% cap)
	f := sizer.Size("AAPL", 0.6, 1.5, 0)
	expected := 0.25 * (0.6*1.5 - 0.4) / 1.5
	if math.Abs(f-expected) > 1e-9 {
		t.Fatalf("expected %v, got %v", expected, f)
	}
}

func TestKellySizer_NegativeKelly(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 80.0, 100.0)

	// p=0.3, W=1.5 → p·W−(1−p) = 0.45−0.7 = −0.25 → negative → 0
	f := sizer.Size("TSLA", 0.3, 1.5, 0)
	if f != 0.0 {
		t.Fatalf("expected 0, got %v", f)
	}
}

func TestKellySizer_ExposureClamp(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 20.0, 100.0)

	// p=0.9 → full kelly = 0.25 * (1.8-1)/1.5 = 0.25*0.533 = 0.133
	// but exposure cap is 20% and current is 18%, so remaining is 2%
	f := sizer.Size("AAPL", 0.9, 1.5, 0.18)
	if math.Abs(f-0.02) > 1e-9 {
		t.Fatalf("expected ~0.02, got %v", f)
	}
}

func TestKellySizer_ComputeNotional(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 80.0, 500.0)

	// 10% of $10000 = $1000
	notional := sizer.ComputeNotional(10000, 0.1)
	if notional != 1000.0 {
		t.Fatalf("expected 1000, got %v", notional)
	}

	// Below min → 0
	notional = sizer.ComputeNotional(1000, 0.01) // $10 < $500 min
	if notional != 0.0 {
		t.Fatalf("expected 0, got %v", notional)
	}
}

func TestKellySizer_LightGBM(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 80.0, 100.0)
	output := map[string]float64{"probability": 0.6}
	f := sizer.SizeFromLightGBM("AAPL", output, 1.5, 0)
	expected := 0.25 * (0.6*1.5 - 0.4) / 1.5 // p=0.6, W=1.5
	if math.Abs(f-expected) > 1e-9 {
		t.Fatalf("expected %v, got %v", expected, f)
	}
}

func TestKellySizer_SensitivityTable(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 80.0, 100.0)
	rows := sizer.SensitivityTable(1.5)
	if len(rows) != 21 {
		t.Fatalf("expected 21 rows, got %d", len(rows))
	}
	// p=0 → negative, f=0
	if rows[0].Size != 0 {
		t.Fatalf("p=0 expected 0, got %v", rows[0].Size)
	}
	// p=1 → full positive
	if rows[20].Size <= 0 {
		t.Fatalf("p=1.0 expected positive, got %v", rows[20].Size)
	}
}

func TestKellySizer_ProbabilityClamp(t *testing.T) {
	sizer := NewQuarterKellySizer(10.0, 80.0, 100.0)

	// p > 1 clamped to 1
	f1 := sizer.Size("AAPL", 1.5, 1.5, 0)
	f2 := sizer.Size("AAPL", 1.0, 1.5, 0)
	if math.Abs(f1-f2) > 1e-9 {
		t.Fatalf("expected clamped values to match: %v vs %v", f1, f2)
	}

	// p < 0 clamped to 0 → negative kelly → 0
	f := sizer.Size("AAPL", -0.5, 1.5, 0)
	if f != 0.0 {
		t.Fatalf("expected 0, got %v", f)
	}
}

func TestKellySizer_SetMinTradeSize(t *testing.T) {
	s := NewQuarterKellySizer(10.0, 80.0, 100.0)
	if s.MinTradeSize() != 100.0 {
		t.Fatalf("expected 100, got %v", s.MinTradeSize())
	}
	// equity 1000, p=0.65, W=1 → f=0.25*0.3=0.075 → notional £75
	s.SetMinTradeSize(50.0)
	if got := s.ComputeNotional(1000, 0.075); got != 75.0 {
		t.Fatalf("expected 75 (75 >= 50), got %v", got)
	}
	// lower floor to £5: notional £7.50 (f=0.0075) now passes
	s.SetMinTradeSize(5.0)
	if got := s.ComputeNotional(1000, 0.0075); got != 7.5 {
		t.Fatalf("expected 7.5 (7.5 >= 5), got %v", got)
	}
	// floor higher than notional → 0
	s.SetMinTradeSize(10.0)
	if got := s.ComputeNotional(1000, 0.0075); got != 0.0 {
		t.Fatalf("expected 0 (7.5 < 10), got %v", got)
	}
}
